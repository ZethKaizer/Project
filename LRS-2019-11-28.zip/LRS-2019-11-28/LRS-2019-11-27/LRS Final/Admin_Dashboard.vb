﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin_Dashboard
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs) Handles Panel6.Paint

    End Sub

    Private Sub Admin_Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        showTotalUser()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label11.Text = Date.Now.ToString("MMMM dd, yyyy")
        Label3.Text = Date.Now.ToString("hh:mm:ss tt")
        showTotalUser()
        'LoadTotalVideo()
        'LoadTotalPDF()
    End Sub

    Public Sub LoadTotalVideo()

        TotalVideos.Text = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos", "*.*", SearchOption.AllDirectories).ToList().Count.ToString()

    End Sub

    Public Sub LoadTotalPDF()
        TotalPDF.Text = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF", "*.*", SearchOption.AllDirectories).ToList().Count.ToString()
    End Sub

    Public Sub showTotalUser()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_user", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select count(user_id) as MaxID from tbl_user"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid
        End If
        lbl_totalUser.Text = intid
        CN.Close()
    End Sub



End Class
