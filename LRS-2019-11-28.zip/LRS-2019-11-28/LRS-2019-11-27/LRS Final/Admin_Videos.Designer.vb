﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Videos
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Videos))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BunifuSlider1 = New Bunifu.Framework.UI.BunifuSlider()
        Me.bunifuImageButton10 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton11 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton9 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton7 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton6 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton5 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btn_Upload = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(976, 50)
        Me.Panel1.TabIndex = 78
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(206, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Windows Media Player"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.LRS_Final.My.Resources.Resources.vidIcon
        Me.PictureBox1.Location = New System.Drawing.Point(150, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(50, 47)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.Panel2)
        Me.Panel3.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(0, 50)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(693, 579)
        Me.Panel3.TabIndex = 80
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel5.Controls.Add(Me.lbl_Title)
        Me.Panel5.Location = New System.Drawing.Point(0, 443)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(693, 58)
        Me.Panel5.TabIndex = 81
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.lbl_Title.ForeColor = System.Drawing.Color.White
        Me.lbl_Title.Location = New System.Drawing.Point(71, 16)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(0, 24)
        Me.lbl_Title.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel2.Controls.Add(Me.BunifuSlider1)
        Me.Panel2.Controls.Add(Me.bunifuImageButton10)
        Me.Panel2.Controls.Add(Me.bunifuImageButton11)
        Me.Panel2.Controls.Add(Me.bunifuImageButton9)
        Me.Panel2.Controls.Add(Me.bunifuImageButton7)
        Me.Panel2.Controls.Add(Me.bunifuImageButton6)
        Me.Panel2.Controls.Add(Me.bunifuImageButton5)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 496)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(693, 83)
        Me.Panel2.TabIndex = 80
        '
        'BunifuSlider1
        '
        Me.BunifuSlider1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSlider1.BackgroudColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BunifuSlider1.BorderRadius = 0
        Me.BunifuSlider1.IndicatorColor = System.Drawing.Color.DodgerBlue
        Me.BunifuSlider1.Location = New System.Drawing.Point(561, 29)
        Me.BunifuSlider1.MaximumValue = 100
        Me.BunifuSlider1.Name = "BunifuSlider1"
        Me.BunifuSlider1.Size = New System.Drawing.Size(117, 30)
        Me.BunifuSlider1.TabIndex = 19
        Me.BunifuSlider1.Value = 20
        '
        'bunifuImageButton10
        '
        Me.bunifuImageButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton10.Image = CType(resources.GetObject("bunifuImageButton10.Image"), System.Drawing.Image)
        Me.bunifuImageButton10.ImageActive = Nothing
        Me.bunifuImageButton10.Location = New System.Drawing.Point(530, 30)
        Me.bunifuImageButton10.Name = "bunifuImageButton10"
        Me.bunifuImageButton10.Size = New System.Drawing.Size(25, 25)
        Me.bunifuImageButton10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton10.TabIndex = 18
        Me.bunifuImageButton10.TabStop = False
        Me.bunifuImageButton10.Zoom = 10
        '
        'bunifuImageButton11
        '
        Me.bunifuImageButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton11.Image = CType(resources.GetObject("bunifuImageButton11.Image"), System.Drawing.Image)
        Me.bunifuImageButton11.ImageActive = Nothing
        Me.bunifuImageButton11.Location = New System.Drawing.Point(155, 21)
        Me.bunifuImageButton11.Name = "bunifuImageButton11"
        Me.bunifuImageButton11.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton11.TabIndex = 17
        Me.bunifuImageButton11.TabStop = False
        Me.bunifuImageButton11.Zoom = 10
        '
        'bunifuImageButton9
        '
        Me.bunifuImageButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton9.Image = CType(resources.GetObject("bunifuImageButton9.Image"), System.Drawing.Image)
        Me.bunifuImageButton9.ImageActive = Nothing
        Me.bunifuImageButton9.Location = New System.Drawing.Point(442, 21)
        Me.bunifuImageButton9.Name = "bunifuImageButton9"
        Me.bunifuImageButton9.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton9.TabIndex = 16
        Me.bunifuImageButton9.TabStop = False
        Me.bunifuImageButton9.Zoom = 10
        '
        'bunifuImageButton7
        '
        Me.bunifuImageButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton7.Image = CType(resources.GetObject("bunifuImageButton7.Image"), System.Drawing.Image)
        Me.bunifuImageButton7.ImageActive = Nothing
        Me.bunifuImageButton7.Location = New System.Drawing.Point(219, 21)
        Me.bunifuImageButton7.Name = "bunifuImageButton7"
        Me.bunifuImageButton7.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton7.TabIndex = 15
        Me.bunifuImageButton7.TabStop = False
        Me.bunifuImageButton7.Zoom = 10
        '
        'bunifuImageButton6
        '
        Me.bunifuImageButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton6.Image = CType(resources.GetObject("bunifuImageButton6.Image"), System.Drawing.Image)
        Me.bunifuImageButton6.ImageActive = Nothing
        Me.bunifuImageButton6.Location = New System.Drawing.Point(82, 15)
        Me.bunifuImageButton6.Name = "bunifuImageButton6"
        Me.bunifuImageButton6.Size = New System.Drawing.Size(55, 55)
        Me.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton6.TabIndex = 14
        Me.bunifuImageButton6.TabStop = False
        Me.bunifuImageButton6.Zoom = 10
        '
        'bunifuImageButton5
        '
        Me.bunifuImageButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton5.Image = CType(resources.GetObject("bunifuImageButton5.Image"), System.Drawing.Image)
        Me.bunifuImageButton5.ImageActive = Nothing
        Me.bunifuImageButton5.Location = New System.Drawing.Point(21, 21)
        Me.bunifuImageButton5.Name = "bunifuImageButton5"
        Me.bunifuImageButton5.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton5.TabIndex = 13
        Me.bunifuImageButton5.TabStop = False
        Me.bunifuImageButton5.Zoom = 10
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(0, -1)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(693, 444)
        Me.AxWindowsMediaPlayer1.TabIndex = 78
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.ComboBox2)
        Me.Panel4.Controls.Add(Me.ComboBox1)
        Me.Panel4.Controls.Add(Me.ListBox1)
        Me.Panel4.Controls.Add(Me.btn_Upload)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(693, 50)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(283, 579)
        Me.Panel4.TabIndex = 81
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(13, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 20)
        Me.Label3.TabIndex = 81
        Me.Label3.Text = "Show Videos"
        '
        'ComboBox2
        '
        Me.ComboBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ComboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.ComboBox2.ForeColor = System.Drawing.Color.White
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"ICT", "HE", "Agriculture"})
        Me.ComboBox2.Location = New System.Drawing.Point(17, 486)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(250, 28)
        Me.ComboBox2.TabIndex = 80
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.ComboBox1.ForeColor = System.Drawing.Color.White
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"", "ICT", "HE", "Agriculture"})
        Me.ComboBox1.Location = New System.Drawing.Point(17, 45)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(250, 28)
        Me.ComboBox1.TabIndex = 79
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.White
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(17, 88)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(250, 377)
        Me.ListBox1.TabIndex = 77
        '
        'btn_Upload
        '
        Me.btn_Upload.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Upload.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Upload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Upload.BorderRadius = 7
        Me.btn_Upload.ButtonText = "                Upload"
        Me.btn_Upload.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Upload.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Upload.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Upload.Iconimage = Global.LRS_Final.My.Resources.Resources.uploadIcon
        Me.btn_Upload.Iconimage_right = Nothing
        Me.btn_Upload.Iconimage_right_Selected = Nothing
        Me.btn_Upload.Iconimage_Selected = Nothing
        Me.btn_Upload.IconMarginLeft = 0
        Me.btn_Upload.IconMarginRight = 0
        Me.btn_Upload.IconRightVisible = True
        Me.btn_Upload.IconRightZoom = 0.0R
        Me.btn_Upload.IconVisible = True
        Me.btn_Upload.IconZoom = 50.0R
        Me.btn_Upload.IsTab = False
        Me.btn_Upload.Location = New System.Drawing.Point(17, 525)
        Me.btn_Upload.Name = "btn_Upload"
        Me.btn_Upload.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Upload.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Upload.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Upload.selected = False
        Me.btn_Upload.Size = New System.Drawing.Size(250, 42)
        Me.btn_Upload.TabIndex = 75
        Me.btn_Upload.Text = "                Upload"
        Me.btn_Upload.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Upload.Textcolor = System.Drawing.Color.White
        Me.btn_Upload.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Timer1
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Admin_Videos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Admin_Videos"
        Me.Size = New System.Drawing.Size(976, 629)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_Upload As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents BunifuSlider1 As Bunifu.Framework.UI.BunifuSlider
    Private WithEvents bunifuImageButton10 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton11 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton9 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton7 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton6 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton5 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents lbl_Title As System.Windows.Forms.Label


End Class
