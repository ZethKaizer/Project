﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin_User_Manage
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim admin_dashboard As New Admin_Dashboard
    Dim ds As DataSet
    Dim dbDataSet As New DataTable

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"


    Private Sub Admin_User_Manage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
      
        tableHeader()
        Timer1.Enabled = True
    End Sub
    Private Sub tableHeader()
        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(1).HeaderText = "Name"
        DataGridView1.Columns(2).HeaderText = "User Name"
        DataGridView1.Columns(3).HeaderText = "Password"
        DataGridView1.Columns(4).HeaderText = "Email"
        DataGridView1.Columns(5).HeaderText = "User Type"
        DataGridView1.Columns(6).HeaderText = "Date Created"
    End Sub

    Private Sub DataGridView1_CellClick1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = DataGridView1.Rows(e.RowIndex)
            BunifuMetroTextbox1.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_ID.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_Name.Text = row.Cells("user_name").Value.ToString
            Admin_Update_User.Textbox_Username.Text = row.Cells("user_username").Value.ToString
            Admin_Update_User.Textbox_Pass.Text = row.Cells("user_pass").Value.ToString
            Admin_Update_User.Textbox_Email.Text = row.Cells("user_email").Value.ToString
            Admin_Update_User.Combobox_Usertype.Text = row.Cells("user_usertype").Value.ToString
            Admin_Update_User.Textbox_DateCreated.Text = row.Cells("user_datecreated").Value.ToString



        End If
    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        If BunifuMetroTextbox1.Text = Nothing Then
            MetroFramework.MetroMessageBox.Show(Me, "Select Account to be Update!", "Select Account", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Admin_Update_User.Show()
        End If
    End Sub

    Private Sub btn_Add_Click(sender As Object, e As EventArgs) Handles btn_Add.Click

    End Sub
End Class
