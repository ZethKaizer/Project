﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Create_User
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Combobox_Usertype = New MetroFramework.Controls.MetroComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Textbox_DateCreated = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Email = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Textbox_ID = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Textbox_Name = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Pass = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Textbox_Username = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_Add = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(171, 603)
        Me.Panel1.TabIndex = 105
        '
        'Combobox_Usertype
        '
        Me.Combobox_Usertype.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Combobox_Usertype.FormattingEnabled = True
        Me.Combobox_Usertype.ItemHeight = 23
        Me.Combobox_Usertype.Items.AddRange(New Object() {"", "Admin", "User"})
        Me.Combobox_Usertype.Location = New System.Drawing.Point(202, 407)
        Me.Combobox_Usertype.Name = "Combobox_Usertype"
        Me.Combobox_Usertype.Size = New System.Drawing.Size(388, 29)
        Me.Combobox_Usertype.TabIndex = 104
        Me.Combobox_Usertype.UseSelectable = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(199, 451)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 20)
        Me.Label9.TabIndex = 103
        Me.Label9.Text = "Date Created"
        '
        'Textbox_DateCreated
        '
        Me.Textbox_DateCreated.Depth = 0
        Me.Textbox_DateCreated.Hint = ""
        Me.Textbox_DateCreated.Location = New System.Drawing.Point(203, 480)
        Me.Textbox_DateCreated.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_DateCreated.Name = "Textbox_DateCreated"
        Me.Textbox_DateCreated.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_DateCreated.SelectedText = ""
        Me.Textbox_DateCreated.SelectionLength = 0
        Me.Textbox_DateCreated.SelectionStart = 0
        Me.Textbox_DateCreated.Size = New System.Drawing.Size(387, 23)
        Me.Textbox_DateCreated.TabIndex = 101
        Me.Textbox_DateCreated.UseSystemPasswordChar = False
        '
        'Textbox_Email
        '
        Me.Textbox_Email.Depth = 0
        Me.Textbox_Email.Hint = ""
        Me.Textbox_Email.Location = New System.Drawing.Point(202, 347)
        Me.Textbox_Email.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Email.Name = "Textbox_Email"
        Me.Textbox_Email.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Email.SelectedText = ""
        Me.Textbox_Email.SelectionLength = 0
        Me.Textbox_Email.SelectionStart = 0
        Me.Textbox_Email.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Email.TabIndex = 100
        Me.Textbox_Email.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(197, 321)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 20)
        Me.Label7.TabIndex = 99
        Me.Label7.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(198, 382)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 98
        Me.Label5.Text = "User Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(197, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 20)
        Me.Label2.TabIndex = 91
        Me.Label2.Text = "ID"
        '
        'Textbox_ID
        '
        Me.Textbox_ID.Depth = 0
        Me.Textbox_ID.Hint = ""
        Me.Textbox_ID.Location = New System.Drawing.Point(200, 89)
        Me.Textbox_ID.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_ID.Name = "Textbox_ID"
        Me.Textbox_ID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_ID.SelectedText = ""
        Me.Textbox_ID.SelectionLength = 0
        Me.Textbox_ID.SelectionStart = 0
        Me.Textbox_ID.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_ID.TabIndex = 90
        Me.Textbox_ID.UseSystemPasswordChar = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(198, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 20)
        Me.Label3.TabIndex = 92
        Me.Label3.Text = "Name"
        '
        'Textbox_Name
        '
        Me.Textbox_Name.Depth = 0
        Me.Textbox_Name.Hint = ""
        Me.Textbox_Name.Location = New System.Drawing.Point(200, 149)
        Me.Textbox_Name.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Name.Name = "Textbox_Name"
        Me.Textbox_Name.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Name.SelectedText = ""
        Me.Textbox_Name.SelectionLength = 0
        Me.Textbox_Name.SelectionStart = 0
        Me.Textbox_Name.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_Name.TabIndex = 93
        Me.Textbox_Name.UseSystemPasswordChar = False
        '
        'Textbox_Pass
        '
        Me.Textbox_Pass.Depth = 0
        Me.Textbox_Pass.Hint = ""
        Me.Textbox_Pass.Location = New System.Drawing.Point(202, 278)
        Me.Textbox_Pass.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Pass.Name = "Textbox_Pass"
        Me.Textbox_Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Pass.SelectedText = ""
        Me.Textbox_Pass.SelectionLength = 0
        Me.Textbox_Pass.SelectionStart = 0
        Me.Textbox_Pass.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Pass.TabIndex = 97
        Me.Textbox_Pass.UseSystemPasswordChar = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(198, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 94
        Me.Label4.Text = "User Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Gray
        Me.Label8.Location = New System.Drawing.Point(198, 253)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 20)
        Me.Label8.TabIndex = 96
        Me.Label8.Text = "Password"
        '
        'Textbox_Username
        '
        Me.Textbox_Username.Depth = 0
        Me.Textbox_Username.Hint = ""
        Me.Textbox_Username.Location = New System.Drawing.Point(201, 210)
        Me.Textbox_Username.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Username.Name = "Textbox_Username"
        Me.Textbox_Username.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Username.SelectedText = ""
        Me.Textbox_Username.SelectionLength = 0
        Me.Textbox_Username.SelectionStart = 0
        Me.Textbox_Username.Size = New System.Drawing.Size(389, 23)
        Me.Textbox_Username.TabIndex = 95
        Me.Textbox_Username.UseSystemPasswordChar = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label1.Location = New System.Drawing.Point(252, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 29)
        Me.Label1.TabIndex = 88
        Me.Label1.Text = "Please Fill up The Form"
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 7
        Me.BunifuFlatButton2.ButtonText = "  Cancel"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = Global.LRS_Final.My.Resources.Resources.clearIcon
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0.0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 70.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(474, 522)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(116, 50)
        Me.BunifuFlatButton2.TabIndex = 102
        Me.BunifuFlatButton2.Text = "  Cancel"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'btn_Add
        '
        Me.btn_Add.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Add.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Add.BorderRadius = 7
        Me.btn_Add.ButtonText = "  Add"
        Me.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Add.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Add.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Add.Iconimage = Global.LRS_Final.My.Resources.Resources.addicon
        Me.btn_Add.Iconimage_right = Nothing
        Me.btn_Add.Iconimage_right_Selected = Nothing
        Me.btn_Add.Iconimage_Selected = Nothing
        Me.btn_Add.IconMarginLeft = 0
        Me.btn_Add.IconMarginRight = 0
        Me.btn_Add.IconRightVisible = True
        Me.btn_Add.IconRightZoom = 0.0R
        Me.btn_Add.IconVisible = True
        Me.btn_Add.IconZoom = 70.0R
        Me.btn_Add.IsTab = False
        Me.btn_Add.Location = New System.Drawing.Point(352, 522)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Add.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Add.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Add.selected = False
        Me.btn_Add.Size = New System.Drawing.Size(116, 50)
        Me.btn_Add.TabIndex = 89
        Me.btn_Add.Text = "  Add"
        Me.btn_Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Add.Textcolor = System.Drawing.Color.White
        Me.btn_Add.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Admin_Create_User
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(619, 603)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Combobox_Usertype)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.BunifuFlatButton2)
        Me.Controls.Add(Me.Textbox_DateCreated)
        Me.Controls.Add(Me.Textbox_Email)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Textbox_ID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Textbox_Name)
        Me.Controls.Add(Me.Textbox_Pass)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Textbox_Username)
        Me.Controls.Add(Me.btn_Add)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Create_User"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin_Create_User"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Combobox_Usertype As MetroFramework.Controls.MetroComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Textbox_DateCreated As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Email As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Textbox_ID As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Name As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Pass As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Username As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents btn_Add As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
