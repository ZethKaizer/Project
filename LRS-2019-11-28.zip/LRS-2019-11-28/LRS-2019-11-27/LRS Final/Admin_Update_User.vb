﻿Public Class Admin_Update_User

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Textbox_DateCreated.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Me.Hide()
    End Sub
End Class