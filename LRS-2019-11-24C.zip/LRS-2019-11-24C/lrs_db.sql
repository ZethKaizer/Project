-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2019 at 07:25 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lrs_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pdf`
--

CREATE TABLE `tbl_pdf` (
  `pdf_id` int(200) NOT NULL,
  `pdf_namefile` varchar(230) NOT NULL,
  `pdf_datecreated` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(20) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `user_username` varchar(40) NOT NULL,
  `user_pass` varchar(15) NOT NULL,
  `user_email` varchar(20) NOT NULL,
  `user_usertype` varchar(20) NOT NULL,
  `user_datecreated` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_username`, `user_pass`, `user_email`, `user_usertype`, `user_datecreated`) VALUES
(1, '3232', '3232', '3232', '3232', 'Admin', 'November 06, 2019'),
(2, '4', '5', '7', '4', 'Admin', 'November 12, 2019'),
(9, 'n525n2', '5n2525n2n5', '2n52n5', '5n225n2', 'User', 'November 21, 2019'),
(12, 'b42b42', '42b42b', '2b424b2', '42b424b2b424b2', 'Admin', ''),
(14, 'b42b42', '4b2b42', 'b42b42', 'b42b42b', 'Admin', ''),
(16, 'v4214v124v1', 'v124v1v414v1', '12v414v1v4', '214v14v14v1242b421b4', 'Admin', ''),
(17, 'rwrwrw', 'park', 'park', '4242b414', 'Admin', 'November 21, 2019'),
(18, 'b42b42', 'parky', 'park', '4b24b2', 'User', 'November 21, 2019');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_pdf`
--
ALTER TABLE `tbl_pdf`
  ADD PRIMARY KEY (`pdf_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_pdf`
--
ALTER TABLE `tbl_pdf`
  MODIFY `pdf_id` int(200) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
