﻿Public Class AdminManageAccount

    Private Sub AdminManageAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class