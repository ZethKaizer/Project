﻿Public Class frm_Front

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim fmain As New frm_Main
        fmain.Show()
        Me.Hide()
    End Sub


End Class
