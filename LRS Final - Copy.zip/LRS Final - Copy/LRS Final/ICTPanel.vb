﻿Public Class ICTPanel

    Private Sub ICTPanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class