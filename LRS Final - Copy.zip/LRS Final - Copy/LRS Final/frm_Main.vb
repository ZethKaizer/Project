﻿Public Class frm_Main
    
    Private Sub frm_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SidePanel.Height = Button1.Height
        SidePanel.Top = Button1.Top
        SidePanel.BringToFront()

    End Sub

    Sub switchPanel(ByVal panel As Form)
        MainPanel.Controls.Clear()
        panel.TopLevel = False
        MainPanel.Controls.Add(panel)
        panel.Show()
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SidePanel.Height = Button1.Height
        SidePanel.Top = Button1.Top
        switchPanel(ICTPanel)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        
        SidePanel.Height = Button2.Height
        SidePanel.Top = Button2.Top
        switchPanel(HEPanel)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        
        SidePanel.Height = Button3.Height
        SidePanel.Top = Button3.Top
        switchPanel(AgriPanel)
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)
        frm_admin_login.Show()

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        frm_admin_login.Show()
    End Sub


    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub
End Class