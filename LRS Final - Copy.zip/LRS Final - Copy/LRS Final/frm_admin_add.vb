﻿Public Class frm_admin_add


    Private Sub picboxAdduser_Click(sender As Object, e As EventArgs) Handles picboxAdduser.Click
        Dim adduser As New frm_add_user
        adduser.Show()
        Me.Close()
    End Sub
End Class