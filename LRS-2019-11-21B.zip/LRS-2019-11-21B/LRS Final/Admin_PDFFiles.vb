﻿Imports MySql.Data.MySqlClient

Public Class Admin_PDFFiles
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim query, getName, path, secretDtrows
    Dim adminDashboard As New Admin_Dashboard

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click

    End Sub
    Private Sub ViewDG()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim cmnd As MySqlCommand
        Dim dt_table As New DataTable
        Dim dtAdptr As New MySqlDataAdapter
        Dim bndSource As New BindingSource
        With dtAdptr
            Try
                conn.Open()
                query = "select pdf_id as 'ID', pdf_namefile as 'Name File', pdf_datecreated as 'Date Created' from tbl_pdf"

                cmnd = New MySqlCommand(
                                        query, conn
                                        )
                .SelectCommand = cmnd
                .Fill(dt_table)
                bndSource.DataSource = dt_table

                BunifuCustomDataGrid1.DataSource = dt_table

            Catch ex As Exception
                MsgBox("Check Your Connection!!",
                                MsgBoxStyle.Exclamation, "Lost Conn")
            End Try
            conn.Close()
        End With
    End Sub

    Private Sub BrowseFile() Handles BunifuFlatButton8.Click
        OpenFileDialog1.Filter = " Choose File (*.pdf) | *.pdf;"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Title = "Select File Pdf.."
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub OpfD() Handles OpenFileDialog1.FileOk
        path = System.IO.Path.GetFullPath(OpenFileDialog1.FileName)
        getName = System.IO.Path.GetFileName(OpenFileDialog1.FileName)

        AxAcroPDF1.src = path


        MaterialSingleLineTextField2.Text = getName
    End Sub

    Private Sub Admin_PDFFiles_Load(sender As Object, e As EventArgs) Handles Me.Load
        ViewDG()
        Timer1.Enabled = True
    End Sub

   
    Private Sub uploadFile()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim cmnd As MySqlCommand
        Dim dt_table As New DataTable
        Dim dtAdptr As New MySqlDataAdapter
        Dim bndSource As New BindingSource

        Try
            conn.Open()
            query = "insert into tbl_pdf (pdf_id, pdf_namefile, pdf_datecreated) values ('', '" & getName & "', '" & Label11.Text & "')"

            cmnd = New MySqlCommand(query, conn)

            Dim _read As MySqlDataReader
            _read = cmnd.ExecuteReader
        Catch

        End Try
        conn.Close()
        ViewDG() 'refresh Datagrid


    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        uploadFile()
    End Sub

    Private Sub BunifuCustomDataGrid1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellClick
        path = System.IO.Path.GetFullPath(OpenFileDialog1.FileName)
        getName = System.IO.Path.GetFileName(OpenFileDialog1.FileName)

        AxAcroPDF1.src = path

    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick
        Try
            Dim index As Integer
            Dim selectrow As DataGridViewRow
            index = e.RowIndex
            selectrow = BunifuCustomDataGrid1.Rows(index)
            MaterialSingleLineTextField2.Text = "Name File : " & selectrow.Cells(1).Value.ToString()
            secretDtrows = selectrow.Cells(1).Value.ToString() 'get data click DG
        Catch ex As Exception
            'errorbypass
        End Try
    End Sub

   
    Private Sub btn_View_Click(sender As Object, e As EventArgs) Handles btn_View.Click

        path = System.IO.Path.GetFullPath(OpenFileDialog1.FileName)
        getName = System.IO.Path.GetFileName(OpenFileDialog1.FileName)

        AxAcroPDF1.src = path
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label11.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub
End Class
