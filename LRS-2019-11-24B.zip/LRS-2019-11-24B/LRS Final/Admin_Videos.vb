﻿Imports System.IO
Imports WMPLib
Public Class Admin_Videos

    Private Sub btn_Browse_Click(sender As Object, e As EventArgs) Handles btn_Browse.Click
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos"
        'MessageBox.Show(directory)
        'OpenFileDialog1.InitialDirectory = "C:\Users\user\Documents\Visual Studio 2012\Projects\LRS-2019-11-23D\LRS Final\Resources\LRS_Videos"
        OpenFileDialog1.InitialDirectory = directory

        OpenFileDialog1.Filter = "MP4 Files (*.mp4)|*.mp4|All files (*.*)|*.*"

        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            For Each str As String In OpenFileDialog1.FileNames
                If ListBox1.Items.Contains(str) = False Then
                    ListBox1.Items.Add(str)
                End If
            Next

        End If
    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        Try
            AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Admin_Videos_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Load Files
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos"

        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.mp4")
        Dim fi As IO.FileInfo

        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next


    End Sub




    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        AxWindowsMediaPlayer1.stretchToFit = True
        If PlayItems.Checked = True Then
            'nothing
            If ListBox1.SelectedIndex > ListBox1.Items.Count - 1 = True Then
                ListBox1.SelectedIndex = 0
            ElseIf AxWindowsMediaPlayer1.playState = WMPPlayState.wmppsStopped = True Then
                ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
                AxWindowsMediaPlayer1 = ListBox1.SelectedItem
            End If
        End If
    End Sub

    Private Sub btn_Upload_Click(sender As Object, e As EventArgs) Handles btn_Upload.Click
        OpenFileDialog1.Filter = "MP4 Files (*.mp4)|*.mp4"
        Dim destinationFile = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos"
        'Disable MultiSelect
        OpenFileDialog1.Multiselect = False
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            ListBox1.Items.Clear()
            For Each str As String In OpenFileDialog1.FileNames
                Dim sourceFile = str

                If True Then

                End If

                'Will create a directory if not exist
                Directory.CreateDirectory(destinationFile)
                'Will copy the files
                File.Copy(sourceFile, Path.Combine(destinationFile, Path.GetFileName(sourceFile)), True)


                'Load Files
                Dim strFileSize As String = ""
                Dim di As New IO.DirectoryInfo(destinationFile)
                Dim aryFi As IO.FileInfo() = di.GetFiles("*.mp4")
                Dim fi As IO.FileInfo

                For Each fi In aryFi
                    ListBox1.Items.Add(fi.FullName)

                Next

                'MessageBox.Show(sourceFile + Environment.NewLine + Path.Combine(destinationFile, Path.GetFileName(sourceFile)))


            Next

        End If
    End Sub
End Class
