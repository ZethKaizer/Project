﻿Imports WMPLib
Public Class AdminVideos

   

    Private Sub btn_Browse_Click(sender As Object, e As EventArgs) Handles btn_Browse.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            For Each str As String In OpenFileDialog1.FileNames
                If ListBox1.Items.Contains(str) = False Then
                    ListBox1.Items.Add(str)
                End If
            Next


        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        
    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        Try
            AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
        Catch ex As Exception

        End Try
    End Sub
End Class
