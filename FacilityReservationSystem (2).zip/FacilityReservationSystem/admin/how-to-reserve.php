<style>
	.back-to-top {
    position: fixed;
    bottom: 25px;
    right: 25px;
}
</style>

<button href="#" class="btn btn-primary back-to-top" data-toggle="modal" data-target="#howToReserve" role="button">How to reserve?</button>


<div class="modal fade" id="howToReserve">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        
		<div class="modal-header">
          <h5 class="modal-title text-center">HOW TO RESERVE?</h5>
        </div>
        
		<div class="modal-body">
			<ul class="nav nav-pills">
				<li class="active" style="width: 50%;"><a data-toggle="pill" href="#NonMem">Non Member</a></li>
				<li style="width: 49%;"><a data-toggle="pill" href="#Mem">Member</a></li>
			</ul>

			<div class="tab-content">
				<div id="NonMem" class="tab-pane fade in active">
                    <br>
					<p class="text-center"> You must have account to enable this part of reservation. If you want to register, <br/><a href='registration.php'>CLICK THIS LINK.</a> </p>
				</div>

				<div id="Mem" class="tab-pane fade">
				<br>
					<p class="text-left">1. Sign in your account.</p>
					<p class="text-left">2. Every module has a calendar. Select between three (3) modules.</p>
					<p class="text-left">3. Select the date and the equipment you want to reserve. </p>
					<p class="text-left">4. Click <b>Submit</b>. </p>
					<p class="text-left">5. Your submitted request has now pending. </p>
					<p class="text-left">6. Pay through walk in. So that, you are able to reserved that equipment by selected date.</p>
					<p class="text-left">7. Once you already paid, admin will send you a notification that your request has been approved.</p>
					<p class="text-left">8. You can now view it at your transaction history or calendar. </p>
					

					
					
				</div>
			</div>			
        </div>  
	</div>
</div>
