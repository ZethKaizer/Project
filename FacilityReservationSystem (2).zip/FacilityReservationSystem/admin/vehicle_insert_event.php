<?php

include('connection.php');
//echo $_POST['title'];
if (isset($_POST['insert'])){
	
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = $_POST['color'];
	$name = $_POST['name'];
	$username = $_POST['username'];
	$contact_number = $_POST['contact_number'];
	$email = $_POST['email'];
	$status = $_POST['status'];

	
	$sql_date_between = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
		
	$sql_insert = mysqli_query($conn, "INSERT INTO tbl_vehicle_reservation(title, start, end, color, name, username, contact_number, email, status) 
	values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Reserved by School')");
	//$req = $bdd->prepare($sql);
	//$req->execute();
//values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Reserved')");
		
	echo $sql;
	
//	$res = mysqli_query($conn, $sql);

}
header('Location: vehicle_reservation.php');
	
?>
