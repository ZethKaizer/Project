<?php 
include('connection.php');
include('tags.php');

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facility Reservation System</title>
    <style>

 body {
           /*
 background-image: linear-gradient(
    rgba(0, 0, 0, 0.1),
    rgba(0, 0, 0, 0.1)
    ), url("../img/imus_bg.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center center;
  background-size: cover;
 */
     overflow-x: hidden !important;
 }
 .fontStyle{
  font-family: 'Poppins', sans-serif;

}

 .box {
    display: table;
    width: 100%;
    height: 100vh;
    background: white;
    
}
.box-cell {
    display: table-cell;
    vertical-align: middle;
    
}
.login-box-cell {
    width: 450px;
    margin: auto;
    
    padding: 15px; 
}
.login-panel {
    box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2);
    padding: 30px 35px 10px 35px; /* top, right, down, left */
    border-radius: 6px;
}
.alertClass {
   width: 100% !important;
   padding: -15px !important;
}

@media (min-width:320px)  { /* smartphones, portrait iPhone, portrait 480x320 phones (Android) */ }
@media (min-width:480px)  { /* smartphones, Android phones, landscape iPhone */ }
@media (min-width:600px)  { /* portrait tablets, portrait iPad, e-readers (Nook/Kindle), landscape 800x480 phones (Android) */ }
@media (min-width:801px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ }
@media (max-width:1025px) { .d-none-pic {display:none;} /* big landscape tablets, laptops, and desktops */ }
@media (min-width:1281px) { /* hi-res laptops and desktops */ }
</style>
</head>
<body>
<div class="row h-100 fontStyle">
    <div class="col-lg-6" style="background-color: white;">
        <div class="box">
            <div class="box-cell">  
            <a href="../user/index.php"><button class="btn btn-primary" style="margin-left: 20px;"><span class="glyphicon glyphicon-chevron-left"></span> Back</button></a>
                    
                <div class="login-box-cell">
                    <div class="login-panel">
                        <div class="row text-center">
                            <img src="../img/icon2.png" width="100"/>
                    </div>
                    <br>
                    <h6 class="text-center lead" style="font-size: 18px; font-weight: bold;">Imus Institute of Science and Technology</h6>
                    
                    <h6 class="text-center lead" style="font-size: 15px;">Admin Portal</h6>
                        <form action="" method="post">
                        <div class="form-group-sm">
                            <h6 for="username" style="font-size: 14px;">Username:</h6>
                            <input type="text" name="username"  class="form-control form-control-sm mb-4" maxlength="11" required>
                        </div>
                        <div class="form-group-sm">
                            <h6 for="password" style="font-size: 14px;">Password:</h6>
                            <input type="password" name="password"  class="form-control form-control-sm" maxlength="11" required>
                        </div>
                          <div class="form-group-sm mb-4" style="margin-top: 14px;">
                        <span><input type="submit" class="btn btn-block btn-primary" style="border-radius: 50px; " value="LOGIN" name="login"></span>
                        </form>
               

                        
                        </div>
                      
                        <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 14px;">
                        
                       </div>
                        <?php 
                            if(isset($_POST["login"]))
                            {
                                // variable naman to para ma-validate niya yung username at password na iinput mo sa page
                                $count = 0;    
                                $username = $_POST['username'];  // So ito naman, mag-dedeclare ka ng variable $username para sa $_POST['username']  
                                $password = $_POST['password'];  // same lang din dito

                                //dito, mag-eexecute ka na ng query.
                                //so first, magdedeclare ka muna ng variable para sa i-eexecute mong query. so, $res ang name ng variable mo.
                                //so pwede mo na gamitin yung $res given sa example sa baba.
                                // So, icacall mo yung $db kasi ito yung variable para ma-connect siya sa database. Nasa connection.php yan.
                                // So, mysqli_query($db, then sa loob nito yung query mo. "SELECT * FROM kung anong table name mo")
                                // WHERE kung saan mo naman siya i-eexecute
                                $res = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials WHERE username='$username' && password='$password'");

                                // so based dito, yung mysqli_num_rows nagrereturn siya ng number ng rows sa magiging result ng query mo
                                $count = mysqli_num_rows($res); 
                                                                
                                // so if yung $count nya is 0 or wala yung username or password nya sa table, i-eexecute nya yung laman ng echo
                                // which is yung alert na mali yung nilagay nyang input                              
                                if($count == 0) { 
                                    
                                echo '<div class="alert alert-danger alertClass">
                                    
                                <center>
                              <!--  <button type="button" class="close" data-dismiss="alert">&times;</button> -->
                                
                                <strong>Invalid</strong> Username Or Password.
                                </center>
                                    </div> ';

                                }
                                // so kapag tama naman yung nilagay nya, i-eexecute nya ulit yung nasa loob ng echo 
                                // which is mapupunta na siya sa index.php na page.
                                else { 
                                    $_SESSION["username"] = $username;
                                    
                                echo '<script>
                                        window.location="index.php";
                                    </script> ';
                                
                                }
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 hide-lg d-none-pic">
        <img src="../img/imus_bg.png"  style="height: 100vh !important; zoom: 100%;"/>
    </div>
</div>
</body>
</html>

<script>
/* Optional but not required 
$("#alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $("#alert-success").slideUp(500);
});
$("#alert-danger").fadeTo(5000, 500).slideUp(500, function(){
    $("#alert-danger").slideUp(500);
});
*/
</script>