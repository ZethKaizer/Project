<?php

include('connection.php');

if (isset($_POST['Event'][0]) && isset($_POST['Event'][1]) && isset($_POST['Event'][2])){

	$id = $_POST['Event'][0];
	$start = $_POST['Event'][1];
	$end = $_POST['Event'][2];

	$sql = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET start = '$start', end = '$end' WHERE id = $id ");

	//$res = mysqli_query($conn, $sql);


}
//header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
