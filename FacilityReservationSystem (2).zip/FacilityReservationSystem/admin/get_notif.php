

<?php 
session_start();
include('connection.php');
include('tags.php');
//$username = $_SESSION['username'];
//$query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation");
$vehicle_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE status='Pending' AND status_notif='Unread'");
$gymnasium_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE status='Pending' AND status_notif='Unread'");
$otherfacilities_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE status='Pending' AND status_notif='Unread'");

echo mysqli_num_rows($vehicle_query) + mysqli_num_rows($gymnasium_query)  + mysqli_num_rows($otherfacilities_query) ;

$vehicle_count_query = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_vehicle_reservation WHERE status='Pending' AND status_notif='Unread'");
$vehicle_row = mysqli_fetch_array($vehicle_count_query);


$otherfacilities_count_query = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_otherfacilities_reservation WHERE status='Pending' AND status_notif='Unread'");
$otherfacilities_row = mysqli_fetch_array($otherfacilities_count_query);

$gymnasium_count_query = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_gymnasium_reservation WHERE status='Pending' AND status_notif='Unread'");
$gymnasiumfacilities_row = mysqli_fetch_array($gymnasium_count_query);


$vehicle_total = $vehicle_row[0] + $otherfacilities_row[0] + $gymnasiumfacilities_row[0];


// counts notification
if(mysqli_num_rows($vehicle_query) + mysqli_num_rows($gymnasium_query) + mysqli_num_rows($otherfacilities_query) == 1){
    echo '<div id="alert_popover">
    <div id="inner-message" class="alert alert-info" >
        You have '. $vehicle_total .' new notification!
    </div>
    </div>';
}
elseif(mysqli_num_rows($vehicle_query) + mysqli_num_rows($gymnasium_query) + mysqli_num_rows($otherfacilities_query) > 0){
    echo '<div id="alert_popover">
    <div id="inner-message" class="alert alert-info">
        You have '. $vehicle_total .' new notifications!
    </div>
    </div>';
}




?>