<?php 
include('connection.php');
$id=$_GET["id"];
mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET status='Reserved By School' WHERE id=$id");

?>

<script>
	window.location="vehicle_reservation.php";
</script>