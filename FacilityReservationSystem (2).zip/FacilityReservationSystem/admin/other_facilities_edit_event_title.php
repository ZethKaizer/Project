<?php
include('connection.php');

if (isset($_POST['delete']) && isset($_POST['id'])){	
	$id = $_POST['id'];
	$title = $_POST['title'];
	$username = $_POST['username'];
	$color = $_POST['color'];	
//	$deleteQuery = mysqli_query($conn, "DELETE FROM tbl_otherfacilities_reservation WHERE id = $id");
//	$res = mysqli_query($conn, $deleteQuery);	
$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', username='$username', color = '#5a0200', status = 'Deleted', status_notif='Unread' WHERE id = $id");

}

elseif (isset($_POST['title']) && isset($_POST['color']) && isset($_POST['id'])){
	$id = $_POST['id'];
	$title = $_POST['title'];
	$username = $_POST['username'];
	$color = $_POST['color'];	
	if($color=='#10538c'){ //dark blue
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', username='$username', color = '$color', status = 'Reserved By School', status_notif='Unread' WHERE id = $id");
	}
	elseif($color=='#147b20'){ //green
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', username='$username', color = '$color', status = 'Reserved By User', status_notif='Unread' WHERE id = $id");
	}
	else{
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', username='$username', color = '$color', status = 'Paid by User', status_notif='Unread' WHERE id = $id");
	}
	//$res = mysqli_query($updateQuery, $sql);
}
header('Location: other_facilities_reservation.php');	
?>
