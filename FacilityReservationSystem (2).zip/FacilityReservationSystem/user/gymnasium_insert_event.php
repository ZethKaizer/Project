<?php

include('connection.php');
//echo $_POST['title'];
if(isset($_POST['insert'])){
	
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = $_POST['color'];
	$name = $_POST['name'];
	$username = $_POST['username'];
	$contact_number = $_POST['contact_number'];
	$email = $_POST['email'];
	$status = $_POST['status'];
	
	$paid_by_user = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#a72d2a'");
	$reserved_by_school = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
	


	if(mysqli_num_rows($paid_by_user) > 0) {
	//	echo '<div class="alert alert-danger">It seems this date paid by others</div>';
		header('Location: gymnasium_already_reserved.php');
	}
	elseif(mysqli_num_rows($reserved_by_school) > 0){
		header('Location: gymnasium_already_reserved_school.php');
	}
	else{
		
	$sql_insert = mysqli_query($conn, "INSERT INTO tbl_gymnasium_reservation(title, start, end, color, name, username, contact_number, email, status, status_notif) 
	values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Pending', 'Unread')");
	//$req = $bdd->prepare($sql);
	//$req->execute();
//values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Reserved')");
header('Location: gymnasium_inserted.php');

	echo $sql;
	
//	$res = mysqli_query($conn, $sql);

}
}
	
?>
