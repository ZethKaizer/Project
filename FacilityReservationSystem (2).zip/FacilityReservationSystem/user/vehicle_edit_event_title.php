<?php
session_start();
include('connection.php');

$sql_date_between = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
	

if (isset($_POST['delete']) && isset($_POST['id'])){	
	$id = $_POST['id'];
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = $_POST['color'];
	$name = $_POST['name'];
	$username = $_POST['username'];
	$contact_number = $_POST['contact_number'];
	$email = $_POST['email'];
	$status = $_POST['status'];

	$sql_insert = mysqli_query($conn, "INSERT INTO tbl_vehicle_reservation(title, start, end, color, name, username, contact_number, email, status, status_notif) 
	values ('$title', '$start', '$end', '$color', '$name', '$username', '$contact_number', '$email', 'Deleted', 'Unread')");
	

	if($sql_insert){
	$deleteQuery = mysqli_query($conn, "DELETE FROM tbl_vehicle_reservation WHERE id = $id");
	}

//	$res = mysqli_query($conn, $deleteQuery);	
}



elseif (isset($_POST['title']) && isset($_POST['color']) && isset($_POST['id'])){
	
	if($color=='#10538c'){ //dark blue
		$updateQuery = mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET title = '$title', color = '$color', status = 'Reserved By School' WHERE id = $id");
	}
	elseif($color=='#147b20'){ //green
		$updateQuery = mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET title = '$title', color = '$color', status = 'Reserved By User' WHERE id = $id");
	}
	else{
		$updateQuery = mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET title = '$title', color = '$color', status = 'Reserved and Paid By User' WHERE id = $id");
	}

	//$res = mysqli_query($updateQuery, $sql);

	}
header('Location: vehicle_reservation.php');	
?>
