<?php 
session_start();
include('connection.php');
include('header.php');
include('tags.php');

?>

<body>

<div class="container mt-5">
    <div class="row">
    <h1 class='text-center fontStyle'>Contacts</h1>
        <div class="well well-lg fontStyle">
            <p>1. Insert Text</p>
            <p>2. Insert Text</p>
            <p>3. Insert Text</p>
            <p>4. Insert Text</p>
            <p>5. Insert Text</p>
        </div>
    </div>
</div>
</body>