<?php

include('connection.php');
$sql_date_between = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
	
	if(mysqli_num_rows($sql_date_between) > 0) {
		echo '<div class="alert alert-danger">It seems this date reserved by others</div>';
	}
	else{
if (isset($_POST['Event'][0]) && isset($_POST['Event'][1]) && isset($_POST['Event'][2])){

	$id = $_POST['Event'][0];
	$start = $_POST['Event'][1];
	$end = $_POST['Event'][2];

	$sql = mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET start = '$start', end = '$end' WHERE id = $id ");

	//$res = mysqli_query($conn, $sql);


}
	}
//header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
