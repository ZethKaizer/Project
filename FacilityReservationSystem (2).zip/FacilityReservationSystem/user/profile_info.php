<?php 
session_start();
  include('connection.php');
  include('tags.php');
 
  $username_session = $_SESSION['username']; //getting information of the user

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<?php
  include('header.php');
  
?>

 


<div class="container bg-white fontStyle"  style="margin-top: 150px;">

<?php 
     if(isset($_POST['updateData'])){    
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $contact_number = $_POST['contact_number'];    
        $query = mysqli_query($conn, "UPDATE tbl_user_credentials SET last_name='$last_name', first_name='$first_name', middle_name='$middle_name', 
        username='$username_session', password='$password', email='$email', contact_number='$contact_number' WHERE username='$username'");
        if($query) 
        {
            echo '<div class="alert alert-success" style="width: 100% !important;"  style="margin-top: 150px;">
                    <center>
                        Successfully Updated
                    </center>
                  </div>';
        }
     }
?> 
<h2 class="text-center mt-3 font-weight-bold">TRANSACTION HISTORY</h2>
  
  <div class="row p-3">
  <?php 

  $vehicle_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE username='$username_session'");
  $gymnasium_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE username='$username_session'");
  $otherfacilities_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE username='$username_session'");
     
?> 
<button class="btn btn-primary btn-sm mr-2 mr-auto" data-toggle="modal" data-target="#addBtn">Update Information</button>            
<!--
<button class="btn btn-light btn-sm ">Filter By Date:</button>            
    <form action="" method="post" style="margin-block-end: 0 !important; display: inherit;">
    <input class="form-control timepicker" name="date_reserved">
    <input type="submit" name="filter_date" value="Filter" class="btn btn-primary btn-sm mr-auto">            
</form>
-->
  </div>
    <!--
            <button class="btn btn-light  btn-sm ml-2">To Date:</button>            
            <div class="input-group" style="width: 20%;">
    <div class="input-group-prepend">
      <button type="button" id="toggle" class="input-group-text">
        <i class="fa fa-calendar-alt"></i>
      </button>
    </div>
    <input class="form-control timepicker"  name="date_reserved">
    </div>
-->

<h4 class="text-center">Gymnasium</h4>
<div class="table-responsive">  
  <table class="table table-bordered table-striped mt-3 ">
    <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>Vehicle</th>
      <th>Name</th>
      <th>Username</th>
      <th>Contact Number</th>
      <th>Email</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Status</th>
    </tr>
      <?php
      //sif($row['status']=='Pending'){
        if(mysqli_num_rows($gymnasium_query) > 0) {
          while($row = mysqli_fetch_array($gymnasium_query)){ 
            if($row['status']=='Pending'){
           echo   '
              <tr style="background: #f0f0f0;">
                <td> '.$row["title"].' </td>                     
                <td> '.$row["name"].' </td>
                <td> '.$row["username"].' </td>
                <td> '.$row["contact_number"].'</td>           
                <td> '.$row["email"].' </td>
                <td> '.$row["start"].' </td>
                <td> '.$row["end"].' </td>
                <td> '.$row["status"] .' </td>
              </tr>
              ';
            }
            else{
          echo 
          
          '
          <tr>
            <td> '.$row["title"].' </td>                     
            <td> '.$row["name"].' </td>
            <td> '.$row["username"].' </td>
            <td> '.$row["contact_number"].'</td>           
            <td> '.$row["email"].' </td>
            <td> '.$row["start"].' </td>
            <td> '.$row["end"].' </td>
            <td> '.$row["status"] .' </td>
          </tr>
          ';
          }
        }
        }

      //}
      else {
        echo "<td colspan='11' class='text-center'>Nothing to Display.</td>
      ";
      }
      ?>
  </table>
</div>

<h4 class="text-center">Other Facilities</h4>

<div class="table-responsive">  
  <table class="table table-bordered table-striped mt-3 ">
    <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>Vehicle</th>
      <th>Name</th>
      <th>Username</th>
      <th>Contact Number</th>
      <th>Email</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Status</th>
    </tr>
      <?php
      if(mysqli_num_rows($otherfacilities_query) > 0) {
        while($row = mysqli_fetch_array($otherfacilities_query)){ 
          if($row['status']=='Pending'){
         echo   '
            <tr style="background: #f0f0f0;">
              <td> '.$row["title"].' </td>                     
              <td> '.$row["name"].' </td>
              <td> '.$row["username"].' </td>
              <td> '.$row["contact_number"].'</td>           
              <td> '.$row["email"].' </td>
              <td> '.$row["start"].' </td>
              <td> '.$row["end"].' </td>
              <td> '.$row["status"] .' </td>
            </tr>
            ';
          }
          else{
        echo 
        
        '
        <tr>
          <td> '.$row["title"].' </td>                     
          <td> '.$row["name"].' </td>
          <td> '.$row["username"].' </td>
          <td> '.$row["contact_number"].'</td>           
          <td> '.$row["email"].' </td>
          <td> '.$row["start"].' </td>
          <td> '.$row["end"].' </td>
          <td> '.$row["status"] .' </td>
        </tr>
        ';
        }
      }
      }

      //}
      else {
        echo "<td colspan='11' class='text-center'>Nothing to Display.</td>
      ";
      }
      ?>
  </table>
</div>





<h4 class="text-center">Vehicles</h4>
<div class="table-responsive">  
  <table class="table table-bordered table-striped mt-3 ">
    <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>Vehicle</th>
      <th>Name</th>
      <th>Username</th>
      <th>Contact Number</th>
      <th>Email</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Status</th>
    </tr>
      <?php
      //sif($row['status']=='Pending'){
        if(mysqli_num_rows($vehicle_query) > 0) {
          while($row = mysqli_fetch_array($vehicle_query)){ 
            if($row['status']=='Pending'){
           echo   '
              <tr style="background: #f0f0f0;">
                <td> '.$row["title"].' </td>                     
                <td> '.$row["name"].' </td>
                <td> '.$row["username"].' </td>
                <td> '.$row["contact_number"].'</td>           
                <td> '.$row["email"].' </td>
                <td> '.$row["start"].' </td>
                <td> '.$row["end"].' </td>
                <td> '.$row["status"] .' </td>
              </tr>
              ';
            }
            else{
          echo 
          
          '
          <tr>
            <td> '.$row["title"].' </td>                     
            <td> '.$row["name"].' </td>
            <td> '.$row["username"].' </td>
            <td> '.$row["contact_number"].'</td>           
            <td> '.$row["email"].' </td>
            <td> '.$row["start"].' </td>
            <td> '.$row["end"].' </td>
            <td> '.$row["status"] .' </td>
          </tr>
          ';
          }
        }
        }

      //}
      else {
        echo "<td colspan='11' class='text-center'>Nothing to Display.</td>
      ";
      }
      ?>
  </table>
</div>




  </div>
</div>
 

<!-- Add Modal -->
<div id="addBtn" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">                        
        <h4 class="modal-title mx-auto">
         Update Information:</h4>
      </div>     
      <div class="modal-body">
      <?php 
      if(!isset($_SESSION['username'])) {
     echo ' 
     <p class="text-center">In order to use this part of the reservation system, you must log in first.</p>
        
        <p class="text-center"><a href="login2.php">LOG IN NOW.</a></p>';
      }
      else{
        $infoUser = mysqli_query($conn, "SELECT * from tbl_user_credentials where username = '$username_session'");
        while($row = mysqli_fetch_array($infoUser)) { 
        echo '
    <form action="" method="post">
        <div class="form-group">
            <label for="usr">Last Name:</label>
                  <input type="text" class="form-control form-control-sm" name="last_name" id="last_name" required value="'.$row['last_name'].'">
          </div>
        
          <div class="form-group">
            <label for="usr">First Name:</label>
                  <input type="text" class="form-control form-control-sm" name="first_name" id="first_name" required value="'.$row['first_name'].'">
          </div>

          <div class="form-group">
            <label for="usr">Middle Name:</label>
                  <input type="text" class="form-control form-control-sm" name="middle_name" id="middle_name" required value="'.$row['middle_name'].'">
          </div>

          <div class="form-group">
            <label for="usr">Username:</label>
                  <input type="text" class="form-control form-control-sm" name="username" readonly id="username" required value="'.$row['username'].'">
          </div>
      
          <div class="form-group">
            <label for="usr">Password:</label>
                  <input type="password" class="form-control form-control-sm" name="password" id="password" required value="'.$row['password'].'">
          </div>
          
          <div class="form-group">
            <label for="usr">Contact Number:</label>
                  <input type="text" class="form-control form-control-sm" name="contact_number" id="contact_number" required value="'.$row['contact_number'].'">
          </div>
          
          <div class="form-group">
            <label for="usr">Email:</label>
                  <input type="text" class="form-control form-control-sm" name="email" id="email" required value="'.$row['email'].'">
          </div>
          
        <div class="form-group float-right">
          <button type="submit" name="updateData" class="btn btn-primary btn-sm">Update</button>
          <button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Close</button>     
        </div>           
    </form>
';
      }
    }
      ?>
      </div>    

    
    </div>  

  </div>
</div> 
</div>
<!-- End of Add Modal --> 

</body>
</html>
