
<?php
include('connection.php');
include('tags.php');
session_start();

//$username_validation = mysqli_query($conn, "SELECT FROM tbl_gymnasium_reservation WHERE username='$username_session' "); //getting information of the user

if(isset($_SESSION['username'])){
	$username = $_SESSION['username']; //getting information of the user
}

if(!isset($_SESSION['username']) OR isset($_POST['all_reservation'])){
	$query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE NOT status='Pending'");
	$events = $query; /* To fetch array inside jquery script foreach $events */

}
elseif(isset($_POST['my_reservation'])){
$subquery = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE username='$username' "); //getting information of the user
$events = $subquery; /* To fetch array inside jquery script foreach $events */
}

else{
	$subquerys = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE NOT status='Deleted' "); //getting information of the user
	$events = $subquerys; /* To fetch array inside jquery script foreach $events */
}

/*
$subquerys = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation"); //getting information of the user
	$events = $subquerys;
	*/
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>Facility Reservation System</title>
  

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
	#calendar {
		max-width: 800px;
	}
	.col-centered{
		float: none;
		margin: 0 auto;
	}

	/* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 12px;
  top: 4;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 14px;
  width: 14px;
  left: 4px;
  bottom: 3px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(17px);
  -ms-transform: translateX(17px);
  transform: translateX(17px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.checkbox label {
	padding-left: 0px !important;
}

    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
	<?php 
		include('header.php');
	?> 

    <!-- Page Content -->
    <div class="container fontStyle" style="margin-top: 50px;">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Gymnasium Reservation</h1>
				<p style="color:#10538c;">&#9724; Reserved by School &nbsp;  
					<span style="color: #147b20;">&#9724; Reserved by User &nbsp; </span>
					<span style="color: #a72d2a;">&#9724; Reserved and Paid by User</span>
				</p>	
			
				
				<script>
		/*
$(document).ready(function(){
    $("#form").on("change", "input:checkbox", function(){
        $("#form").submit();
    });
});
*/

$(document).ready(function(){
        $("#newcheck").change(function() { 
			 if($(this).is(":checked")) { 
				$(this).siblings('label').html('Show your reservation'); 
                $.ajax({
					async: true,				
                    url: 'gymnasium_checked.php',
                    type: 'POST',
					data: {check_query: $(this).is('1')},
					success: function (data) {					
                $("#calendar").html(data);
            }
                });
            } else {
				$(this).siblings('label').html('Show all reservation');
                $.ajax({
					
					async: true,
                    url: 'gymnasium_unchecked.php',
                    type: 'POST',
					data: {check_query: $(this).is('0')},
					success: function (data) {
                $("#calendar").html(data);
            }
                });
            }
        }); 
    });

</script>
<form id="form" method="post" action="">
	<div class="checkbox">
	<!--
		<label class="switch">
			<input type="checkbox" name="check_query" id="newcheck" checked>
			<span class="slider round"></span>
			
		</label>
		
		<label for="newcheck">Show All Reservation</label>
		-->
		
		<input id="newcheck" type="checkbox" checked><label for="newcheck">Show your reservation</label>
	</div>
</form>
		
			





				</div>
				<!-- Once the user logged in, these buttons show -->
				<?php
				if(isset($_SESSION['username'])){
				echo '
				<!--
				<form action="" method="post">
				<button class="btn btn-primary" type="submit" style="margin-top: 5px;" name="all_reservation">Check availability</button>
				<button class="btn btn-primary" type="submit" style="margin-top: 5px;" name="my_reservation">My Reservation</button>
				</form>
				-->
				';
				}
				?>
				
			<br>	<!-- To show calendar -->
                <div id="calendar" class="col-centered"></div>
				<?php 
				/*
				if(!isset($_SESSION['username'])){
				echo '<button href="#" class="btn btn-primary back-to-top" data-toggle="modal" data-target="#howToReserve" role="button">How to reserve?</button>';
				}
				else{
					echo '<button href="#" class="btn btn-primary back-to-top" data-toggle="modal" data-target="#howToReserve" role="button">How to reserve?</button>';
			
				}
				*/
				include('how-to-reserve.php');
				?>
            </div>
        </div>
		<?php 
		if(isset($_POST['insert'])){
		echo '
		';
		}
		?>
        <!-- /.row -->
		


        <!-- Modal footer -->
        <!--
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      -->
    


		<!-- Modal -->
		<div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="zoom: 90%;">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="" method="POST" action="gymnasium_insert_event.php"> <!-- form-horizontal class -->
			
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Gymnasium Registration</h4>
			  </div>
			
			  <div class="modal-body">	
			  <?php 
      if(!isset($_SESSION['username'])) {
     echo ' 
     <p class="text-center">In order to use this part of the reservation system, you must log in first.</p>
        
        <p class="text-center"><a href="login2.php">LOG IN NOW.</a></p>';
	  }
	  else{
		  echo 
		  '<div class="row">
		  <div class="col-sm-6">
		  <div class="form-group">
			<label for="title" class="control-label">Gymnasium</label>					
			<select class="custom-select custom-select-sm form-control" id="title" name="title" required>
			<option selected disabled>Choose Gymnasium:</option>
			<option value="Gymnasium">Gymnasium</option>
				
					'; 
					/*
					$res = mysqli_query($conn, "SELECT gymnasium from tbl_gymnasium");
					while($row = mysqli_fetch_array($res)) { 
						echo "<option> ";
						echo $row["gymnasium"]; 
						echo "</option> ";
					
				}
				*/
				echo '</select>
			</div>';
		
		$infoUser = mysqli_query($conn, "SELECT * from tbl_user_credentials where username = '$username'");
        while($row = mysqli_fetch_array($infoUser)) { 
			echo '
			<div class="form-group">
			<label for="color" class="control-label">Status</label>	
			  <select name="color" readonly class="form-control" id="color">
			<!--
			  <option value="">Choose</option>
				  <option style="color:#FF0000;" value="#FF0000">&#9724; Red</option>
				  <option style="color:#000;" value="#000">&#9724; Black</option> 
				  <option style="color:#0071c5;" value="#0071c5">&#9724; Dark blue</option>
				  <option style="color:#008000;" value="#008000">&#9724; Green</option>		
				  -->				  
				  <option style="color:#147b20;" readonly value="#147b20">&#9724; Pending</option>
				</select>
		  </div>
		  <div class="form-group">
			<label for="start" class="control-label">Start date</label>
			  <input type="text" name="start" class="form-control" id="start" readonly>
		  </div>
		  <div class="form-group">
			<label for="end" class="control-label">End date</label>	
			  <input type="text" name="end" class="form-control" id="end" readonly>
		  </div>	
		  
			</div>
			<div class="col-sm-6">
				  <div class="form-group">
					<label for="name" class="control-label">Name</label>
					  <input type="text" readonly name="name" value="'.$row['first_name']. ' ' .$row['middle_name']. ' ' .$row['last_name'].'" class="form-control" id="name" placeholder="Name">
				  </div>
				  
				
				  <div class="form-group">
					<label for="username" class="control-label">Username</label>
						<input type="text" readonly class="form-control form-control-sm" name="username" required value="'.$row['username'].'">	
				  </div>

				  <div class="form-group">
					<label for="contact_number" class="control-label">Contact Number</label>
						<input type="text" readonly class="form-control form-control-sm" name="contact_number" required value="'.$row['contact_number'].'">	
				  </div>

				  <div class="form-group">
					<label for="email" class="control-label">Email</label>	
					<input type="text" readonly class="form-control form-control-sm" name="email" required value="'.$row['email'].'">
				  </div>
				</div>
				 	</div>	  
	
				</div>
			  
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary" name="insert">Save changes</button>
			  </div>

			


			  '; } } ?>
			</form>
			</div>
		  </div>
		</div>
		
		
			  	  <?php 
      if(!isset($_SESSION['username'])) {
     echo ' 
    ';
	  }
	  else{
			?>	
		<!-- Modal -->
		<div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="" method="POST" action="gymnasium_edit_event_title.php">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Edit Event</h4>
			  </div>
			  <div class="modal-body">
			
				  <div class="form-group">
					<label for="title" class="control-label">Gymnasium</label>	
					<select class="custom-select custom-select-sm form-control" id="title" name="title" required>
                  <option selected disabled>Choose Gymnasium:</option>
				  <option value="Gymnasium">Gymnasium</option>
					<?php 
					/*
                      $res = mysqli_query($conn, "SELECT gymnasium from tbl_gymnasium");
                      while($row = mysqli_fetch_array($res)) { 
                          echo "<option> ";
						  echo $row["gymnasium"]; 
					      echo "</option> ";
					  }
					  */
					  
                    ?>
                </select>
				  </div>
				  
				  <div class="form-group">
					<label for="color" class="control-label">Status</label>
					  <select name="color" class="form-control" id="color" readonly>
					  <!--
						  <option value="">Choose</option>
						  <option style="color:#0071c5;" value="#0071c5">&#9724; Dark blue</option>
						  <option style="color:#008000;" value="#008000">&#9724; Green</option>
						  <option style="color:#FF0000;" value="#FF0000">&#9724; Red</option>
						  <option style="color:#000;" value="#000">&#9724; Black</option>
						  -->						  
						  <option style="color:#a72d2a;" value="#a72d2a">&#9724; Reserved and Paid by User</option>
						</select>
				  </div>
				    <div class="form-group"> 
						  <div class="checkbox"  style="margin-left: 20px;">
							<label class="text-danger"><input type="checkbox"  name="delete"> Delete event</label>
						  </div>
					</div>
				  
				  <input type="hidden" name="id" class="form-control" id="id">				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			  </div>
	  <?php } ?>
			</form>
			</div>
		  </div>
		</div>

    </div>
    <!-- /.container -->

 <!-- jQuery Version 1.11.1 -->
 
</body>
<?php
 if(isset($_SESSION['username'])){
 $show_all = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE username='$username'"); //getting information of the user              				
 }
include('gymnasium_calendar.php');
 
 ?>
 
<script>
/*
	$(document).ready(function(){
		function load_last_notification(){
			$.ajax({
				url: "popup.php",
				method: "POST",
				success:function(data){
					$('.content').html(data);
				}
			})
		}
	});
	*/
/*
$(document).ready(function(){
  $("#changestate").click(function(){
    $("$show_all").show();
  });
});
*/


</script>
<?php 

?>

</html>
