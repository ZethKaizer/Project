<?php 
session_start();
include('connection.php');
include('tags.php');
$username = $_SESSION['username'];
//$query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation");
$vehicle_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE status='Paid by User' AND username='$username' AND status_notif='Unread'");
$gymnasium_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE status='Paid by User' AND username='$username' AND status_notif='Unread'");
$otherfacilities_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE status='Paid by User' AND username='$username' AND status_notif='Unread'");
$vehicle_deleted_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE status='Deleted' AND username='$username' AND status_notif='Unread'");
$otherfacilities_deleted_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE status='Deleted' AND username='$username' AND status_notif='Unread'");
$gymnasium_deleted_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE status='Deleted' AND username='$username' AND status_notif='Unread'");

echo mysqli_num_rows($vehicle_query) + mysqli_num_rows($gymnasium_query) + mysqli_num_rows($otherfacilities_query)
+ mysqli_num_rows($vehicle_deleted_query) + mysqli_num_rows($otherfacilities_deleted_query) + mysqli_num_rows($gymnasium_deleted_query) ;

?>