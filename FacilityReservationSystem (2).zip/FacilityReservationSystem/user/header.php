<style>


body {
    font-family: 'Poppins', sans-serif;
}

.fontStyle{
  font-family: 'Poppins', sans-serif;

}

.navstyle{
  font-family: 'Poppins', sans-serif;
  box-shadow: 0px 5px 18px 1px rgba(0,0,0,0.10);
  background: white;
  padding: 25px;

}
.navbar-nav li a{
  color: black;
  font-weight: normal;
  font-weight: 300;
}

.navbar-nav li a:hover{
  color: blue;
  background: white !important;
}

.btnLogin{
  font-weight: 700 !important;
    border-radius: 25px;
    padding-left: 20px;
    padding-right: 20px;
    line-height: 30px;
    color: #ffffff;
    
    background-color: #0000d0;   /* #7d1eff; */
    text-transform: uppercase;
    transition: .3s all ease-in-out;

}
.btnLogin:hover{
  background-color: #232c85;   /* #7d1eff; */
  color: white;
  transition: .3s all ease-in-out;
}

.align-center {
  float: none;
    margin: 0 auto;
}

.navbar-toggle{
  background-color: blue;
}

.navbar-toggle .icon-bar{
  background: white;
}

.mt-5 {
  margin-top: 115px;
}
/*
.fade-scale {
  transform: scale(0);
  opacity: 0;
  -webkit-transition: all .25s linear;
  -o-transition: all .25s linear;
  transition: all .25s linear;
}

.fade-scale.in {
  opacity: 1;
  transform: scale(1);
}
*/

.dropdown:hover .dropdown-menu {
  display: block;
}

.hover-link:hover{
  color: blue !important;
}


.modal {
  text-align: center;
}

@media screen and (min-width: 768px) { 
  .modal:before {
    display: inline-block;
    vertical-align: middle;
    content: " ";
    height: 100%;
  }
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}


</style>  <!-- Navigation -->
<!--
<link rel="stylesheet" type="text/css" href="style.css">
-->

  <nav class="navbar navbar-fixed-top navstyle" role="navigation" >
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="#" title="Imus Institute of Science and Technology">
        <img style="max-width:100px; margin-top: -25px;"
        src="../img/icon2.png" width="75">
    </a>
       
                <a class="navbar-brand" href="#"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1">
            
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gymnasium</a>
                          <ul class="dropdown-menu hover-link" role="menu">
                          <li class="dropdown-header">Gymnasium</li>
                              <li><a href="gymnasium_reservation.php" class="hover-link">Calendar</a></li>
                              <li><a href="gymnasium_gallery.php" class="hover-link">Gallery</a></li>
                              <li><a href="gymnasium_rules.php" class="hover-link">Rules</a></li>
                          </ul>
                    </li>
                    <li class="dropdown">
                        <a href="gymnasium_reservation.php" class="dropdown-toggle" data-toggle="dropdown">Other Facilities</a>
                          <ul class="dropdown-menu hover-link" role="menu">
                          <li class="dropdown-header">Other Facilities</li>
                              <li><a href="other_facilities_reservation.php" class="hover-link">Calendar</a></li>
                              <li><a href="other_facilities_gallery.php" class="hover-link">Gallery</a></li>
                              <li><a href="other_facilities_rules.php" class="hover-link">Rules</a></li>
                          </ul>
                    </li>
                    <li class="dropdown">
                        <a href="gymnasium_reservation.php" class="dropdown-toggle" data-toggle="dropdown">Vehicles</a>
                          <ul class="dropdown-menu hover-link" role="menu">
                          <li class="dropdown-header">Vehicles</li>
                              <li><a href="vehicle_reservation.php" class="hover-link">Calendar</a></li>
                              <li><a href="vehicle_gallery.php" class="hover-link">Gallery</a></li>
                              <li><a href="vehicle_rules.php" class="hover-link">Rules</a></li>
                          </ul>
                    </li>
                    <li>
                        <a href="contacts.php">Contacts</a>
                    </li>
                    

                </ul>
                    
                <ul class="nav navbar-nav navbar-right">
                <?php  
                    if(!isset($_SESSION['username'])) {
                    echo'
                        <a href="#" data-toggle="modal" data-target="#myModal">
                        <button class="btn btnLogin">Login</button></a>
                    <!--
                    <li>
                        <a href="registration.php">Register</a>
                    </li>
                    -->
                    ';
                    }
                    else{
                            // $count = 0;
                             $username_session = $_SESSION['username'];
                             $res = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation WHERE status='Reserved and Paid by User' AND username='$username_session' ORDER BY id DESC");
                           //  $data = mysqli_fetch_array($rescount);
                             echo'
                             <li>
                             <a href="profile_info.php">Welcome, '.$_SESSION["username"].'</a>
                             </li> 
                             <li class="dropdown" >
                                 <button type="button" class="dropdown-toggle btn navbar-btn" data-toggle="dropdown"style="background-color:#337ab7; !important; border-radius: 30px;" > 
                                 <span class="glyphicon glyphicon-bell" style="color: white;"> </span> <span class="badge" style="background:#337ab7;" id="notif_count"> 0 </span></button>
                                 <ul class="dropdown-menu" style="overflow-y: auto; height: 300px;" > '; // style="overflow-y: scroll; height: 350px;" 
                                
                                     ?>
                                     <li class='text-center' id='notif_dropdown'>
                                    </li>
                                 <?php
                                 
                              
                                 echo'
                                 </ul>
                             </li>
                             <li>
                         <a href="logout.php">Log Out</a>
                         </li> 
                             '; 
                         }
?>
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
     <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered modal-sm">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h5 class="modal-title text-center">Choose an User type</h5>
         <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <a href="../admin/login.php"  class="btn btn-primary btn-block">Login as Admin</a>
        
        <a href="../user/login.php"  class="btn btn-outline-primary btn-block">Login as User</a>
        </div>
        
        <!-- Modal footer -->
        <!--
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      -->
      </div>
    </div>
  </div>



<script>
/*
 $.ajax({
          url: href,
          dataType: 'css',
          success: function(){                  
                $('<link rel="stylesheet" type="text/css" href="'+href+'" />').appendTo("head");
                //your callback
            }
    });
*/
function loadDoc() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {   
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("notif_count").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "get_notif.php", true);
  xhttp.send();

    }, 1000);
    }
   loadDoc();



   function loadDropdown() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {   
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("notif_dropdown").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "show_notif.php", true);
  xhttp.send();

    }, 1000);
    }
   loadDropdown();

   
 
// when the user clicks notif bell, it executes read_notif.php which is update query
// update status_notif from 'Unread' to 'Read'  
$(document).ready(function(){
  $("button").hover(function(){
    $.ajax({url: "read_notif.php", success: function(result){
      $(".update_notif").html(result);
    }});
  });
});

</script>