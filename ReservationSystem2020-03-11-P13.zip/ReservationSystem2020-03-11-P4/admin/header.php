<?php 
session_start();
include('connection.php');
//include('tags.php');

//Ibig sabihin naman nito, hanggang hindi pa naseset yung session nya or hangga't hindi pa siya nakaka-log in
//Magreredirect siya sa 'login.php'. Ang purpose nito is para ma-secure nya yung data at hindi nya ma-access
// yung Functions hangga't di siya nakakapag-log in
if(!isset($_SESSION["username"])) { 
echo
'<script>
  window.location = "login.php";
</script>';
}
?>

<style>
 .rightColumn {
  display: inline;
  font-family: "Old English Text MT";
  font-size: 25px;
  color: white;
 }
 .nav-link:hover {
  text-decoration: underline !important;
 }
</style>

<div class="container-fluid" style="background-color: #232c85; color: white; ">
  <div class="row p-3 justify-content-center">
    <div class="justify-content-center">
      <img src="../img/icon2.png" width="80"/>
      <p class="ml-2 rightColumn">Imus Institute of Science and Technology</p>
    </div>
  </div>  

</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="background-color: #1d1d4d !important;">
<button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
 
 <!-- <a class="navbar-brand" href="#">Home</a> -->
 <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link active" href="index.php">HOME</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="manage_admin.php">MANAGE ACCOUNTS</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">GYMNASIUM</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">OTHER FACILITIES</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="reservation.php">VEHICLES</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="logout.php">LOG OUT</a>
    </li>
 
  </ul>
  </div>
</nav>
</div>