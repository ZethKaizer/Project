<?php 
  include('connection.php');
  include('tags.php');
  include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>

<?php 
  if(isset($_POST["addData"]))
     {
        $name = $_POST['name'];
        $username = $_POST['username'];
        $date_reserved = $_POST['date_reserved'];
        $contact_number = $_POST['contact_number'];
        $email = $_POST['email'];
        $vehicle = $_POST['vehicle'];
        $query_show = mysqli_query($db, "SELECT * FROM tbl_reservation");
        
        $query = mysqli_query($db, "SELECT * FROM tbl_reservation WHERE date_reserved='$date_reserved' AND status='Paid'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger" style="width: 100% !important;">
             <center>This date already reserved and paid. Please select other date.</center>
        </div>';
         }
         else 
         {    
              $query_insert = mysqli_query($db, "INSERT INTO tbl_reservation 
                  VALUES('', '$name', '$username', '$contact_number', 
                  '$email', '$vehicle', '$date_reserved', 'Reserved')");
                if($query_insert)
                {            
                echo ' <div class="alert alert-success" style="width: 100% !important;">
                <center> Registration successfully </center>
                       </div>';
                
            }
          }
      }
?>

 


    <!-- UPDATE QUERY [EDIT USER] -->  
               
<?php 
     if(isset($_POST['updateData'])){    
        $id = $_POST['update_id'];
        $name = $_POST['name'];
        $username = $_POST['username'];
        $contact_number = $_POST['contact_number'];
        $email = $_POST['email'];
        $vehicle = $_POST['vehicle'];
        $date_reserved = $_POST['date_reserved'];
        $query = mysqli_query($db, "UPDATE tbl_reservation SET name='$name', username='$username', contact_number='$contact_number', email='$email', vehicle='$vehicle', date_reserved='$date_reserved' WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
            Successfully Updated
            </center>
            </div>';
        }
     }
?>

     <!-- DELETE QUERY [DELETE USER] -->                    
<?php 
     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($db, "DELETE FROM tbl_admin_credentials WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
               Successfully Deleted
            </center>
            </div>';
        }
     }
?>  
<div class="container mw-100">
<h2 class="text-center mt-3 font-weight-bold">VEHICLE RESERVATION</h2>
 
  <div class="row mt-5 p-3">
  <?php 

if(isset($_POST['filter_date'])){
  $date_reserved = $_POST['date_reserved'];
  if($date_reserved == 0){
    $res = mysqli_query($db, "SELECT * FROM tbl_reservation order by ID desc");
  }
  else{
  $res = mysqli_query($db, "SELECT * FROM tbl_reservation WHERE date_reserved='$date_reserved'");
  }
}
else{
  $res = mysqli_query($db, "SELECT * FROM tbl_reservation order by ID desc");
  if($res){
    $rowcount = mysqli_num_rows($res);
  }
}
?> 

<button class="btn btn-primary btn-sm mr-2 mr-auto" data-toggle="modal" data-target="#addBtn">Add New Reservation</button>            

<button class="btn btn-light btn-sm ">Check Availability:</button>            
    <form action="" method="post" style="margin-block-end: 0 !important; display: inherit;">
    <input class="form-control timepicker" name="date_reserved">
    <input type="submit" name="filter_date" value="Filter" class="btn btn-primary btn-sm mr-auto">            
</form>
  </div>
    <!--
            <button class="btn btn-light  btn-sm ml-2">To Date:</button>            
            <div class="input-group" style="width: 20%;">
    <div class="input-group-prepend">
      <button type="button" id="toggle" class="input-group-text">
        <i class="fa fa-calendar-alt"></i>
      </button>
    </div>
    <input class="form-control timepicker"  name="date_reserved">
    </div>
-->
 
  <div class="table-responsive">
  
  <table class="table table-bordered table-striped mt-3 ">
                          <tr style="background: #d9d9d9 !important; text-align: center;">
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Contact Number</th>
                            <th>Email</th>
                            <th>Vehicle</th>
                            <th>Date Reserved</th>
                            <th colspan="2">Status</th>
                            <th>Edit</th>
                            <th>Delete</th>                                                               
                          </tr>
                          <?php 
                        if(mysqli_num_rows($res) > 0) {
                        
                        while($row = mysqli_fetch_array($res)){ ?>
                          <tr>
                            <td><?php echo $row["id"]; ?> </td>
                            <td><?php echo $row["name"]; ?> </td>
                            <td><?php echo $row["username"]; ?> </td>
                            <td><?php echo $row["contact_number"]; ?> </td>           
                            <td><?php echo $row["email"]; ?> </td>
                            <td><?php echo $row["vehicle"]; ?> </td>                     
                        <!--    <td><?php echo $row["plate_number"]; ?> </td>  -->                   
                            <td><?php echo $row["date_reserved"]; ?> </td>
                            <td><?php echo $row["status"]; ?> </td>  
                            <td>                   
                            <div class="dropdown">
                                  <button class="btn dropdown-toggle btn-primary btn-sm"  type="button" data-toggle="dropdown">Status By
                                  <span class="caret"></span></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="reserved.php?id=<?php echo $row["id"]; ?>">Reserved</a>
                                    <a class="dropdown-item" href="paid.php?id=<?php echo $row["id"]; ?>">Paid</a>
                           <!--         <a class="dropdown-item" href="returned.php?id=<?php echo $row["id"]; ?>">Returned</a> -->
                                    
                                  </div>
                                  </td>
                            <td><?php echo '<button class="btn btn-warning btn-sm editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td>
                            <td><?php echo '<button class="btn btn-danger btn-sm deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
                          </tr>
                          <?php
                          }
                        }
                        else{
                          echo "<td colspan='11' class='text-center'>Nothing to display.</td>
                          ";
                        }
                          ?>
                          </table>
                          </div>
  </div>
</div>
<!-- Add Modal -->
<div id="addBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">                        
        <h4 class="modal-title mx-auto">
         Add New Reservation</h4>
      </div>     
      
      <div class="modal-body">
        <form action="" method="post">     
          <div class="form-group">
              <label for="usr">Name:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-user"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="name" required>
                </div>
            </div>
            <div class="form-group">
              <label for="usr">Username:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-user"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="username" required>
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Contact Number:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-mobile-alt"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="contact_number" required>
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Email:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fab fa-google"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="email" required>
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Vehicle:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fa fa-bus-alt"></i>
                          </button>
                    </div>
                  <select class="custom-select custom-select-sm" id="inputGroupSelect01" name="vehicle" required>
                    <option selected disabled>Choose Vehicle:</option>
                      <?php 
                        $res = mysqli_query($db, "SELECT vehicle from tbl_vehicle");
                        while($row = mysqli_fetch_array($res)) { 
                            echo '<option> ';
                            echo $row["vehicle"]; 
                            echo '</option> ';
                        }
                      ?>
                  </select>
              </div>  
            </div> 
         
          <div class="form-group">
            <label for="usr">Date Reserved:</label>
              <div class="input-group">
                  <div class="input-group-prepend">
                        <button type="button" id="toggle" class="input-group-text">
                            <i class="fa fa-calendar-alt"></i>
                        </button>
                  </div>
                  <input type="date" class="form-control form-control-sm" name="date_reserved" required>
              </div>
            </div>

          <div class="form-group float-right">
            <button type="submit" name="addData" class="btn btn-primary btn-sm">Add Reservation</button>
            <button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Close</button>     
          </div>           
      </form>
    </div>  

  </div>
</div> 
</div>
<!-- End of Add Modal --> 


<!-- Edit Modal -->
<div id="editBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">                        
        <h4 class="modal-title mx-auto">
         Update Data</h4>
      </div>     
      
      <div class="modal-body">
        <form action="" method="post">  
        <input id="update_id" name="update_id" type="hidden">
   
          <div class="form-group">
              <label for="usr">Name:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-user"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="name" id="name">
                </div>
            </div>
            <div class="form-group">
              <label for="usr">Username:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-user"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="username" id="username">
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Contact Number:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fas fa-mobile-alt"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="contact_number" id="contact_number">
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Email:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fab fa-google"></i>
                          </button>
                    </div>
                    <input type="text" class="form-control form-control-sm" name="email" id="email">
                </div>
            </div>
            
            <div class="form-group">
              <label for="usr">Vehicle:</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                          <button type="button" id="toggle" class="input-group-text">
                              <i class="fa fa-bus-alt"></i>
                          </button>
                    </div>
                  <select class="custom-select custom-select-sm" id="inputGroupSelect01" name="vehicle">
                    <option selected disabled>Choose Vehicle:</option>
                      <?php 
                        $res = mysqli_query($db, "SELECT vehicle from tbl_vehicle");
                        while($row = mysqli_fetch_array($res)) { 
                            echo '<option id="vehicle"> ';
                            echo $row["vehicle"]; 
                            echo '</option> ';
                        }
                      ?>
                  </select>
              </div>  
            </div> 
         
          <div class="form-group">
            <label for="usr">Date Reserved:</label>
              <div class="input-group">
                  <div class="input-group-prepend">
                        <button type="button" id="toggle" class="input-group-text">
                            <i class="fa fa-calendar-alt"></i>
                        </button>
                  </div>
                  <input type="text" class="form-control form-control-sm timepicker" name="date_reserved" id="date_reserved">
              </div>
            </div>

          <div class="form-group float-right">
            <button type="submit" name="updateData" class="btn btn-primary btn-sm">Update Data</button>
            <button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Close</button>     
          </div>           
      </form>
    </div>  
</div>
  </div>
</div> 
<!-- End of Edit Modal --> 






</body>
</html>

<script>
/* To toggle date time picker */
$('.timepicker').datetimepicker({
  timepicker:false,
  datepicker:true,
  format: 'Y-m-d',
  weeks: true
})
$('#toggle').on('click', function(){
  $('picker').datetimepicker('toggle')
})

/* Script for updating data */
$(document).ready(function(){
        $('.editBtn').on('click', function(){
            $('#editBtn').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();
            $('#update_id').val(data[0]);
            $('#name').val(data[1]);
            $('#username').val(data[2]);
            $('#contact_number').val(data[3]);
            $('#email').val(data[4]);
            $('#vehicle').val(data[5]);   
            $('#date_reserved').val(data[6]);   
               
        });
    });


</script>