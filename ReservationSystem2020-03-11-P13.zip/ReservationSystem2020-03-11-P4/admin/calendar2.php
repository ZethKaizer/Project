<?php 
include('connection.php');
include('header.php');
include('tags.php');

?>
<?php
$shop = array( array("Sunday"=>"", "Monday"=>"" , "Tuesday"=>15),
               array("Sunday"=>"daisy", "price"=>0.75 , "number"=>25),
               array("Tuesday"=>"orchid", "price"=>1.15 , "number"=>7) 
             ); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class='container'>
        <div class='row'>
        
            <table class='table table-condensed table-bordered mt-3'>
            
            <tr>
            
      <th><?php echo implode('</th><th>', array_keys(current($shop))); ?></th>
    </tr>
    <?php foreach ($shop as $row): array_map('htmlentities', $row); ?>
    <tr>
      <td><?php echo implode('</td><td>', $row); ?></td>
    </tr>
<?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>