
<style>
    body{
 background-image: linear-gradient(
    rgba(0, 0, 0, 0.1),
    rgba(0, 0, 0, 0.1)
    ), url("../img/imus_bg.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center center;
  background-size: cover;
 }
 .rightColumn {
  display: inline;
  font-family: "Old English Text MT";
  font-size: 25px;
  color: white;
 }
 .nav-link:hover {
  text-decoration: underline;
 }
</style>

<div class="container-fluid" style="background-color: #232c85; color: white; ">
  <div class="row p-3 justify-content-center">
    <div class="justify-content-center">
      <img src="../img/icon2.png" width="80"/>
      <p class="ml-2 rightColumn">Imus Institute of Science and Technology</p>
    </div>
  </div>  

</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" style="background-color: #1d1d4d !important;">
<button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
 
 <!-- <a class="navbar-brand" href="#">Home</a> -->
 <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link active" href="index.php">HOME</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">GYMNASIUM</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">OTHER FACILITIES</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">VEHICLES</a>
    </li>
    <li class="nav-item">
 <!--
    <button type="button" class="btn btn-primary ml-1" data-toggle="modal" data-target="#myModal">
    LOGIN
  </button>
  -->
  <a class="nav-link active" href="#" data-toggle="modal" data-target="#myModal">LOGIN</a>
    </li>

  </ul>
  </div>
</nav>
</div>


  <!-- The Modal -->
  <div class="modal fade" id="myModal" style="zoom: 90%;">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h5 class="modal-title">Choose an User type</h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <a href="../admin/login.php"  class="btn btn-primary btn-block">Login as Admin</a>
        
        <a href="login2.php"  class="btn btn-outline-primary btn-block">Login as User</a>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
     <!--     <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      -->
        </div>
        
      </div>
    </div>
  </div>
  