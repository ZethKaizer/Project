<?php 
include('tags.php');
include('header.php');

?>

<?php 
function build_calendar($month, $year){
    include('connection.php');
  //  $month = $_POST['month'];
   // $year = $_POST['year'];
   /*
    $bookings = array();
    $query = mysqli_query($db, "SELECT * FROM tbl_reservation WHERE MONTH(date)='$month' AND YEAR(date)='$year'");
    if(mysqli_num_rows($query) > 0){
   while($row = mysqli_fetch_array($query)){
       $bookings[] = $row['date'];
   }
    }
    */
    // so first, mag-seset tayo ng array para sa pangalan ng araw
    $daysOfWeek = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    // next, i-geget naman natin yung every first day sa bawal month.
    // so, yung mktime ginagamit siya for getting specific na
    // hour, minute, sec, month, day, year, etc.
    // kaya ganyan ang format nya kasi mag-iistart tayo sa 0 hour, 0 min at 0 sec
    // then variable na month, '1' kasi sa 1 ang kukunin natin na value sa Day
    // then variable for year
    $firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);

    //i-geget dito yung bilang ng araw sa kada month
    $numberDays = date('t', $firstDayOfMonth);

    //i-geget dito yung information ng first day sa specific na month
    $dateComponents = getdate($firstDayOfMonth);

    //i-geget dito naman yung name ng specific na month
    $monthName = $dateComponents['month'];

    //i-geget dito yung specific na bilang ng araw sa kada linggo
    $dayOfWeek = $dateComponents['wday'];

    //i-geget dito yung current date
    $dateToday = date("Y-m-d");

    // dito na yung pag-create natin ng calendar.
    // ginawa natin to para hindi na tayo magmano-mano ng type
    
    $calendar = "<table class='table table-bordered table-striped'>";
    $calendar .= "<br><center><h2>$monthName - $year</h2>";

    //filter by previous, current and next month
   
    $calendar.= "<a class='btn btn-sm btn-primary' href='?month=".date('m', mktime(0, 0, 0, $month-1, 1, $year))."&year=".date('Y', mktime(0, 0, 0, $month-1, 1, $year))."'>Previous Month</a> ";   
    $calendar.= " <a class='btn btn-sm btn-primary' href='?month=".date('m')."&year=".date('Y')."'>Current Month</a> ";   
    $calendar.= "<a class='btn btn-sm btn-primary' href='?month=".date('m', mktime(0, 0, 0, $month+1, 1, $year))."&year=".date('Y', mktime(0, 0, 0, $month+1, 1, $year))."'>Next Month</a></center><br>";
    $calendar.= "<tr></center>";
    
    //dito na natin icacall yung array na cinall natin sa taas. yung array na day name

    foreach($daysOfWeek as $day){
    $calendar.="<th class='header'>$day</th>";
    }

    $calendar.="</tr><br><tr>";

    //dito naman yung variable para ma-assure natin na meron lang tayong 
    //7 columns sa magiging table natin
    if($dayOfWeek > 0){
        for($k=0;$k<$dayOfWeek;$k++){
            $calendar.="<td></td>";
        }
    }
    // iinitiate natin yung current day 
    $currentDay = 1;

    //i-geget dito yung bilang ng buwan
    $month = str_pad($month, 2, "0", STR_PAD_LEFT);

    while($currentDay <= $numberDays){

    //if ang seventh na column niya is na-reach, mag-ccreate siya ng panibagong row
        if($dayOfWeek == 7){
            $dayOfWeek = 0;
            $calendar.= "<tr></tr>";
        }

        $currentDayRel = str_pad($currentDay, 2, "0", STR_PAD_LEFT);
        $date = "$year-$month-$currentDayRel"; 
        $dayname = strtolower(date('l', strtotime($date)));
        $eventNum = 0;
        
        $today = $date==date('Y-m-d')? "today" : "";
       
        if($date<date('Y-m-d')){
            $calendar.="<td><h4>$currentDay</h4> <button class='btn btn-danger btn-sm'>N/A</button>";
        }
        /*
        elseif(in_array($date, $bookings)){
            $calendar.="<td class='$today'><h4>$currentDay</h4><button class='btn btn-danger btn-sm'>Reserved</h4>";
        }
        */
        
        else{
            $calendar.="<td class='$today'><h4>$currentDay</h4>
            <a href='reserve.php?date=".$date."' class='btn btn-success btn-sm'>Available</a>";
        }

/*
        if($dateToday == $date){
            $calendar.="<td class='today'><h4>$currentDay</h4></td>";
        }
        else{
            $calendar.="<td><h4>$currentDay</h4></td>";
        }
  */  
        $calendar.="</td>";
        $currentDay++;
        $dayOfWeek++;
    }
    
    if($dayOfWeek !=7) {
        $remainingDays = 7-$dayOfWeek;
        for($i=0;$i<$remainingDays;$i++){
            $calendar.="<td></td>";
        }
    }

    $calendar.="</tr>";
    $calendar.="</table>";
    echo $calendar;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Facility Reservation System</title>
    <style>
        table {
            table-layout:fixed;
        }
        td {
            width: 33% !important;
        }
        .today {
            background-color: lightgray;
           
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php 
                    $dateComponents = getdate();
                    if(isset($_GET['month']) && isset($_GET['year'])){
                        $month = $_GET['month']; 			     
                        $year = $_GET['year'];
                    }
                    else{
                        $month = $dateComponents['mon']; 			     
                        $year =  $dateComponents['year'];
                    }
                    echo build_calendar($month, $year);
                ?>
            </div>
            <div class="col-md-4">
            
            </div>
        </div>
    </div>
</body>
</html>