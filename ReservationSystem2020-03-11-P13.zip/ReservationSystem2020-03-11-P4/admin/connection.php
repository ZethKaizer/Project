<?php 
include('tags.php');
$db = mysqli_connect('localhost', 'root', '', 'reservation');
?>

