<?php 
//session_start();
include('tags.php');
include('connection.php');
include('header.php');
?>
