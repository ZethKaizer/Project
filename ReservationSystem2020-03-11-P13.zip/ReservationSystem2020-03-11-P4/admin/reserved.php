<?php 
include "connection.php";
$id = $_GET["id"];

$res = mysqli_query($db, "UPDATE tbl_reservation SET status='Reserved' WHERE id=$id");
if($res){
   echo "<script>
         window.location = 'reservation.php';
   </script>";
}
?>