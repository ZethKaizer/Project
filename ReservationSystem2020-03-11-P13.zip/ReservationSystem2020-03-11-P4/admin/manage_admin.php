<?php 
//session_start();
include('header.php');
include('tags.php');

include('connection.php');
?>


<!-- ADD QUERY [ADD NEW USER] -->  
<?php 
  if(isset($_POST["addData"]))
     {
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $query_show = mysqli_query($db, "SELECT * FROM tbl_admin_credentials");
        
        $query = mysqli_query($db, "SELECT * FROM tbl_admin_credentials WHERE username='$username'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger" style="width: 100% !important;">
             <center> The username you entered already exists.</center>
        </div>';
         }
         else 
         {
           // ones na lumagpas sa 3 yung magreregister sa kanya, i-aalert nya yung baba.
            if(mysqli_num_rows($query_show) > 2) 
            {
              echo '<div class="alert alert-danger" style="width: 100% !important;">
                      <center>Sorry, you have reached the user account limit.</center>
                    </div>';
            }   
            else
            {
              //else, i-eexecute nya yung insert query
              $query_insert = mysqli_query($db, "INSERT INTO tbl_admin_credentials 
                  VALUES('', '$last_name', '$first_name', '$middle_name', 
                  '$username', '$password')");
                if($query_insert)
                {            
                echo ' <div class="alert alert-success" style="width: 100% !important;">
                <center> Registration successfully </center>
                       </div>';
                }
            }
          }
      }
?>

 


    <!-- UPDATE QUERY [EDIT USER] -->  
               
<?php 
     if(isset($_POST['updateData'])){    
        $id = $_POST['update_id'];
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $query = mysqli_query($db, "UPDATE tbl_admin_credentials SET last_name='$last_name', first_name='$first_name', middle_name='$middle_name', username='$username', password='$password' WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
            Successfully Updated
            </center>
            </div>';
        }
     }
?>

     <!-- DELETE QUERY [DELETE USER] -->                    
<?php 
     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($db, "DELETE FROM tbl_admin_credentials WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
               Successfully Deleted
            </center>
            </div>';
        }
     }
?>  
<head>
<title>Facility Reservation System</title>
</head>
<body>
        <!-- page content area main -->
        <div class="container">       
            <br>
                <div class="row justify-content-center">
                    <center>     
                        <h2>Manage Admin Credentials</h2>
                        <br>
                        <?php 
                        $res = mysqli_query($db, "SELECT * FROM tbl_admin_credentials order by ID desc");
                        if($res){
                          $rowcount = mysqli_num_rows($res);
                        }
                        
                        ?>    
                        
                        <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addBtn">Add New User</button>            
                        <br><br>
                        <table class='table table-bordered table-striped'>
                          <tr style="background: #d9d9d9 !important; text-align: center;">
                            <th>ID</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Edit</th>
                            <th>Delete</th>                                                               
                          </tr>
                        <?php while($row = mysqli_fetch_array($res)){ ?>
                          <tr>
                            <td><?php echo $row["id"]; ?> </td>
                            <td><?php echo $row["last_name"]; ?> </td>
                            <td><?php echo $row["first_name"]; ?> </td>
                            <td><?php echo $row["middle_name"]; ?> </td>           
                            <td><?php echo $row["username"]; ?> </td>
                            <td><?php echo $row["password"]; ?> </td>                     
                            <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td>
                            <td><?php echo '<button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
                          </tr>
                          <?php
                          }
                          ?>
                        </table>
                    </center>
                  </div>
                </div>

<!-- Add Modal -->
<div id="addBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add New User</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">  
          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" class="form-control" required>
          </div>    
        </div>

        <div class="modal-footer">
          <button type="submit" name="addData" class="btn btn-primary">Add User</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Add Modal -->        

<!-- Update Modal -->
<div id="editBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">
        <input id="update_id" name="update_id" type="hidden">

          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" id="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" id="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" id="middle_name" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" id="username" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Password:</label>
            <input type="text" name="password" id="password" class="form-control" required>
          </div>    
        </div>

        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->


<!-- Delete Modal -->
<div id="deleteUser" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- End of Delete Modal -->
</body>


<script>
    $(document).ready(function(){
        $('.editBtn').on('click', function(){
            $('#editBtn').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();

            $('#update_id').val(data[0]);
            $('#last_name').val(data[1]);
            $('#first_name').val(data[2]);
            $('#middle_name').val(data[3]);
            $('#username').val(data[4]);
            $('#password').val(data[5]);      
        });
    });
</script>

<script>
    $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });
</script>
</body>
</html>
