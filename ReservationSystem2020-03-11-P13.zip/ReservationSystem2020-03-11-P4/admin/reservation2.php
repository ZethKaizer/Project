<?php 
//session_start();
include('header.php');
include('tags.php');

include('connection.php');
?>


<head>
<title>Facility Reservation System</title>
<style>

.table-responsive {
    display: table !important;
}
</style>
</head>
<body>
<?php 
  if(isset($_POST["addData"]))
     {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $date_reserved = $_POST['date_reserved'];
        $contact_number = $_POST['contact_number'];
        $email = $_POST['email'];
        $vehicle = $_POST['vehicle'];
        $query_show = mysqli_query($db, "SELECT * FROM tbl_reservation");
        
        $query = mysqli_query($db, "SELECT * FROM tbl_reservation WHERE email='$email'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger" style="width: 100% !important;">
             <center> The email you entered already exists.</center>
        </div>';
         }
         else 
         {
           // ones na lumagpas sa 3 yung magreregister sa kanya, i-aalert nya yung baba.
            if(mysqli_num_rows($query_show) > 2) 
            {
              echo '<div class="alert alert-danger" style="width: 100% !important;">
                      <center>Sorry, you have reached the user account limit.</center>
                    </div>';
            }   
            else
            {
              //else, i-eexecute nya yung insert query
              $query_insert = mysqli_query($db, "INSERT INTO tbl_reservation 
                  VALUES('', '$name', '$email', '$contact_number', 
                  '$email', '$vehicle', '$date_reserved', 'reserved')");
                if($query_insert)
                {            
                echo ' <div class="alert alert-success" style="width: 100% !important;">
                <center> Registration successfully </center>
                       </div>';
                }
            }
          }
      }
?>

 


    <!-- UPDATE QUERY [EDIT USER] -->  
               
<?php 
     if(isset($_POST['updateData'])){    
        $id = $_POST['update_id'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact_number = $_POST['contact_number'];
        $email = $_POST['email'];
        $vehicle = $_POST['vehicle'];
        $query = mysqli_query($db, "UPDATE tbl_admin_credentials SET name='$name', email='$email', contact_number='$contact_number', email='$email', vehicle='$vehicle' WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
            Successfully Updated
            </center>
            </div>';
        }
     }
?>

     <!-- DELETE QUERY [DELETE USER] -->                    
<?php 
     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($db, "DELETE FROM tbl_admin_credentials WHERE id='$id'");
        if($query) {
            echo '<div class="alert alert-success" style="width: 100% !important;">
            <center>
               Successfully Deleted
            </center>
            </div>';
        }
     }
?>  
        <!-- page content area main -->
        <div class="container-fluid">       
            <br>
                <div class="row justify-content-center">
                
<!-- ADD QUERY [ADD NEW USER] -->  

                    <center>     
                        <h2>Manage Reservations</h2>
                        <br>
                        <?php 
                        $res = mysqli_query($db, "SELECT * FROM tbl_reservation order by ID desc");
                        if($res){
                          $rowcount = mysqli_num_rows($res);
                        }
                        
                        ?>    
                        
                        <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addBtn">Add New Reservation</button>            
                        <br><br>
                        <div class="table-responsive">
                        <table class="table table-bordered table-striped m-3">
                          <tr style="background: #d9d9d9 !important; text-align: center;">
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Contact Number</th>
                            <th>Email</th>
                            <th>Vehicle</th>
                            <th>Date Reserved</th>
                            <th>Status</th>
                            <th>Approval</th>                           
                            <th>Edit</th>
                            <th>Delete</th>                                                               
                          </tr>
                        <?php 
                        if(mysqli_num_rows($res) > 0) {
                        
                        while($row = mysqli_fetch_array($res)){ ?>
                          <tr>
                            <td><?php echo $row["id"]; ?> </td>
                            <td><?php echo $row["name"]; ?> </td>
                            <td><?php echo $row["username"]; ?> </td>
                            <td><?php echo $row["contact_number"]; ?> </td>           
                            <td><?php echo $row["email"]; ?> </td>
                            <td><?php echo $row["vehicle"]; ?> </td>                     
                        <!--    <td><?php echo $row["plate_number"]; ?> </td>  -->                   
                            <td><?php echo $row["date_reserved"]; ?> </td>
                            <td><?php echo $row["status"]; ?> </td>  
                            <td>                   
                            <div class="dropdown">
                                  <button class="btn dropdown-toggle btn-primary"  type="button" data-toggle="dropdown">Approval
                                  <span class="caret"></span></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="reserved.php?id=<?php echo $row["id"]; ?>">Reserved</a>
                                    <a class="dropdown-item" href="paid.php?id=<?php echo $row["id"]; ?>">Paid</a>
                                    <a class="dropdown-item" href="returned.php?id=<?php echo $row["id"]; ?>">Returned</a>
                                    
                                  </div>
                                  </td>
                            <td><?php echo '<button class="btn btn-warning editBtn" data-toggle="modal" data-target="#editBtn">Edit</button>' ?> </td>
                            <td><?php echo '<button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
                          </tr>
                          <?php
                          }
                        }
                        else{
                          echo "<td colspan='11' class='text-center'>Nothing to Display</td>
                          ";
                        }
                          ?>
                        </table>
                        </div>
                    </center>
                  </div>
                </div>

<!-- Add Modal -->
<div id="addBtn" class="modal fade" role="dialog" style="zoom: 90%;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add New Reservation</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">  
          <div class="form-group">
            <label for="usr">Name:</label>
            <input type="text" name="name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Contact Number:</label>
            <input type="text" name="contact_number" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Email:</label>
            <input type="text" name="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Vehicle:</label>
            <input type="text" name="vehicle" class="form-control" required>
          </div>    
          <div class="form-group">
            <label for="usr">Plate Number:</label>
            <input type="text" name="vehicle" class="form-control" required>
          </div> 
          <div class="form-group">
            <label for="usr">Date Reserved:</label>
            <input type="date" name="date_reserved" class="form-control" required>
          </div> 
        </div>

        <div class="modal-footer">
          <button type="submit" name="addData" class="btn btn-primary">Add Reservation</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>

  </div>
</div>     
<!-- End of Add Modal -->        

<!-- Update Modal -->
<div id="editBtn" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
      </div>     

      <div class="modal-body">
        <form action="" method="post">
        <input id="update_id" name="update_id" type="hidden">

          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="name" id="name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="email" id="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="contact_number" id="contact_number" class="form-control">
          </div>
          <div class="form-group">
            <label for="usr">email:</label>
            <input type="text" name="email" id="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">vehicle:</label>
            <input type="text" name="vehicle" id="vehicle" class="form-control" required>
          </div>    
        </div>

        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->


<!-- Delete Modal -->
<div id="deleteUser" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- End of Delete Modal -->
</body>


<script>

    $(document).ready(function(){
        $('.editBtn').on('click', function(){
            $('#editBtn').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();

            $('#update_id').val(data[0]);
            $('#name').val(data[1]);
            $('#email').val(data[2]);
            $('#contact_number').val(data[3]);
            $('#email').val(data[4]);
            $('#vehicle').val(data[5]);      
        });
    }
</script>

<script>
    $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });
</script>
</body>
</html>
