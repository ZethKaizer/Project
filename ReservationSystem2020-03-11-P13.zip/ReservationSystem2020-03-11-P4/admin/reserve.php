<?php 
include('connection.php');
include('header.php');
include('tags.php');
?>


<?php 
if(isset($_GET['date'])){
	$date = $_GET['date'];
}

if(isset($_POST['submit'])){
	/*
	$name = $_POST['name'];
	$email = $_POST['email'];
	$contact_number = $_POST['contact_number'];
	//$date = $_POST['date'];
	$query = mysqli_query($db, "INSERT INTO tbl_reservation (name, email, contact_number, date) VALUES('$name', '$email', '$contact_number', '$date'");

	if($query){
		echo '<div class="alert alert-success" style="width: 100% !important;">
                      <center>Reservation Successful.</center>
                    </div>';
	}
	*/ 
	$name = $_POST['name'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];
   // $mysqli = new mysqli('localhost', 'root', '', 'reservation');
    $query = mysqli_query($db, "INSERT INTO tbl_reservation (name, email, contact_number, date) VALUES ('$name', '$contact_number', '$email', '$date')");
   if($query){
		echo '<div class="alert alert-success" style="width: 100% !important;">
                      <center>Reservation Successful.</center>
                    </div>';
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Facility Reservation System</title>
</head>
<body>
<div class="container" style="zoom: 90%;">
	<br>

	<h1 class="text-center" name="date">Reservation for Date: <?php echo date('F d, Y', strtotime($date)); ?> </h1>
	<div class="row">
		<div class="col-md-6 mx-auto">

	<form method="post" action="" autocomplete="off">
		<div class="form-group">
			<label for="name">Name:</label>
			<input type="text" class="form-control" name="name">			
		</div>

		<div class="form-group">
			<label for="name">Email:</label>
			<input type="text" class="form-control" name="email">			
		</div>

		<div class="form-group">
			<label for="name">Contact Number:</label>
			<input type="number" class="form-control" name="contact_number">			
		</div>
<!--
		<input type="hidden" name="date" value='<?php echo date('F d, Y', strtotime($date)); ?>'/>
	-->
		<input type="submit" class='btn btn-primary' name='submit'>

	</form>
</div>
</div>
</div>
</body>
</html>