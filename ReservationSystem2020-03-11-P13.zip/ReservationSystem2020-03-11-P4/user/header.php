<?php 
session_start();
include('connection.php');
//include('tags.php');

//Ibig sabihin naman nito, hanggang hindi pa naseset yung session nya or hangga't hindi pa siya nakaka-log in
//Magreredirect siya sa 'login.php'. Ang purpose nito is para ma-secure nya yung data at hindi nya ma-access
// yung Functions hangga't di siya nakakapag-log in
if(!isset($_SESSION["username"])) { 
echo
'<script>
  window.location = "login.php";
</script>';
}
?>
<style>
        .nav-link, .dropdown-item {
            font-size: 14px;
        }
        .nav-link:hover {
        }
    </style>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <img src="../img/imus_logo.png" width="50"> &nbsp;&nbsp;
      <a class="navbar-brand" href="#">Facility Reservation System</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
                
                <li class="nav-item active">
                  <a class="nav-link" >Welcome, <b><?php echo $_SESSION["username"]; ?></b> |</a>
                </li>

                <li class="nav-item active">
                  <a class="nav-link">View Reservation</a>
                </li>          

            <!--
              <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                      Manage Reservation
                    </a>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="add_equipment.php">Manage Equipment</a>
                      <a class="dropdown-item" href="display_books.php">Display Books</a>
                      <a class="dropdown-item" href="issue_books.php">Issue Books</a>
                      <a class="dropdown-item" href="return_book.php">Return Books</a>
                    </div>
                  </li> 
                  -->   
                 <li class="nav-item">
                  <a class="nav-link" href="logout.php">Log Out</a>
                </li>    
          </ul>
      </div>
    </nav>