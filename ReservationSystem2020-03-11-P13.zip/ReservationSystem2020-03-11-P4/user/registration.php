<?php 
include('tags.php');
include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    body{
 background-image: linear-gradient(
    rgba(0, 0, 0, 0.1),
    rgba(0, 0, 0, 0.1)
    ), url("../img/imus_bg.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center center;
  background-size: cover;
 }
 </style>
</head>
<body>
<?php
  include('header2.php');
?>
<div class="container-fluid">
<div class="row justify-content-center">
<form action="" method="post">  
<div class="p-5 m-5 " style="zoom: 90%; background: #f0f0f0;">
<?php 
  if(isset($_POST["addData"]))
     {
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $contact_number = $_POST['contact_number'];
        $query = mysqli_query($db, "SELECT * FROM tbl_user_credentials WHERE username='$username'");
         if(mysqli_num_rows($query) > 0) 
         {
             echo '<div class="alert alert-danger alert-dismissible fade show " style="width: 100% !important;">
             <center> 
             <button type="button" class="close" data-dismiss="alert">&times;</button>
             The username you entered already exists.
             </center>
        </div>';
         }
         else 
         {
            $query_insert = mysqli_query($db, "INSERT INTO tbl_user_credentials 
                VALUES('', '$last_name', '$first_name', '$middle_name', 
                '$username', '$password', '$email', '$contact_number')");
            if($query_insert)
            {            
            echo ' <div class="alert alert-success alert-dismissible fade show" style="width: 100% !important;">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
             
            <center> Registration successfully. <span><a href="login2.php"><b>Click this to proceed to Login</b></a></span> </center>
                    </div>';           
            }
          }
      }
?>  
      <div class="row justify-content-center mb-2">
          <img src="../img/imus_logo.png" width="150" />
      </div>
          <h1 class="display-4 mb-5 text-center">Registration Form</h1>
          <div class="form-group">
            <label for="usr">Last Name:</label>
            <input type="text" name="last_name" class="form-control" required>
          </div>

          <div class="form-group">
            <label for="usr">First Name:</label>
            <input type="text" name="first_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="usr">Middle Name:</label>
            <input type="text" name="middle_name" class="form-control">
          </div>
          <div class="row">
            <div class="form-group col-lg-6">
                <label for="usr">Username:</label>
                <input type="text" name="username" class="form-control" maxlength="11" required>
                <center>
                  <h6 class="mt-2" style="font-size: 14px;">Maximum of 11 digits only</h6>
                </center>  
          </div>
            <div class="form-group col-lg-6">
                <label for="usr">Password:</label>
                <input type="password" maxlength="11" name="password" class="form-control" required>
                <center>
                  <h6 class="mt-2" style="font-size: 14px;">Maximum of 11 digits only</h6>
                </center> 
            </div>  
          </div>
          <div class="form-group">
            <label for="usr">Email:</label>
            <input type="text" name="email" class="form-control" required>
          </div>  
          <div class="form-group">
            <label for="usr">Contact Number:</label>
            <input type="text" name="contact_number" class="form-control" required>
          </div>    
       
          <button type="submit" name="addData" class="btn  btn-primary btn-block p-2" style="font-size: 18px !important;">REGISTER</button>
          <br>
          <div class="form-group">
            <a href="login2.php" class="float-md-right " style="font-size: 18px;"><u>Back to Login</u></a>
        </div>
      </form>
      
      </div>
</div>
</div>
</body>
</html>

<script>
/* Optional but not required 
$("#alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $("#alert-success").slideUp(500);
});
$("#alert-danger").fadeTo(5000, 500).slideUp(500, function(){
    $("#alert-danger").slideUp(500);
});
*/
</script>