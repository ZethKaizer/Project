<?php 
include('tags.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
  include('header2.php');
?>
<div class="container-fluid" style="color: white;">
  <br>
  <center>
  <!--
  <h1 class="mb-3">Welcome to Facility Management System</h3>
  <h5>It's nice to meet you!</h5>
  <br>
  <button class='btn btn-lg btn-primary rounded-sm'>View Reservation</button>
  -->
  <div class="row">
    <div class="col-sm-6 p-5">
    <div style="background-color: #1d1d4d;" class="p-5">
      <h1 class="display-4">Welcome to Facility</h1>
      <h1 class="display-4">Management System</h1>
      <br>
      <p class="lead">It's nice to meet you!</p>
      
    </div>
    </div>
    <div class="col-sm-6 p-5">
    <div class="p-5">
      <h1 class="font-weight-normal">Want to Reserve Gymnasium? Vehicles? Or Other Facilities?</h1>
     <h1 class="lead mb-4">Click the Link below</h1>
      <a href="login2.php"><button class="btn btn-lg btn-primary" style="background: #1d1d4d;">Start Reservation</button></a>
    </div>
    </div>
    </div>
</center>
  </div>
  
  <br>
</body>
</html>