<?php 
session_start();
include('connection.php');
?>

<?php 
    if(isset($_POST["login"]))
    {
        // variable naman to para ma-validate niya yung username at password na iinput mo sa page
        $count = 0;    
        $username = $_POST['username'];  // So ito naman, mag-dedeclare ka ng variable $username para sa $_POST['username']  
        $password = $_POST['password'];  // same lang din dito

        //dito, mag-eexecute ka na ng query.
        //so first, magdedeclare ka muna ng variable para sa i-eexecute mong query. so, $res ang name ng variable mo.
        //so pwede mo na gamitin yung $res given sa example sa baba.
        // So, icacall mo yung $db kasi ito yung variable para ma-connect siya sa database. Nasa connection.php yan.
        // So, mysqli_query($db, then sa loob nito yung query mo. "SELECT * FROM kung anong table name mo")
        // WHERE kung saan mo naman siya i-eexecute
        $res = mysqli_query($db, "SELECT * FROM tbl_user_credentials WHERE username='$username' && password='$password'");

        // so based dito, yung mysqli_num_rows nagrereturn siya ng number ng rows sa magiging result ng query mo
        $count = mysqli_num_rows($res); 
                                        


        // so if yung $count nya is 0 or wala yung username or password nya sa table, i-eexecute nya yung laman ng echo
        // which is yung alert na mali yung nilagay nyang input                              
        if($count == 0) { 
            
        echo '<div class="alert alert-danger col-lg-12 " style="width: 100%;">
               <center><strong>Invalid</strong> Username Or Password.</center>
            </div> ';

        }
        // so kapag tama naman yung nilagay nya, i-eexecute nya ulit yung nasa loob ng echo 
        // which is mapupunta na siya sa index.php na page.
        else { 
            $_SESSION["username"] = $username;
            
         echo '<script>
                window.location="index.php";
            </script> ';
           
        }
    }
?>

<html>
<head>
    <title>Facility Reservation System</title>
</head>
<body>

<div class="container"> 
<div class="text-center " style="margin-top: 20px;">
    <img src="../img/imus_logo.png" width="150"/>
    </div>
    <h4 class="text-center p-4">Facility Reservation System</h4> 
    <h6 class="text-center">User Portal</h6> 
  
    <div class="row justify-content-center"> 
        <div class="col-lg-5 bg-light mt-4 px-0" style="background: white !important; border: solid 1px #d8dee2 !important; border-radius: 10px; margin: 15px;">   
       
        <form action="" method="post" class="p-4">

        <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="form-group">
            <span><input type="submit" class="btn btn-block btn-primary" value="Login" name="login"></span>
        </div>
        </form>
    </div>
</div>

</div>

</div>


</body>
</html>