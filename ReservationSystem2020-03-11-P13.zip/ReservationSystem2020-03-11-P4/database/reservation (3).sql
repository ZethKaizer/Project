-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2020 at 06:25 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(2, 'Kaizer', 'Zeth', 'Jin', 'zethkaizer04', 'zethkaizer'),
(8, 'sampleuser', 'sampleuser', 'sampleuser', 'sampleuser', 'sample'),
(9, '09909', '909009', '909009', '909009', '0990');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reservation`
--

CREATE TABLE `tbl_reservation` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `contact_number` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `vehicle` varchar(100) NOT NULL,
  `date_reserved` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reservation`
--

INSERT INTO `tbl_reservation` (`id`, `name`, `username`, `contact_number`, `email`, `vehicle`, `date_reserved`, `status`) VALUES
(1, 'Zeth Kaizer', 'zethkaizer04@gm', '09123456789', 'zethkaizer04@gmail.com', 'Isuzu Crosswind', '2020-03-23', 'Reserved'),
(2, 'name', 'email', 'contact', 'email', 'B Coaster 1', '2020-12-31', 'Reserved'),
(3, 'name', '', 'contact', 'email', 'B Coaster 1', '2020-12-31', 'Reserved'),
(4, 'name', 'username', 'contact', 'email', 'B Coaster 1', '2020-12-31', 'Reserved'),
(5, 'name        ', 'username       ', 'contact        ', 'email        ', 'B Coaster 1', '2020-03-14 ', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `email`, `contact_number`) VALUES
(1, 'Sampleuser', 'sampleuser', 'Sampleuser', 'Sampleuser', 'Sampleuser', 'Sampleuser@gmail.com', '523552552'),
(2, '8890089', '809089089', '0898989', '08989089', '08908989', '089089089@gmail.com', '89089089'),
(3, '890089089', '89089089', '898989', '8989', '89898989', '898989@gmail.com', '8989'),
(4, '8988890', '809089809', '809089', '08908989089089', '898989089', '089089809@gmail.com', '08908'),
(5, '6236266380602830998', '089986820903689268089', '89620882830892623860808', '080238608608260', '890632806280968', '08986093208936206893089@gmail.com', '089630829632809'),
(6, '9988390896089089', '089063892896068293089', '0896238096028962080808960289', '098689380839809', '08908628628', '88096320893620898@gmail.com', '0980962089'),
(7, '998038900829089', '890890', '809089890', '08089089089089', '809809', '089809890@gmail.com', '890809809'),
(8, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(9, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(10, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(11, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(12, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(13, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(14, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(15, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(16, '90890890', '890980890', '809809908', '089809890890809', '8080989089', '26326632@gmail.com', '80809'),
(17, '099059009539', '09052', '909009', '90090990', '09099090', '925152112@gmail.com', '96296363262'),
(18, '088', '8898989', '988989898989', '8989898', '8989898', '989898989', '898989'),
(19, 'lastica', 'mark aldrin', 'b', 'aldrin04', 'aldrin04', 'markaldrin04@gmail.com', '095305353'),
(20, '0989089', '8899880980', '890890098', '089080890', '80809809809', '9808080', '8980890'),
(21, '8908889098', '898989', '89008908989', '80980980898', '98098098080', '809809890890809809', '80989080809080980980989'),
(22, '63262', '80808', '9808', '90808', '80808', '898080808', '9880');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicle`
--

CREATE TABLE `tbl_vehicle` (
  `id` int(11) NOT NULL,
  `vehicle` varchar(200) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `capacity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vehicle`
--

INSERT INTO `tbl_vehicle` (`id`, `vehicle`, `plate_number`, `capacity`) VALUES
(1, 'B Coaster 1', 'VG-5008', '28'),
(2, 'II Coaster 2', 'VG-5011', '28'),
(3, 'II Coaster 3', 'VG-5010', '28'),
(4, 'Isuzu Crosswind', 'ZJZ-493', '8'),
(5, 'Nissan Urban', 'AIA-8161', '18'),
(6, 'L-300/II Elf', 'UMT-896', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reservation`
--
ALTER TABLE `tbl_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_reservation`
--
ALTER TABLE `tbl_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
