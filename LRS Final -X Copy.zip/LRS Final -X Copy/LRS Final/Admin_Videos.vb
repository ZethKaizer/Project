﻿Public Class Admin_Videos

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        OpenFileDialog1.Filter = "(*.mp4) | *.mp4"
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            AxVLCPlugin21.playlist.add(OpenFileDialog1.FileName)
        End If
    End Sub


    Private Sub BunifuFlatButton10_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton10.Click
    End Sub


    Private Sub BunifuFlatButton9_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton9.Click
    End Sub

    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs)

    End Sub
End Class
