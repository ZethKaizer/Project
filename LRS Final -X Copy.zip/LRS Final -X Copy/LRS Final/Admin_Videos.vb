﻿Public Class Admin_Videos

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        OpenFileDialog1.Filter = "(*.mp4) | *.mp4"
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            AxWindowsMediaPlayer1.URL = OpenFileDialog1.FileName
            MaterialSingleLineTextField2.Text = AxWindowsMediaPlayer1.currentMedia.name.ToString()
        End If
    End Sub
End Class
