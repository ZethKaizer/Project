﻿Public Class Admin_Manage_Users

 

    Private Sub Admin_Manage_Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BunifuCustomDataGrid1.BringToFront()
    End Sub

    

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete this user?", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxIcon.Warning)
    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click

    End Sub

    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton7.Click

    End Sub
End Class
