﻿Imports MetroFramework


Public Class AdminManageUsers

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs) Handles Panel5.Paint

    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        MetroFramework.MetroMessageBox.Show(Me, "Successfully Deleted! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)


    End Sub

    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton7.Click
        UserAddAccount1.BringToFront()

    End Sub

    Private Sub AdminManageUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BunifuCustomDataGrid1.BringToFront()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        UserUpdateAccount1.BringToFront()
    End Sub
End Class