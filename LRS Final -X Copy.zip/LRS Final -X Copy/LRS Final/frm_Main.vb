﻿Public Class frm_Main


    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = True
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        If (ComboBox1.SelectedIndex = 0) Then
            Me.Hide()
            ICT_Panel.Show()
        ElseIf (ComboBox1.SelectedIndex = 1) Then
            Me.Hide()
            HE_Panel.Show()
        ElseIf (ComboBox1.SelectedIndex = 2) Then
            Me.Hide()
            AgriPanel.Show()
        End If



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        frm_admin_login.Show()

    End Sub

    Private Sub frm_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub
End Class