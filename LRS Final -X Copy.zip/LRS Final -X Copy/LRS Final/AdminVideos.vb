﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class AdminVideos
    Dim conn As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=admin_video_db")
    Private Sub btn_Dashboard_Click(sender As Object, e As EventArgs)
        Me.Hide()
        AdminDashboard.Show()

    End Sub

    Private Sub btn_PDF_Click(sender As Object, e As EventArgs)
        Me.Hide()
        AdminPDFFiles.Show()
    End Sub

    Private Sub btn_Videos_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub

 
 
    Private Sub BunifuThinButton23_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
    
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        AxWindowsMediaPlayer1.Ctlcontrols.pause()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        AxWindowsMediaPlayer1.Ctlcontrols.stop()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        AxWindowsMediaPlayer1.fullScreen = True
    End Sub

    Private Sub AxWindowsMediaPlayer1_Enter(sender As Object, e As EventArgs) Handles AxWindowsMediaPlayer1.Enter

    End Sub

    Private Sub AxWindowsMediaPlayer1_Enter(ms As MemoryStream, p2 As String)

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            AxWindowsMediaPlayer1.URL = OpenFileDialog1.FileName
            MaterialSingleLineTextField2.Text = AxWindowsMediaPlayer1.currentMedia.name.ToString()
        End If

    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs)


    End Sub
End Class