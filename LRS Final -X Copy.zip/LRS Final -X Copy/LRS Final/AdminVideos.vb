﻿Public Class AdminVideos

    Private Sub btn_Dashboard_Click(sender As Object, e As EventArgs) Handles btn_Dashboard.Click
        Me.Hide()
        AdminDashboard.Show()

    End Sub

    Private Sub btn_PDF_Click(sender As Object, e As EventArgs) Handles btn_PDF.Click
        Me.Hide()
        AdminPDFFiles.Show()
    End Sub

    Private Sub btn_Videos_Click(sender As Object, e As EventArgs) Handles btn_Videos.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        OpenFileDialog1.ShowDialog()

    End Sub

    Private Sub BunifuThinButton23_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        AxWindowsMediaPlayer1.URL = OpenFileDialog1.FileName

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        AxWindowsMediaPlayer1.Ctlcontrols.pause()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        AxWindowsMediaPlayer1.Ctlcontrols.stop()
    End Sub
End Class