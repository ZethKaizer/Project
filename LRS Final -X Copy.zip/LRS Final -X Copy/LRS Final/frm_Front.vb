﻿Public Class frm_Front

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        Dim fmain As New frm_Main
        fmain.Show()
        Me.Hide()
    End Sub


    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs)
        Me.Hide()
        frm_Main.Show()
    End Sub

    Private Sub frm_Front_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs)


    End Sub


    Private Sub frm_Front_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()
    End Sub

    
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        frm_Main.Show()
    End Sub
End Class
