﻿Public Class AdminPDFFiles

    
    Private Sub btn_Dashboard_Click(sender As Object, e As EventArgs) Handles btn_Dashboard.Click
        Me.Hide()
        AdminDashboard.Show()

    End Sub

    Private Sub btn_PDF_Click(sender As Object, e As EventArgs) Handles btn_PDF.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub btn_Videos_Click(sender As Object, e As EventArgs) Handles btn_Videos.Click
        Me.Hide()
        AdminVideos.Show()
    End Sub
End Class