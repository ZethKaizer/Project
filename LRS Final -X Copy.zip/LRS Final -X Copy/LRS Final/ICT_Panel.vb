﻿Public Class ICT_Panel
    Private Sub ICTPanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        ICT_PDF_Files.Show()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        frm_Main.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        ICT_Videos.Show()

    End Sub
End Class