﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_Logout = New System.Windows.Forms.Button()
        Me.btn_Account = New System.Windows.Forms.Button()
        Me.btn_Videos = New System.Windows.Forms.Button()
        Me.SidePanel = New System.Windows.Forms.Panel()
        Me.btn_PDF = New System.Windows.Forms.Button()
        Me.btn_Dashboard = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'MainPanel
        '
        Me.MainPanel.BackgroundImage = Global.LRS_Final.My.Resources.Resources.abstract
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainPanel.Location = New System.Drawing.Point(0, 57)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(1235, 509)
        Me.MainPanel.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Panel1.Controls.Add(Me.btn_Logout)
        Me.Panel1.Controls.Add(Me.btn_Account)
        Me.Panel1.Controls.Add(Me.btn_Videos)
        Me.Panel1.Controls.Add(Me.SidePanel)
        Me.Panel1.Controls.Add(Me.btn_PDF)
        Me.Panel1.Controls.Add(Me.btn_Dashboard)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.ForeColor = System.Drawing.Color.Transparent
        Me.Panel1.Location = New System.Drawing.Point(0, 566)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1235, 120)
        Me.Panel1.TabIndex = 3
        '
        'btn_Logout
        '
        Me.btn_Logout.FlatAppearance.BorderSize = 0
        Me.btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Logout.Font = New System.Drawing.Font("Montserrat", 15.0!)
        Me.btn_Logout.ForeColor = System.Drawing.Color.White
        Me.btn_Logout.Location = New System.Drawing.Point(784, 1)
        Me.btn_Logout.Name = "btn_Logout"
        Me.btn_Logout.Size = New System.Drawing.Size(197, 120)
        Me.btn_Logout.TabIndex = 5
        Me.btn_Logout.Text = "Log Out"
        Me.btn_Logout.UseVisualStyleBackColor = True
        '
        'btn_Account
        '
        Me.btn_Account.FlatAppearance.BorderSize = 0
        Me.btn_Account.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Account.Font = New System.Drawing.Font("Montserrat", 15.0!)
        Me.btn_Account.ForeColor = System.Drawing.Color.White
        Me.btn_Account.Location = New System.Drawing.Point(594, 1)
        Me.btn_Account.Name = "btn_Account"
        Me.btn_Account.Size = New System.Drawing.Size(197, 120)
        Me.btn_Account.TabIndex = 4
        Me.btn_Account.Text = "Manage Account"
        Me.btn_Account.UseVisualStyleBackColor = True
        '
        'btn_Videos
        '
        Me.btn_Videos.FlatAppearance.BorderSize = 0
        Me.btn_Videos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Videos.Font = New System.Drawing.Font("Montserrat", 15.0!)
        Me.btn_Videos.ForeColor = System.Drawing.Color.White
        Me.btn_Videos.Location = New System.Drawing.Point(401, 2)
        Me.btn_Videos.Name = "btn_Videos"
        Me.btn_Videos.Size = New System.Drawing.Size(197, 120)
        Me.btn_Videos.TabIndex = 3
        Me.btn_Videos.Text = "Manage Videos"
        Me.btn_Videos.UseVisualStyleBackColor = True
        '
        'SidePanel
        '
        Me.SidePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SidePanel.Location = New System.Drawing.Point(1, 110)
        Me.SidePanel.Name = "SidePanel"
        Me.SidePanel.Size = New System.Drawing.Size(196, 10)
        Me.SidePanel.TabIndex = 2
        '
        'btn_PDF
        '
        Me.btn_PDF.FlatAppearance.BorderSize = 0
        Me.btn_PDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_PDF.Font = New System.Drawing.Font("Montserrat", 15.0!)
        Me.btn_PDF.ForeColor = System.Drawing.Color.White
        Me.btn_PDF.Location = New System.Drawing.Point(198, 1)
        Me.btn_PDF.Name = "btn_PDF"
        Me.btn_PDF.Size = New System.Drawing.Size(197, 120)
        Me.btn_PDF.TabIndex = 1
        Me.btn_PDF.Text = "Manage PDF Files"
        Me.btn_PDF.UseVisualStyleBackColor = True
        '
        'btn_Dashboard
        '
        Me.btn_Dashboard.FlatAppearance.BorderSize = 0
        Me.btn_Dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Dashboard.Font = New System.Drawing.Font("Montserrat", 15.0!)
        Me.btn_Dashboard.ForeColor = System.Drawing.Color.White
        Me.btn_Dashboard.Location = New System.Drawing.Point(0, 1)
        Me.btn_Dashboard.Name = "btn_Dashboard"
        Me.btn_Dashboard.Size = New System.Drawing.Size(197, 120)
        Me.btn_Dashboard.TabIndex = 0
        Me.btn_Dashboard.Text = "Dashboard"
        Me.btn_Dashboard.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1235, 57)
        Me.Panel2.TabIndex = 4
        '
        'AdminDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.LRS_Final.My.Resources.Resources.abstract
        Me.ClientSize = New System.Drawing.Size(1235, 686)
        Me.Controls.Add(Me.MainPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AdminDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AdminDashboard"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents MainPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btn_Logout As System.Windows.Forms.Button
    Friend WithEvents btn_Account As System.Windows.Forms.Button
    Friend WithEvents btn_Videos As System.Windows.Forms.Button
    Friend WithEvents SidePanel As System.Windows.Forms.Panel
    Friend WithEvents btn_PDF As System.Windows.Forms.Button
    Friend WithEvents btn_Dashboard As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
