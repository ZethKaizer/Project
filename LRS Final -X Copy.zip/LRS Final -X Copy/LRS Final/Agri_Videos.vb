﻿Public Class Agri_Videos

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        AgriPanel.Show()

    End Sub
End Class