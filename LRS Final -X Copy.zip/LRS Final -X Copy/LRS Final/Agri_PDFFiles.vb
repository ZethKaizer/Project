﻿Public Class Agri_PDFFiles

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        AgriPanel.Show()

    End Sub
End Class