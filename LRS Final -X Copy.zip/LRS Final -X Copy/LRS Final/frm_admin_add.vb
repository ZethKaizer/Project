﻿Public Class frm_admin_add



    Private Sub frm_admin_add_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SidePanel.Width = Button1.Width
        SidePanel.Left = Button1.Left
        SidePanel.BringToFront()
    End Sub

    Sub switchPanel(ByVal panel As Form)
        MainPanel.Controls.Clear()
        panel.TopLevel = False
        MainPanel.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SidePanel.Width = Button1.Width
        SidePanel.Left = Button1.Left
        switchPanel(AdminDashboard)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        SidePanel.Width = Button2.Width
        SidePanel.Left = Button2.Left
        switchPanel(AdminPDFFiles)
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub
End Class

