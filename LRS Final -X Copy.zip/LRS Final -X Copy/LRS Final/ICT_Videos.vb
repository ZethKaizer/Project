﻿Public Class ICT_Videos

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        ICT_Panel.Show()

    End Sub
End Class