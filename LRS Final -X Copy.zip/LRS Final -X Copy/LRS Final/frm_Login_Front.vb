﻿Public Class frm_Login_Front
 
    Dim attempt As Integer = 1
  
    Private Sub BunifuCheckbox1_OnChange(sender As Object, e As EventArgs) Handles BunifuCheckbox1.OnChange
        'Show Password'
        If BunifuCheckbox1.Checked Then
            MaterialSingleLineTextField2.PasswordChar = ""
        Else
            MaterialSingleLineTextField2.PasswordChar = "•"
        End If

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        'Para to sa kapag nagkamali ng input yung user ng tatlong beses, mag-eexit yung program'

        Dim username, password As String
        username = MaterialSingleLineTextField1.Text
        password = MaterialSingleLineTextField2.Text

        If username = "admin" And password = "password" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            AdminDashboard.Show()

        ElseIf username = "user" And password = "password" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            frm_Main.Show()

        ElseIf attempt = 3 Then
            MessageBox.Show("Maximum number of Attempts (3). The Program will now close. ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            FileClose()
        Else
            MessageBox.Show("Incorrect Username or Password. Please re-enter. You currently have reached attempt " & attempt & " of 3. "" ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            attempt = attempt + 1
            MaterialSingleLineTextField1.Clear()
            MaterialSingleLineTextField2.Clear()
            MaterialSingleLineTextField1.Focus()
            If MaterialSingleLineTextField2.PasswordChar = "•" Then
                MaterialSingleLineTextField2.PasswordChar = ""
            End If
        End If
    End Sub

    Private Sub frm_admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MaterialSingleLineTextField2_TextChanged(sender As Object, e As EventArgs)
     
    End Sub

 

    Private Sub MaterialSingleLineTextField1_GotFocus1(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField1.GotFocus
        If MaterialSingleLineTextField1.Text = "Username" Then
            MaterialSingleLineTextField1.Text = ""
        End If

    End Sub

   

    Private Sub MaterialSingleLineTextField2_GotFocus1(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField2.GotFocus
        If MaterialSingleLineTextField2.Text = "Password" Then
            MaterialSingleLineTextField2.Text = ""
            MaterialSingleLineTextField2.PasswordChar = "•"
        ElseIf MaterialSingleLineTextField2.PasswordChar = "•" Then
            MaterialSingleLineTextField2.PasswordChar = "•"
        Else
            MaterialSingleLineTextField2.PasswordChar = ""
        End If

    End Sub

    Private Sub MaterialSingleLineTextField2_Click(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField2.Click
        If MaterialSingleLineTextField2.Text = "Password" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If
    End Sub



    Private Sub MaterialSingleLineTextField1_LostFocus1(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField1.LostFocus
        If MaterialSingleLineTextField1.Text = "" Then
            MaterialSingleLineTextField1.Text = "Username"
        End If
    End Sub



    Private Sub MaterialSingleLineTextField2_LostFocus1(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField2.LostFocus
        If MaterialSingleLineTextField2.Text = "" Then
            MaterialSingleLineTextField2.Text = "Password"
        End If
        If MaterialSingleLineTextField2.PasswordChar = "•" Then
            MaterialSingleLineTextField2.PasswordChar = "•"
        End If
        If MaterialSingleLineTextField2.Text = "Password" Then
            MaterialSingleLineTextField2.PasswordChar = ""
        End If

    End Sub
End Class
