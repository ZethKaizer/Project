﻿Public Class frm_admin_login
    Dim attempt As Integer = 1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs)
        frm_admin_add.Show()
        Me.Close()
    End Sub

    Private Sub BunifuThinButton22_Click_1(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        Me.Hide()
        frm_Main.Show()
    End Sub

    Private Sub TextBox1_GotFocus(sender As Object, e As EventArgs) Handles TextBox1.GotFocus
        'Kapag 'Username' yung naka-input sa textbox tapos clinick mo, maki-clear yung text nya'
        If TextBox1.Text = "Username" Then
            TextBox1.Text = ""
        End If
    End Sub

    Private Sub TextBox2_GotFocus(sender As Object, e As EventArgs) Handles TextBox2.GotFocus
        'Para hindi ma-show yung password kapag nag-click ka na sa ibang tools'

        If TextBox2.Text = "Password" Then
            TextBox2.Text = ""
            TextBox2.PasswordChar = "•"
        ElseIf TextBox2.PasswordChar = "•" Then
            TextBox2.PasswordChar = "•"
        Else
            TextBox2.PasswordChar = ""
        End If
    End Sub

    Private Sub TextBox1_LostFocus(sender As Object, e As EventArgs) Handles TextBox1.LostFocus
        'Kapag walang naka-input na text at nagclick ka sa ibang tools, mag-dedefault text siya as 'Username' na text. '
        If TextBox1.Text = "" Then
            TextBox1.Text = "Username"
        End If
    End Sub

    Private Sub TextBox2_LostFocus(sender As Object, e As EventArgs) Handles TextBox2.LostFocus
        'Para hindi maging '•' yung nakalagay sa text ng password kapag nag-click ka sa ibang tools'
        If TextBox2.Text = "" Then
            TextBox2.Text = "Password"
        End If
        If TextBox2.PasswordChar = "•" Then
            TextBox2.PasswordChar = "•"
        End If
        If TextBox2.Text = "Password" Then
            TextBox2.PasswordChar = ""
        End If
    End Sub

    Private Sub BunifuCheckbox1_OnChange(sender As Object, e As EventArgs) Handles BunifuCheckbox1.OnChange
        'Show Password'
        If BunifuCheckbox1.Checked Then
            TextBox2.PasswordChar = ""
        Else
            TextBox2.PasswordChar = "•"
        End If



    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        'Para to sa kapag nagkamali ng input yung user ng tatlong beses, mag-eexit yung program'

        Dim username, password As String
        username = TextBox1.Text
        password = TextBox2.Text

        If username = "admin" And password = "password" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            frm_admin_add.Show()

        ElseIf attempt = 3 Then
            MessageBox.Show("Maximum number of Attempts (3). The Program will now close. ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Close()
        Else
            MessageBox.Show("Incorrect Username or Password. Please re-enter. You currently have reached attempt " & attempt & " of 3. "" ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            attempt = attempt + 1
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox1.Focus()
            If TextBox2.PasswordChar = "•" Then
                TextBox2.PasswordChar = ""
            End If
        End If
    End Sub

    Private Sub frm_admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        If TextBox2.Text = "Password" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class