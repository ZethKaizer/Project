﻿Public Class frm_admin_add



    Private Sub frm_admin_add_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SidePanel.Width = btn_Dashboard.Width
        SidePanel.Left = btn_Dashboard.Left
        SidePanel.BringToFront()
    End Sub

 

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_Dashboard.Click
        SidePanel.Width = btn_Dashboard.Width
        SidePanel.Left = btn_Dashboard.Left
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_PDF.Click
        SidePanel.Width = btn_PDF.Width
        SidePanel.Left = btn_PDF.Left
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub
End Class

