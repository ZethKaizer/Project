﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminVideos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminVideos))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btn_Browse = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_Upload = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuProgressBar1 = New Bunifu.Framework.UI.BunifuProgressBar()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PlayItems = New Bunifu.Framework.UI.BunifuCheckbox()
        Me.BunifuSlider1 = New Bunifu.Framework.UI.BunifuSlider()
        Me.bunifuImageButton10 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.bunifuImageButton11 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton9 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton7 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton6 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton5 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel4.Controls.Add(Me.ListBox1)
        Me.Panel4.Controls.Add(Me.btn_Browse)
        Me.Panel4.Controls.Add(Me.btn_Upload)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(693, 50)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(542, 553)
        Me.Panel4.TabIndex = 85
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.White
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(25, 26)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(242, 377)
        Me.ListBox1.TabIndex = 77
        '
        'btn_Browse
        '
        Me.btn_Browse.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Browse.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Browse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Browse.BorderRadius = 7
        Me.btn_Browse.ButtonText = "   Browse"
        Me.btn_Browse.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Browse.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Browse.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Browse.Iconimage = Global.LRS_Final.My.Resources.Resources.browseIcon
        Me.btn_Browse.Iconimage_right = Nothing
        Me.btn_Browse.Iconimage_right_Selected = Nothing
        Me.btn_Browse.Iconimage_Selected = Nothing
        Me.btn_Browse.IconMarginLeft = 0
        Me.btn_Browse.IconMarginRight = 0
        Me.btn_Browse.IconRightVisible = True
        Me.btn_Browse.IconRightZoom = 0.0R
        Me.btn_Browse.IconVisible = True
        Me.btn_Browse.IconZoom = 50.0R
        Me.btn_Browse.IsTab = False
        Me.btn_Browse.Location = New System.Drawing.Point(35, 432)
        Me.btn_Browse.Name = "btn_Browse"
        Me.btn_Browse.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Browse.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Browse.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Browse.selected = False
        Me.btn_Browse.Size = New System.Drawing.Size(113, 36)
        Me.btn_Browse.TabIndex = 76
        Me.btn_Browse.Text = "   Browse"
        Me.btn_Browse.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Browse.Textcolor = System.Drawing.Color.White
        Me.btn_Browse.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'btn_Upload
        '
        Me.btn_Upload.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Upload.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Upload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Upload.BorderRadius = 7
        Me.btn_Upload.ButtonText = "  Upload"
        Me.btn_Upload.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Upload.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Upload.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Upload.Iconimage = Global.LRS_Final.My.Resources.Resources.uploadIcon
        Me.btn_Upload.Iconimage_right = Nothing
        Me.btn_Upload.Iconimage_right_Selected = Nothing
        Me.btn_Upload.Iconimage_Selected = Nothing
        Me.btn_Upload.IconMarginLeft = 0
        Me.btn_Upload.IconMarginRight = 0
        Me.btn_Upload.IconRightVisible = True
        Me.btn_Upload.IconRightZoom = 0.0R
        Me.btn_Upload.IconVisible = True
        Me.btn_Upload.IconZoom = 50.0R
        Me.btn_Upload.IsTab = False
        Me.btn_Upload.Location = New System.Drawing.Point(154, 432)
        Me.btn_Upload.Name = "btn_Upload"
        Me.btn_Upload.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Upload.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Upload.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Upload.selected = False
        Me.btn_Upload.Size = New System.Drawing.Size(113, 36)
        Me.btn_Upload.TabIndex = 75
        Me.btn_Upload.Text = "  Upload"
        Me.btn_Upload.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Upload.Textcolor = System.Drawing.Color.White
        Me.btn_Upload.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'BunifuProgressBar1
        '
        Me.BunifuProgressBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BunifuProgressBar1.BorderRadius = 5
        Me.BunifuProgressBar1.Location = New System.Drawing.Point(0, 486)
        Me.BunifuProgressBar1.MaximumValue = 100
        Me.BunifuProgressBar1.Name = "BunifuProgressBar1"
        Me.BunifuProgressBar1.ProgressColor = System.Drawing.Color.DodgerBlue
        Me.BunifuProgressBar1.Size = New System.Drawing.Size(693, 10)
        Me.BunifuProgressBar1.TabIndex = 0
        Me.BunifuProgressBar1.Value = 20
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.BunifuProgressBar1)
        Me.Panel3.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(0, 50)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(693, 553)
        Me.Panel3.TabIndex = 84
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(0, -1)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(693, 498)
        Me.AxWindowsMediaPlayer1.TabIndex = 78
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(345, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 17)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Autoplay"
        '
        'PlayItems
        '
        Me.PlayItems.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.PlayItems.ChechedOffColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.PlayItems.Checked = True
        Me.PlayItems.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.PlayItems.ForeColor = System.Drawing.Color.White
        Me.PlayItems.Location = New System.Drawing.Point(321, 29)
        Me.PlayItems.Name = "PlayItems"
        Me.PlayItems.Size = New System.Drawing.Size(20, 20)
        Me.PlayItems.TabIndex = 20
        '
        'BunifuSlider1
        '
        Me.BunifuSlider1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSlider1.BackgroudColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BunifuSlider1.BorderRadius = 0
        Me.BunifuSlider1.IndicatorColor = System.Drawing.Color.DodgerBlue
        Me.BunifuSlider1.Location = New System.Drawing.Point(561, 25)
        Me.BunifuSlider1.MaximumValue = 100
        Me.BunifuSlider1.Name = "BunifuSlider1"
        Me.BunifuSlider1.Size = New System.Drawing.Size(117, 30)
        Me.BunifuSlider1.TabIndex = 19
        Me.BunifuSlider1.Value = 20
        '
        'bunifuImageButton10
        '
        Me.bunifuImageButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton10.Image = CType(resources.GetObject("bunifuImageButton10.Image"), System.Drawing.Image)
        Me.bunifuImageButton10.ImageActive = Nothing
        Me.bunifuImageButton10.Location = New System.Drawing.Point(530, 26)
        Me.bunifuImageButton10.Name = "bunifuImageButton10"
        Me.bunifuImageButton10.Size = New System.Drawing.Size(25, 25)
        Me.bunifuImageButton10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton10.TabIndex = 18
        Me.bunifuImageButton10.TabStop = False
        Me.bunifuImageButton10.Zoom = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(206, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Windows Media Player"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.LRS_Final.My.Resources.Resources.vidIcon
        Me.PictureBox1.Location = New System.Drawing.Point(150, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(50, 47)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'bunifuImageButton11
        '
        Me.bunifuImageButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton11.Image = CType(resources.GetObject("bunifuImageButton11.Image"), System.Drawing.Image)
        Me.bunifuImageButton11.ImageActive = Nothing
        Me.bunifuImageButton11.Location = New System.Drawing.Point(155, 17)
        Me.bunifuImageButton11.Name = "bunifuImageButton11"
        Me.bunifuImageButton11.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton11.TabIndex = 17
        Me.bunifuImageButton11.TabStop = False
        Me.bunifuImageButton11.Zoom = 10
        '
        'bunifuImageButton9
        '
        Me.bunifuImageButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton9.Image = CType(resources.GetObject("bunifuImageButton9.Image"), System.Drawing.Image)
        Me.bunifuImageButton9.ImageActive = Nothing
        Me.bunifuImageButton9.Location = New System.Drawing.Point(442, 17)
        Me.bunifuImageButton9.Name = "bunifuImageButton9"
        Me.bunifuImageButton9.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton9.TabIndex = 16
        Me.bunifuImageButton9.TabStop = False
        Me.bunifuImageButton9.Zoom = 10
        '
        'bunifuImageButton7
        '
        Me.bunifuImageButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton7.Image = CType(resources.GetObject("bunifuImageButton7.Image"), System.Drawing.Image)
        Me.bunifuImageButton7.ImageActive = Nothing
        Me.bunifuImageButton7.Location = New System.Drawing.Point(219, 17)
        Me.bunifuImageButton7.Name = "bunifuImageButton7"
        Me.bunifuImageButton7.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton7.TabIndex = 15
        Me.bunifuImageButton7.TabStop = False
        Me.bunifuImageButton7.Zoom = 10
        '
        'bunifuImageButton6
        '
        Me.bunifuImageButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton6.Image = CType(resources.GetObject("bunifuImageButton6.Image"), System.Drawing.Image)
        Me.bunifuImageButton6.ImageActive = Nothing
        Me.bunifuImageButton6.Location = New System.Drawing.Point(82, 11)
        Me.bunifuImageButton6.Name = "bunifuImageButton6"
        Me.bunifuImageButton6.Size = New System.Drawing.Size(55, 55)
        Me.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton6.TabIndex = 14
        Me.bunifuImageButton6.TabStop = False
        Me.bunifuImageButton6.Zoom = 10
        '
        'bunifuImageButton5
        '
        Me.bunifuImageButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.bunifuImageButton5.Image = CType(resources.GetObject("bunifuImageButton5.Image"), System.Drawing.Image)
        Me.bunifuImageButton5.ImageActive = Nothing
        Me.bunifuImageButton5.Location = New System.Drawing.Point(21, 17)
        Me.bunifuImageButton5.Name = "bunifuImageButton5"
        Me.bunifuImageButton5.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton5.TabIndex = 13
        Me.bunifuImageButton5.TabStop = False
        Me.bunifuImageButton5.Zoom = 10
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1235, 50)
        Me.Panel1.TabIndex = 82
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.PlayItems)
        Me.Panel2.Controls.Add(Me.BunifuSlider1)
        Me.Panel2.Controls.Add(Me.bunifuImageButton10)
        Me.Panel2.Controls.Add(Me.bunifuImageButton11)
        Me.Panel2.Controls.Add(Me.bunifuImageButton9)
        Me.Panel2.Controls.Add(Me.bunifuImageButton7)
        Me.Panel2.Controls.Add(Me.bunifuImageButton6)
        Me.Panel2.Controls.Add(Me.bunifuImageButton5)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 603)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1235, 83)
        Me.Panel2.TabIndex = 83
        '
        'AdminVideos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1235, 686)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AdminVideos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AdminVideos"
        Me.Panel4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents btn_Browse As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_Upload As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuProgressBar1 As Bunifu.Framework.UI.BunifuProgressBar
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PlayItems As Bunifu.Framework.UI.BunifuCheckbox
    Friend WithEvents BunifuSlider1 As Bunifu.Framework.UI.BunifuSlider
    Private WithEvents bunifuImageButton10 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents bunifuImageButton11 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton9 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton7 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton6 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton5 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
