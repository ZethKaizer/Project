﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Manage_Users
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.Combobox_Usertype = New MetroFramework.Controls.MetroComboBox()
        Me.MaterialSingleLineTextField7 = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Textbox_DateCreated = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.Textbox_Email = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Textbox_ID = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Textbox_Name = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Pass = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Textbox_Username = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.btn_Update = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_Add = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Panel5.Controls.Add(Me.DataGridView1)
        Me.Panel5.Controls.Add(Me.lbl_date)
        Me.Panel5.Controls.Add(Me.Combobox_Usertype)
        Me.Panel5.Controls.Add(Me.MaterialSingleLineTextField7)
        Me.Panel5.Controls.Add(Me.Label9)
        Me.Panel5.Controls.Add(Me.BunifuFlatButton2)
        Me.Panel5.Controls.Add(Me.BunifuFlatButton1)
        Me.Panel5.Controls.Add(Me.Textbox_DateCreated)
        Me.Panel5.Controls.Add(Me.BunifuSeparator1)
        Me.Panel5.Controls.Add(Me.Textbox_Email)
        Me.Panel5.Controls.Add(Me.Label7)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.Textbox_ID)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Controls.Add(Me.Textbox_Name)
        Me.Panel5.Controls.Add(Me.Textbox_Pass)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Controls.Add(Me.Label8)
        Me.Panel5.Controls.Add(Me.Textbox_Username)
        Me.Panel5.Controls.Add(Me.btn_Update)
        Me.Panel5.Controls.Add(Me.btn_Add)
        Me.Panel5.Controls.Add(Me.BunifuFlatButton6)
        Me.Panel5.Controls.Add(Me.Label6)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(976, 629)
        Me.Panel5.TabIndex = 25
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(330, 114)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(633, 493)
        Me.DataGridView1.TabIndex = 71
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lbl_date.ForeColor = System.Drawing.Color.Gray
        Me.lbl_date.Location = New System.Drawing.Point(689, 21)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(0, 20)
        Me.lbl_date.TabIndex = 70
        '
        'Combobox_Usertype
        '
        Me.Combobox_Usertype.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Combobox_Usertype.FormattingEnabled = True
        Me.Combobox_Usertype.ItemHeight = 23
        Me.Combobox_Usertype.Items.AddRange(New Object() {"", "Admin", "User"})
        Me.Combobox_Usertype.Location = New System.Drawing.Point(22, 395)
        Me.Combobox_Usertype.Name = "Combobox_Usertype"
        Me.Combobox_Usertype.Size = New System.Drawing.Size(274, 29)
        Me.Combobox_Usertype.TabIndex = 69
        Me.Combobox_Usertype.UseSelectable = True
        '
        'MaterialSingleLineTextField7
        '
        Me.MaterialSingleLineTextField7.Depth = 0
        Me.MaterialSingleLineTextField7.Hint = ""
        Me.MaterialSingleLineTextField7.Location = New System.Drawing.Point(330, 77)
        Me.MaterialSingleLineTextField7.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialSingleLineTextField7.Name = "MaterialSingleLineTextField7"
        Me.MaterialSingleLineTextField7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.MaterialSingleLineTextField7.SelectedText = ""
        Me.MaterialSingleLineTextField7.SelectionLength = 0
        Me.MaterialSingleLineTextField7.SelectionStart = 0
        Me.MaterialSingleLineTextField7.Size = New System.Drawing.Size(522, 23)
        Me.MaterialSingleLineTextField7.TabIndex = 68
        Me.MaterialSingleLineTextField7.UseSystemPasswordChar = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(19, 439)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 20)
        Me.Label9.TabIndex = 67
        Me.Label9.Text = "Date Created"
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 7
        Me.BunifuFlatButton2.ButtonText = "  Clear"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = Global.LRS_Final.My.Resources.Resources.clearIcon
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0.0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 70.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(161, 501)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(135, 50)
        Me.BunifuFlatButton2.TabIndex = 66
        Me.BunifuFlatButton2.Text = "  Clear"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 7
        Me.BunifuFlatButton1.ButtonText = "Search"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = Global.LRS_Final.My.Resources.Resources._105498_200
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconMarginLeft = 0
        Me.BunifuFlatButton1.IconMarginRight = 0
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0.0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 50.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(858, 65)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton1.selected = False
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(105, 35)
        Me.BunifuFlatButton1.TabIndex = 65
        Me.BunifuFlatButton1.Text = "Search"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Textbox_DateCreated
        '
        Me.Textbox_DateCreated.Depth = 0
        Me.Textbox_DateCreated.Hint = ""
        Me.Textbox_DateCreated.Location = New System.Drawing.Point(23, 462)
        Me.Textbox_DateCreated.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_DateCreated.Name = "Textbox_DateCreated"
        Me.Textbox_DateCreated.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_DateCreated.SelectedText = ""
        Me.Textbox_DateCreated.SelectionLength = 0
        Me.Textbox_DateCreated.SelectionStart = 0
        Me.Textbox_DateCreated.Size = New System.Drawing.Size(273, 23)
        Me.Textbox_DateCreated.TabIndex = 64
        Me.Textbox_DateCreated.UseSystemPasswordChar = False
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(309, 13)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(15, 649)
        Me.BunifuSeparator1.TabIndex = 63
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = True
        '
        'Textbox_Email
        '
        Me.Textbox_Email.Depth = 0
        Me.Textbox_Email.Hint = ""
        Me.Textbox_Email.Location = New System.Drawing.Point(22, 335)
        Me.Textbox_Email.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Email.Name = "Textbox_Email"
        Me.Textbox_Email.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Email.SelectedText = ""
        Me.Textbox_Email.SelectionLength = 0
        Me.Textbox_Email.SelectionStart = 0
        Me.Textbox_Email.Size = New System.Drawing.Size(274, 23)
        Me.Textbox_Email.TabIndex = 62
        Me.Textbox_Email.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(17, 309)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 20)
        Me.Label7.TabIndex = 61
        Me.Label7.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(18, 370)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "User Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(17, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 20)
        Me.Label2.TabIndex = 52
        Me.Label2.Text = "ID"
        '
        'Textbox_ID
        '
        Me.Textbox_ID.Depth = 0
        Me.Textbox_ID.Hint = ""
        Me.Textbox_ID.Location = New System.Drawing.Point(20, 77)
        Me.Textbox_ID.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_ID.Name = "Textbox_ID"
        Me.Textbox_ID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_ID.SelectedText = ""
        Me.Textbox_ID.SelectionLength = 0
        Me.Textbox_ID.SelectionStart = 0
        Me.Textbox_ID.Size = New System.Drawing.Size(276, 23)
        Me.Textbox_ID.TabIndex = 51
        Me.Textbox_ID.UseSystemPasswordChar = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(18, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 20)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "Name"
        '
        'Textbox_Name
        '
        Me.Textbox_Name.Depth = 0
        Me.Textbox_Name.Hint = ""
        Me.Textbox_Name.Location = New System.Drawing.Point(20, 137)
        Me.Textbox_Name.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Name.Name = "Textbox_Name"
        Me.Textbox_Name.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Name.SelectedText = ""
        Me.Textbox_Name.SelectionLength = 0
        Me.Textbox_Name.SelectionStart = 0
        Me.Textbox_Name.Size = New System.Drawing.Size(276, 23)
        Me.Textbox_Name.TabIndex = 54
        Me.Textbox_Name.UseSystemPasswordChar = False
        '
        'Textbox_Pass
        '
        Me.Textbox_Pass.Depth = 0
        Me.Textbox_Pass.Hint = ""
        Me.Textbox_Pass.Location = New System.Drawing.Point(22, 266)
        Me.Textbox_Pass.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Pass.Name = "Textbox_Pass"
        Me.Textbox_Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.Textbox_Pass.SelectedText = ""
        Me.Textbox_Pass.SelectionLength = 0
        Me.Textbox_Pass.SelectionStart = 0
        Me.Textbox_Pass.Size = New System.Drawing.Size(274, 23)
        Me.Textbox_Pass.TabIndex = 58
        Me.Textbox_Pass.UseSystemPasswordChar = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(18, 173)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "User Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Gray
        Me.Label8.Location = New System.Drawing.Point(18, 241)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 20)
        Me.Label8.TabIndex = 57
        Me.Label8.Text = "Password"
        '
        'Textbox_Username
        '
        Me.Textbox_Username.Depth = 0
        Me.Textbox_Username.Hint = ""
        Me.Textbox_Username.Location = New System.Drawing.Point(21, 198)
        Me.Textbox_Username.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Username.Name = "Textbox_Username"
        Me.Textbox_Username.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Username.SelectedText = ""
        Me.Textbox_Username.SelectionLength = 0
        Me.Textbox_Username.SelectionStart = 0
        Me.Textbox_Username.Size = New System.Drawing.Size(276, 23)
        Me.Textbox_Username.TabIndex = 56
        Me.Textbox_Username.UseSystemPasswordChar = False
        '
        'btn_Update
        '
        Me.btn_Update.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Update.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Update.BorderRadius = 7
        Me.btn_Update.ButtonText = "  Update"
        Me.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Update.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Update.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Update.Iconimage = Global.LRS_Final.My.Resources.Resources.updateicon
        Me.btn_Update.Iconimage_right = Nothing
        Me.btn_Update.Iconimage_right_Selected = Nothing
        Me.btn_Update.Iconimage_Selected = Nothing
        Me.btn_Update.IconMarginLeft = 0
        Me.btn_Update.IconMarginRight = 0
        Me.btn_Update.IconRightVisible = True
        Me.btn_Update.IconRightZoom = 0.0R
        Me.btn_Update.IconVisible = True
        Me.btn_Update.IconZoom = 50.0R
        Me.btn_Update.IsTab = False
        Me.btn_Update.Location = New System.Drawing.Point(20, 557)
        Me.btn_Update.Name = "btn_Update"
        Me.btn_Update.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Update.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Update.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Update.selected = False
        Me.btn_Update.Size = New System.Drawing.Size(135, 50)
        Me.btn_Update.TabIndex = 3
        Me.btn_Update.Text = "  Update"
        Me.btn_Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Update.Textcolor = System.Drawing.Color.White
        Me.btn_Update.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'btn_Add
        '
        Me.btn_Add.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Add.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Add.BorderRadius = 7
        Me.btn_Add.ButtonText = "  Add"
        Me.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Add.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Add.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Add.Iconimage = Global.LRS_Final.My.Resources.Resources.addicon
        Me.btn_Add.Iconimage_right = Nothing
        Me.btn_Add.Iconimage_right_Selected = Nothing
        Me.btn_Add.Iconimage_Selected = Nothing
        Me.btn_Add.IconMarginLeft = 0
        Me.btn_Add.IconMarginRight = 0
        Me.btn_Add.IconRightVisible = True
        Me.btn_Add.IconRightZoom = 0.0R
        Me.btn_Add.IconVisible = True
        Me.btn_Add.IconZoom = 70.0R
        Me.btn_Add.IsTab = False
        Me.btn_Add.Location = New System.Drawing.Point(20, 501)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Add.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Add.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Add.selected = False
        Me.btn_Add.Size = New System.Drawing.Size(135, 50)
        Me.btn_Add.TabIndex = 2
        Me.btn_Add.Text = "  Add"
        Me.btn_Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Add.Textcolor = System.Drawing.Color.White
        Me.btn_Add.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'BunifuFlatButton6
        '
        Me.BunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton6.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton6.BorderRadius = 7
        Me.BunifuFlatButton6.ButtonText = "Delete"
        Me.BunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton6.Iconimage = Global.LRS_Final.My.Resources.Resources.delete_1432400_1211078
        Me.BunifuFlatButton6.Iconimage_right = Nothing
        Me.BunifuFlatButton6.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton6.Iconimage_Selected = Nothing
        Me.BunifuFlatButton6.IconMarginLeft = 0
        Me.BunifuFlatButton6.IconMarginRight = 0
        Me.BunifuFlatButton6.IconRightVisible = True
        Me.BunifuFlatButton6.IconRightZoom = 0.0R
        Me.BunifuFlatButton6.IconVisible = True
        Me.BunifuFlatButton6.IconZoom = 80.0R
        Me.BunifuFlatButton6.IsTab = False
        Me.BunifuFlatButton6.Location = New System.Drawing.Point(161, 557)
        Me.BunifuFlatButton6.Name = "BunifuFlatButton6"
        Me.BunifuFlatButton6.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton6.selected = False
        Me.BunifuFlatButton6.Size = New System.Drawing.Size(135, 50)
        Me.BunifuFlatButton6.TabIndex = 1
        Me.BunifuFlatButton6.Text = "Delete"
        Me.BunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton6.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label6.Location = New System.Drawing.Point(579, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 29)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Records"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label1.Location = New System.Drawing.Point(13, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please Fill up The Form"
        '
        'Timer1
        '
        '
        'Admin_Manage_Users
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.Controls.Add(Me.Panel5)
        Me.Name = "Admin_Manage_Users"
        Me.Size = New System.Drawing.Size(976, 629)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btn_Update As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_Add As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton6 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Name As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Pass As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Textbox_ID As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Username As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Email As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents Textbox_DateCreated As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents MaterialSingleLineTextField7 As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Combobox_Usertype As MetroFramework.Controls.MetroComboBox
    Friend WithEvents lbl_date As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView

End Class
