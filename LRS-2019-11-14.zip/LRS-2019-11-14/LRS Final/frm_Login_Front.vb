﻿Public Class frm_Login_Front
 
    Dim attempt As Integer = 1
  
    Private Sub BunifuCheckbox1_OnChange(sender As Object, e As EventArgs) Handles BunifuCheckbox1.OnChange
        'Show Password'
        If BunifuCheckbox1.Checked Then
            MaterialSingleLineTextField2.PasswordChar = ""
        Else
            MaterialSingleLineTextField2.PasswordChar = "•"
        End If

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        'Para to sa kapag nagkamali ng input yung user ng tatlong beses, mag-eexit yung program'

        Dim username, password As String
        username = MaterialSingleLineTextField1.Text
        password = MaterialSingleLineTextField2.Text

        If username = "admin" And password = "password" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            
            frm_Front.Hide()
            AdminDashboard.Show()
            MaterialSingleLineTextField1.Text = ""
            MaterialSingleLineTextField2.Text = ""


        ElseIf username = "user" And password = "password" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            frm_Front.Hide()
            frm_Main.Show()
            MaterialSingleLineTextField1.Text = ""
            MaterialSingleLineTextField2.Text = ""

        ElseIf attempt = 3 Then
            MessageBox.Show("Maximum number of Attempts (3). The Program will now close. ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            frm_Front.Close()
        Else
            MessageBox.Show("Incorrect Username or Password. Please re-enter. You currently have reached attempt " & attempt & " of 3. "" ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            attempt = attempt + 1
            MaterialSingleLineTextField1.Clear()
            MaterialSingleLineTextField2.Clear()
            MaterialSingleLineTextField1.Focus()
            If MaterialSingleLineTextField2.PasswordChar = "•" Then
                MaterialSingleLineTextField2.PasswordChar = ""
            End If
        End If
    End Sub

    Private Sub frm_admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MaterialSingleLineTextField1.Focus()
    End Sub

    Private Sub MaterialSingleLineTextField2_TextChanged(sender As Object, e As EventArgs)
     
    End Sub

 

    Private Sub MaterialSingleLineTextField1_GotFocus1(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField1.Text = "Username" Then
            MaterialSingleLineTextField1.Text = ""
        End If

    End Sub

   

    
    Private Sub MaterialSingleLineTextField2_Click(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField2.Text = "Password" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If
    End Sub



    
    Private Sub MaterialSingleLineTextField1_Click(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField1.Click

    End Sub
End Class
