﻿Imports MySql.Data.MySqlClient
Public Class frm_Login_Front
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"


    Dim attempt As Integer = 1

    Private Sub BunifuCheckbox1_OnChange(sender As Object, e As EventArgs) Handles BunifuCheckbox1.OnChange
        'Show Password'
        If BunifuCheckbox1.Checked Then
            MaterialSingleLineTextField2.PasswordChar = ""
        Else
            MaterialSingleLineTextField2.PasswordChar = "•"
        End If

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        'Para to sa kapag nagkamali ng input yung user ng tatlong beses, mag-eexit yung program'
        login()
       
    End Sub

    Private Sub login()

        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim cmd As MySqlCommand = New MySqlCommand("select * from tbl_user where user_username='" & MaterialSingleLineTextField1.Text & "' and user_pass ='" & MaterialSingleLineTextField2.Text & "'and user_usertype='" & Combobox_Usertype.Text & "'", conn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        da.Fill(dt)
        If (dt.Rows.Count > 0) Then
            MessageBox.Show("You logined as " + dt.Rows(0)(2))
            If Combobox_Usertype.SelectedIndex = 1 Then
                Dim a As New AdminDashboard
                a.Show()
                Me.Hide()
            Else
                Dim main As New frm_Main
                main.Show()
                Me.Hide()
            End If
        Else
            MessageBox.Show("Error")
        End If




    End Sub


    Private Sub frm_admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MaterialSingleLineTextField1.Focus()
    End Sub

    Private Sub MaterialSingleLineTextField2_TextChanged(sender As Object, e As EventArgs)

    End Sub



    Private Sub MaterialSingleLineTextField1_GotFocus1(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField1.Text = "Username" Then
            MaterialSingleLineTextField1.Text = ""
        End If

    End Sub




    Private Sub MaterialSingleLineTextField2_Click(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField2.Text = "Password" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If
    End Sub




    Private Sub MaterialSingleLineTextField1_Click(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField1.Click

    End Sub
End Class
