﻿Imports WMPLib
Public Class AdminVideos

    Private Sub btn_Browse_Click(sender As Object, e As EventArgs) Handles btn_Browse.Click


        OpenFileDialog1.Multiselect = True
        OpenFileDialog1.ShowDialog()
        For Each s As String In OpenFileDialog1.FileNames
            ListBox1.Items.Add(s)
        Next
        Me.ListBox1.SelectedIndex = Me.ListBox1.SelectedIndex + 1
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Dim itemNo As Integer
            itemNo = ListBox1.SelectedIndex

            If Me.AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsStopped Then
                Me.ListBox1.SelectedIndex = itemNo + 1
                AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
                Timer1.Start()
            Else
                Timer1.Start()
            End If

        Catch ex As Exception
            If PlayItems.Checked = True Then
                ListBox1.SelectedIndex = "0"
                AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
            Else
                AxWindowsMediaPlayer1.URL = ""
                ListBox1.SelectedIndex = "0"
            End If
        End Try
    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        If ListBox1.Items.Count = 0 = True Then
            MsgBox("Nothing to Play")
        Else
            AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
            Timer1.Start()
        End If
    End Sub

    Private Sub AdminVideos_Load(sender As Object, e As EventArgs) Handles Me.Load
        AxWindowsMediaPlayer1.uiMode = "none"
    End Sub

    Private Sub btn_Upload_Click(sender As Object, e As EventArgs) Handles btn_Upload.Click

    End Sub

    Private Sub PlayItems_OnChange(sender As Object, e As EventArgs) Handles PlayItems.OnChange

    End Sub
End Class
