﻿Imports WMPLib
Public Class Admin_Videos

    Private Sub btn_Browse_Click(sender As Object, e As EventArgs) Handles btn_Browse.Click
        Dim ofd As New OpenFileDialog
        ofd.InitialDirectory = "C:\Users\user\Documents\Visual Studio 2012\Projects\LRS-2019-11-23\LRS Final\bin\Debug\LRS_Videos\Videos_Agriculture"
        ofd.Multiselect = True
        ofd.ShowDialog()
        For I As Integer = 0 To ofd.FileNames.Count - 1
            ListBox1.Items.Add(ofd.SafeFileNames(I))

        Next
        If ListBox1.Items.Count = 0 = True Then
            MsgBox("Choose Video")
        Else
            ListBox1.SelectedIndex = 0
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        AxWindowsMediaPlayer1.stretchToFit = True

        If PlayItems.Checked = True Then
            If AxWindowsMediaPlayer1.playState = WMPPlayState.wmppsPlaying = True Then
                'nothing
            ElseIf AxWindowsMediaPlayer1.playState = WMPPlayState.wmppsStopped = True Then
                ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
                AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
            End If
        End If

    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        If ListBox1.Items.Count = 0 = True Then
            MsgBox("Nothing to Play")
        Else
            AxWindowsMediaPlayer1.URL = ListBox1.SelectedItem
        End If
    End Sub

    Private Sub Admin_Videos_Load(sender As Object, e As EventArgs) Handles Me.Load
        AxWindowsMediaPlayer1.uiMode = "none"
    End Sub
End Class
