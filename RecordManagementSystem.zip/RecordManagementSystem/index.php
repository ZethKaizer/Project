<!DOCTYPE html>
<html>
<head>
	<title>Record Management System</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<form action="" method="post" class="p-4">
	<div class="form-group">
		<input type="text" name="username" class="form-control form-control-lg" placeholder="Username" required>
	</div>
	<div class="form-group">
		<input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required>
	</div>
	

</form>
</body>
</html>