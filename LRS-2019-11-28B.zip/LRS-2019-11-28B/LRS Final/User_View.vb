﻿Imports System.IO
Imports WMPLib
Public Class User_View

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub AxAcroPDF1_Enter(sender As Object, e As EventArgs) Handles AxAcroPDF1.Enter

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 1 Then
            ListBox1.Items.Clear()
            PDF_ICT()
        ElseIf ComboBox1.SelectedIndex = 2 Then
            ListBox1.Items.Clear()
            PDF_HE()
        ElseIf ComboBox1.SelectedIndex = 3 Then
            ListBox1.Items.Clear()
            PDF_Agriculture()
        End If
        If ListBox1.Items.Count = 0 Then
            ListBox1.Items.Add("Nothing to display.")
        End If
    End Sub

    Private Sub PDF_ICT()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_ICT"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub PDF_HE()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_HE"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub PDF_Agriculture()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_Agriculture"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.Items.Count = 0 Then
            ListBox1.Items.Add("Nothing to display.")
        End If
        Try
            AxAcroPDF1.src = ListBox1.SelectedItem

        Catch ex As Exception

        End Try
    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs) Handles Panel5.Paint

    End Sub

    Private Sub bunifuImageButton9_Click(sender As Object, e As EventArgs) Handles bunifuImageButton9.Click
        AxWindowsMediaPlayer1.fullScreen = True
    End Sub

    Private Sub bunifuImageButton6_Click_1(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        AxWindowsMediaPlayer1.Ctlcontrols.play()
    End Sub

    Private Sub bunifuImageButton11_Click(sender As Object, e As EventArgs) Handles bunifuImageButton11.Click
        AxWindowsMediaPlayer1.Ctlcontrols.pause()
    End Sub

    Private Sub BunifuSlider1_ValueChanged(sender As Object, e As EventArgs) Handles BunifuSlider1.ValueChanged
        AxWindowsMediaPlayer1.settings.volume = BunifuSlider1.Value
    End Sub




    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged
        If ListBox2.Items.Count = 0 Then
            ListBox2.Items.Add("Nothing to display.")
        End If
        Try
            AxWindowsMediaPlayer1.URL = ListBox2.SelectedItem
            lbl_Title.Text = AxWindowsMediaPlayer1.currentMedia.name.ToString()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.SelectedIndex = 1 Then
            ListBox2.Items.Clear()
            Videos_ICT()
        ElseIf ComboBox2.SelectedIndex = 2 Then
            ListBox2.Items.Clear()
            Videos_HE()
        ElseIf ComboBox1.SelectedIndex = 3 Then
            ListBox2.Items.Clear()
            Videos_Agriculture()
        End If

    End Sub
    Private Sub Videos_ICT()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos\Videos_ICT"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.mp4")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox2.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub Videos_HE()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos\Videos_HE"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.mp4")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox2.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub Videos_Agriculture()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_Videos\Videos_Agriculture"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.mp4")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox2.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        AxWindowsMediaPlayer1.stretchToFit = True
    End Sub

    Private Sub AxWindowsMediaPlayer1_Enter(sender As Object, e As EventArgs) Handles AxWindowsMediaPlayer1.Enter

    End Sub

    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs) Handles BunifuImageButton1.Click
        Me.Controls.Clear()
        InitializeComponent()
        user_view_load(e, e)
    End Sub

    Private Sub User_View_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs) Handles BunifuImageButton2.Click
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to exit the program? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            MetroFramework.MetroMessageBox.Show(Me, "Program Successfully Exit! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Exit()
        End If
    End Sub
End Class