﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Update_User
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Combobox_Usertype = New MetroFramework.Controls.MetroComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Textbox_DateCreated = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Email = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Textbox_ID = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Textbox_Name = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Pass = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Textbox_Username = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_Update = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(171, 603)
        Me.Panel1.TabIndex = 123
        '
        'Combobox_Usertype
        '
        Me.Combobox_Usertype.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Combobox_Usertype.FormattingEnabled = True
        Me.Combobox_Usertype.ItemHeight = 23
        Me.Combobox_Usertype.Items.AddRange(New Object() {"", "Admin", "User"})
        Me.Combobox_Usertype.Location = New System.Drawing.Point(204, 407)
        Me.Combobox_Usertype.Name = "Combobox_Usertype"
        Me.Combobox_Usertype.Size = New System.Drawing.Size(388, 29)
        Me.Combobox_Usertype.TabIndex = 122
        Me.Combobox_Usertype.UseSelectable = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(201, 451)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 20)
        Me.Label9.TabIndex = 121
        Me.Label9.Text = "Date Created"
        '
        'Textbox_DateCreated
        '
        Me.Textbox_DateCreated.Depth = 0
        Me.Textbox_DateCreated.Hint = ""
        Me.Textbox_DateCreated.Location = New System.Drawing.Point(205, 480)
        Me.Textbox_DateCreated.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_DateCreated.Name = "Textbox_DateCreated"
        Me.Textbox_DateCreated.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_DateCreated.SelectedText = ""
        Me.Textbox_DateCreated.SelectionLength = 0
        Me.Textbox_DateCreated.SelectionStart = 0
        Me.Textbox_DateCreated.Size = New System.Drawing.Size(387, 23)
        Me.Textbox_DateCreated.TabIndex = 119
        Me.Textbox_DateCreated.UseSystemPasswordChar = False
        '
        'Textbox_Email
        '
        Me.Textbox_Email.Depth = 0
        Me.Textbox_Email.Hint = ""
        Me.Textbox_Email.Location = New System.Drawing.Point(204, 347)
        Me.Textbox_Email.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Email.Name = "Textbox_Email"
        Me.Textbox_Email.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Email.SelectedText = ""
        Me.Textbox_Email.SelectionLength = 0
        Me.Textbox_Email.SelectionStart = 0
        Me.Textbox_Email.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Email.TabIndex = 118
        Me.Textbox_Email.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(199, 321)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 20)
        Me.Label7.TabIndex = 117
        Me.Label7.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(200, 382)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 116
        Me.Label5.Text = "User Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(199, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 20)
        Me.Label2.TabIndex = 109
        Me.Label2.Text = "ID"
        '
        'Textbox_ID
        '
        Me.Textbox_ID.Depth = 0
        Me.Textbox_ID.Hint = ""
        Me.Textbox_ID.Location = New System.Drawing.Point(202, 89)
        Me.Textbox_ID.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_ID.Name = "Textbox_ID"
        Me.Textbox_ID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_ID.SelectedText = ""
        Me.Textbox_ID.SelectionLength = 0
        Me.Textbox_ID.SelectionStart = 0
        Me.Textbox_ID.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_ID.TabIndex = 108
        Me.Textbox_ID.UseSystemPasswordChar = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(200, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 20)
        Me.Label3.TabIndex = 110
        Me.Label3.Text = "Name"
        '
        'Textbox_Name
        '
        Me.Textbox_Name.Depth = 0
        Me.Textbox_Name.Hint = ""
        Me.Textbox_Name.Location = New System.Drawing.Point(202, 149)
        Me.Textbox_Name.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Name.Name = "Textbox_Name"
        Me.Textbox_Name.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Name.SelectedText = ""
        Me.Textbox_Name.SelectionLength = 0
        Me.Textbox_Name.SelectionStart = 0
        Me.Textbox_Name.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_Name.TabIndex = 111
        Me.Textbox_Name.UseSystemPasswordChar = False
        '
        'Textbox_Pass
        '
        Me.Textbox_Pass.Depth = 0
        Me.Textbox_Pass.Hint = ""
        Me.Textbox_Pass.Location = New System.Drawing.Point(204, 278)
        Me.Textbox_Pass.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Pass.Name = "Textbox_Pass"
        Me.Textbox_Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Pass.SelectedText = ""
        Me.Textbox_Pass.SelectionLength = 0
        Me.Textbox_Pass.SelectionStart = 0
        Me.Textbox_Pass.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Pass.TabIndex = 115
        Me.Textbox_Pass.UseSystemPasswordChar = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(200, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 112
        Me.Label4.Text = "User Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Gray
        Me.Label8.Location = New System.Drawing.Point(200, 253)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 20)
        Me.Label8.TabIndex = 114
        Me.Label8.Text = "Password"
        '
        'Textbox_Username
        '
        Me.Textbox_Username.Depth = 0
        Me.Textbox_Username.Hint = ""
        Me.Textbox_Username.Location = New System.Drawing.Point(203, 210)
        Me.Textbox_Username.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Username.Name = "Textbox_Username"
        Me.Textbox_Username.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Username.SelectedText = ""
        Me.Textbox_Username.SelectionLength = 0
        Me.Textbox_Username.SelectionStart = 0
        Me.Textbox_Username.Size = New System.Drawing.Size(389, 23)
        Me.Textbox_Username.TabIndex = 113
        Me.Textbox_Username.UseSystemPasswordChar = False
        '
        'Timer1
        '
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label1.Location = New System.Drawing.Point(259, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 29)
        Me.Label1.TabIndex = 106
        Me.Label1.Text = "Please Fill up The Form"
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 7
        Me.BunifuFlatButton2.ButtonText = "  Cancel"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = Global.LRS_Final.My.Resources.Resources.clearIcon
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0.0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 70.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(476, 519)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(116, 50)
        Me.BunifuFlatButton2.TabIndex = 120
        Me.BunifuFlatButton2.Text = "  Cancel"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'btn_Update
        '
        Me.btn_Update.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Update.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Update.BorderRadius = 7
        Me.btn_Update.ButtonText = "  Update"
        Me.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Update.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Update.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Update.Iconimage = Global.LRS_Final.My.Resources.Resources.updateicon
        Me.btn_Update.Iconimage_right = Nothing
        Me.btn_Update.Iconimage_right_Selected = Nothing
        Me.btn_Update.Iconimage_Selected = Nothing
        Me.btn_Update.IconMarginLeft = 0
        Me.btn_Update.IconMarginRight = 0
        Me.btn_Update.IconRightVisible = True
        Me.btn_Update.IconRightZoom = 0.0R
        Me.btn_Update.IconVisible = True
        Me.btn_Update.IconZoom = 40.0R
        Me.btn_Update.IsTab = False
        Me.btn_Update.Location = New System.Drawing.Point(354, 519)
        Me.btn_Update.Name = "btn_Update"
        Me.btn_Update.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_Update.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn_Update.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Update.selected = False
        Me.btn_Update.Size = New System.Drawing.Size(116, 50)
        Me.btn_Update.TabIndex = 107
        Me.btn_Update.Text = "  Update"
        Me.btn_Update.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Update.Textcolor = System.Drawing.Color.White
        Me.btn_Update.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Admin_Update_User
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(619, 603)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Combobox_Usertype)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.BunifuFlatButton2)
        Me.Controls.Add(Me.Textbox_DateCreated)
        Me.Controls.Add(Me.Textbox_Email)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Textbox_ID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Textbox_Name)
        Me.Controls.Add(Me.Textbox_Pass)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Textbox_Username)
        Me.Controls.Add(Me.btn_Update)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Update_User"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin_Update_User"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Combobox_Usertype As MetroFramework.Controls.MetroComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Textbox_DateCreated As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Email As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Textbox_ID As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Name As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Pass As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Textbox_Username As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents btn_Update As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
