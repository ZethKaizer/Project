﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin_Manage_Users

    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim admin_dashboard As New Admin_Dashboard
    Dim ds As DataSet


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)

    

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        If BunifuMetroTextbox1.Text = Nothing Then
            MetroFramework.MetroMessageBox.Show(Me, "Select Account to be Update!", "Select Account", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Admin_Update_User.Show()
        End If
    End Sub


    Private Sub btn_Add_Click_2(sender As Object, e As EventArgs) Handles btn_Add.Click
        Admin_Create_User.Show()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = DataGridView1.Rows(e.RowIndex)
            BunifuMetroTextbox1.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_ID.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_Name.Text = row.Cells("user_name").Value.ToString
            Admin_Update_User.Textbox_Username.Text = row.Cells("user_username").Value.ToString
            Admin_Update_User.Textbox_Pass.Text = row.Cells("user_pass").Value.ToString
            Admin_Update_User.Textbox_Email.Text = row.Cells("user_email").Value.ToString
            Admin_Update_User.Combobox_Usertype.Text = row.Cells("user_usertype").Value.ToString
            Admin_Update_User.Textbox_DateCreated.Text = row.Cells("user_datecreated").Value.ToString



        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Admin_Manage_Users_Load(sender As Object, e As EventArgs) Handles Me.Load
        loadData()
        tableHeader()
    End Sub

    Public Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New MySqlDataAdapter("Select * from tbl_user", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
        Timer1.Enabled = True
    End Sub

    Private Sub tableHeader()

        DataGridView1.Columns(0).Width = 50
        DataGridView1.Columns(1).Width = 200
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 150

        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(1).HeaderText = "Name"
        DataGridView1.Columns(2).HeaderText = "User Name"
        DataGridView1.Columns(3).HeaderText = "Password"
        DataGridView1.Columns(4).HeaderText = "Email"
        DataGridView1.Columns(5).HeaderText = "User Type"
        DataGridView1.Columns(6).HeaderText = "Date Created"
    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        deleteUser()
    End Sub

    Private Sub deleteUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Deleted! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                conn.Open()
                Dim query As String
                query = "Delete from tbl_user where user_id = '" & BunifuMetroTextbox1.Text & "'"
                cmd = New MySqlCommand(query, conn)
                BunifuMetroTextbox1.Text = ""
                dr = cmd.ExecuteReader
                conn.Close()
                loadData()
                tableHeader()

            End If

        Catch ex As Exception

            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tableHeader()
            End If
        End Try
    End Sub

    Private Sub BunifuMetroTextbox2_OnValueChanged(sender As Object, e As EventArgs) Handles BunifuMetroTextbox2.OnValueChanged
        searchData(BunifuMetroTextbox2.Text)
    End Sub

    Public Sub searchData(valuetoSearch As String)

        Dim searchQuery As String = "select * from tbl_user where concat(user_id, user_name, user_username, user_pass, user_email, user_usertype, user_datecreated) like '%" & valuetoSearch & "%'"
        Dim command As New MySqlCommand(searchQuery, conn)
        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub BunifuMetroTextbox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles BunifuMetroTextbox1.KeyPress
        e.Handled = True
    End Sub

    Private Sub BunifuMetroTextbox1_OnValueChanged(sender As Object, e As EventArgs) Handles BunifuMetroTextbox1.OnValueChanged

    End Sub
End Class
