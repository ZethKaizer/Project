﻿Imports MySql.Data.MySqlClient
Public Class frm_Login_Front
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"


    Dim attempt As Integer = 1

    Private Sub BunifuCheckbox1_OnChange(sender As Object, e As EventArgs) Handles BunifuCheckbox1.OnChange
        'Show Password'
        If BunifuCheckbox1.Checked Then
            MaterialSingleLineTextField2.PasswordChar = ""
        Else
            MaterialSingleLineTextField2.PasswordChar = "•"
        End If

        If MaterialSingleLineTextField2.Text = "" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click

        mainlogin()
      

        
       
    End Sub
    Private Sub mainlogin()
        If MaterialSingleLineTextField1.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your User Name!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf MaterialSingleLineTextField2.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your Password!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf Combobox_Usertype.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your User Type!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If Combobox_Usertype.SelectedIndex = 0 Then
                login()
            ElseIf Combobox_Usertype.SelectedIndex = 1 Then
                MetroFramework.MetroMessageBox.Show(Me, "Log In Successful! Welcome User!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                frm_Front.Hide()
                User_View.Show()
            End If
        End If

    End Sub

    Private Sub login()

        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim cmd As MySqlCommand = New MySqlCommand("select * from tbl_user where user_username='" & MaterialSingleLineTextField1.Text & "' and user_pass ='" & MaterialSingleLineTextField2.Text & "'and user_usertype='" & Combobox_Usertype.Text & "'", conn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        da.Fill(dt)
        If (dt.Rows.Count > 0) Then
            MetroFramework.MetroMessageBox.Show(Me, "Welcome, " + dt.Rows(0)(2) + "! Log In Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            If Combobox_Usertype.SelectedIndex = 0 Then
                Dim a As New AdminDashboard
                a.Show()
                Me.Hide()
                frm_Front.Hide()
            Else
            End If
        Else

            MetroFramework.MetroMessageBox.Show(Me, "The Username you entered is invalid! Please ask the Administrator before you log in.", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If



    End Sub


    Private Sub frm_admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MaterialSingleLineTextField1.Focus()
    End Sub

    Private Sub MaterialSingleLineTextField2_TextChanged(sender As Object, e As EventArgs)

    End Sub



    Private Sub MaterialSingleLineTextField1_GotFocus1(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField1.Text = "Username" Then
            MaterialSingleLineTextField1.Text = ""
        End If

    End Sub




    Private Sub MaterialSingleLineTextField2_Click(sender As Object, e As EventArgs)
        If MaterialSingleLineTextField2.Text = "Password" Then
            BunifuCheckbox1.Enabled = False
        Else
            BunifuCheckbox1.Enabled = True
        End If
    End Sub




    Private Sub MaterialSingleLineTextField1_Click(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField1.Click

    End Sub

    Private Sub MaterialSingleLineTextField2_Click_1(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField2.Click
        
    End Sub

    Private Sub Combobox_Usertype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combobox_Usertype.SelectedIndexChanged
        If Combobox_Usertype.SelectedIndex = 1 Then
            MaterialSingleLineTextField1.Enabled = False
            MaterialSingleLineTextField2.Enabled = False
            Combobox_Usertype.Enabled = False
            BunifuFlatButton1.Text = "              Proceed"
        Else
            MaterialSingleLineTextField1.Enabled = True
            MaterialSingleLineTextField2.Enabled = True
            BunifuFlatButton1.Text = "              Login"
        End If
    End Sub

    Private Sub BunifuFlatButton1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles BunifuFlatButton1.KeyPress
    

    End Sub
End Class
