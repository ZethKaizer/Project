﻿Public Class frm_Front

   

    Private Sub frm_Front_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs)


    End Sub


    Private Sub frm_Front_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()
    End Sub

    
 

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Frm_Login_Front1.BringToFront()
        Frm_Login_Front1.Visible = True
    End Sub
End Class
