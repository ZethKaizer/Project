﻿Imports MySql.Data.MySqlClient
Public Class Admin_Update_User
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim admin_dashboard As New Admin_Dashboard
    Dim ds As DataSet


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Textbox_DateCreated.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Me.Hide()
    End Sub


    Private Sub btn_Update_Click(sender As Object, e As EventArgs) Handles btn_Update.Click
        updateUser()
    End Sub

    Private Sub updateUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to update this user? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Updated! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                conn.Open()
                Dim query As String
                query = "Update tbl_user Set user_name = '" & Textbox_Name.Text & "', user_username = '" & Textbox_Username.Text & "', user_pass = '" & Textbox_Pass.Text & "', user_email = '" & Textbox_Email.Text & "', user_usertype = '" & Combobox_Usertype.Text & "' WHERE user_id = '" & Textbox_ID.Text & "'"
                cmd = New MySqlCommand(query, conn)
                dr = cmd.ExecuteReader
                conn.Close()


                cleardata()


            End If

        Catch ex As Exception
            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        End Try

        
    End Sub

    Private Sub clearData()
        Textbox_Email.Text = ""
        Textbox_Name.Text = ""
        Textbox_Username.Text = ""
        Textbox_Pass.Text = ""
        Combobox_Usertype.Text = ""
    End Sub

    Private Sub autogenerateID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_user", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select Max(user_id) as MaxID from tbl_user"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        Textbox_ID.Text = intid
        CN.Close()
    End Sub
End Class