﻿Imports System.IO
Public Class AdminDashboard

    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs) Handles BunifuImageButton1.Click
        Me.Controls.Clear()
        InitializeComponent()
        admindashboard_load(e, e)
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        SidePanel.Height = BunifuFlatButton1.Height
        SidePanel.Top = BunifuFlatButton1.Top
        Admin_Dashboard1.BringToFront()
    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs) Handles BunifuImageButton2.Click
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to exit the program? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            MetroFramework.MetroMessageBox.Show(Me, "Program Successfully Exit! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Exit()
        End If
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        SidePanel.Height = BunifuFlatButton2.Height
        SidePanel.Top = BunifuFlatButton2.Top
        Admin_PDFFiles1.BringToFront()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        SidePanel.Height = BunifuFlatButton3.Height
        SidePanel.Top = BunifuFlatButton3.Top
        Admin_Videos1.BringToFront()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        SidePanel.Height = BunifuFlatButton4.Height
        SidePanel.Top = BunifuFlatButton4.Top
        Admin_Manage_Users1.BringToFront()
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        SidePanel.Height = BunifuFlatButton5.Height
        SidePanel.Top = BunifuFlatButton5.Top
        If MessageBox.Show("Are you sure you want to log out?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then
            Me.Hide()
            frm_Front.Show()
        End If
    End Sub

    Private Sub AdminDashboard_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class