﻿Public Class AdminDashboard

    
    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        SidePanel.Height = BunifuFlatButton1.Height
        SidePanel.Top = BunifuFlatButton1.Top
        Admin_Dashboard1.BringToFront()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        SidePanel.Height = BunifuFlatButton2.Height
        SidePanel.Top = BunifuFlatButton2.Top
        Admin_PDFFiles1.BringToFront()
        
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        SidePanel.Height = BunifuFlatButton3.Height
        SidePanel.Top = BunifuFlatButton3.Top
        Admin_Videos2.BringToFront()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        SidePanel.Height = BunifuFlatButton4.Height
        SidePanel.Top = BunifuFlatButton4.Top
        Admin_Manage_Users1.BringToFront()
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs)
        
    End Sub

    Private Sub Admin_Manage_Users1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel12_Paint(sender As Object, e As PaintEventArgs)




    End Sub


    Private Sub AdminDashboard_Load(sender As Object, e As EventArgs) Handles Me.Load
        SidePanel.Height = BunifuFlatButton1.Height
        SidePanel.Top = BunifuFlatButton1.Top
        SidePanel.BringToFront()
    End Sub


    Private Sub BunifuFlatButton5_Click_1(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        SidePanel.Height = BunifuFlatButton5.Height
        SidePanel.Top = BunifuFlatButton5.Top
        If MessageBox.Show("Are you sure you want to log out?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then
            Me.Hide()
            frm_Front.Show()
        End If
    End Sub
End Class