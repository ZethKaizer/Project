﻿Imports MySql.Data.MySqlClient

Public Class Admin_PDFFiles
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim query, getName, _path, secretDtrows

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click

    End Sub
    Private Sub ViewDG()
        Dim dt_table As New DataTable
        Dim dtAdptr As New MySqlDataAdapter
        Dim bndSource As New BindingSource
        With dtAdptr
            Try
                conn.Open()
                query = "select * from tbl_pdf"

                cmd = New MySqlCommand(query, conn)
                .SelectCommand = cmd
                .Fill(dt_table)
                bndSource.DataSource = dt_table

                BunifuCustomDataGrid1.DataSource = dt_table

            Catch ex As Exception
                MsgBox("Check Your Connection!!",
                                MsgBoxStyle.Exclamation, "Lost Conn")
            End Try
            conn.Close()
        End With
    End Sub

    Private Sub BrowseFile() Handles BunifuFlatButton8.Click
        OpenFileDialog1.Filter = " Choose File (*.pdf) | *.pdf;"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Title = "Select File Pdf.."
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub OpfD() Handles OpenFileDialog1.FileOk
        _path = System.IO.Path.
                GetFullPath(
                            OpenFileDialog1.FileName
                            )
        getName = System.IO.Path.
            GetFileName(OpenFileDialog1.FileName
                        )



        AxAcroPDF1.src = _path
    End Sub

    Private Sub Admin_PDFFiles_Load(sender As Object, e As EventArgs) Handles Me.Load
        ViewDG()
    End Sub
End Class
