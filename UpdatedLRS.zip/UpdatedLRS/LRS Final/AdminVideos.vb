﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class AdminVideos
    Dim conn As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=admin_video_db")
    Private Sub btn_Dashboard_Click(sender As Object, e As EventArgs)
        Me.Hide()
        AdminDashboard.Show()

    End Sub

    Private Sub btn_PDF_Click(sender As Object, e As EventArgs)
        Me.Hide()
        AdminPDFFiles.Show()
    End Sub

    Private Sub btn_Videos_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub

 
 
    Private Sub BunifuThinButton23_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
    
    End Sub

  

    Private Sub AxWindowsMediaPlayer1_Enter(ms As MemoryStream, p2 As String)

    End Sub

  
    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs)


    End Sub
End Class