﻿Imports MySql.Data.MySqlClient
Public Class Admin_Manage_Users
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"


    Private Sub Admin_Manage_Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        autogenerateID()

        'BunifuCustomDataGrid1.BringToFront()


        Timer1.Enabled = True


    End Sub
    Private Sub autogenerateID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_users", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select Max(users_id) as MaxID from tbl_users"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        MaterialSingleLineTextField1.Text = intid
        CN.Close()
    End Sub



    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete this user?", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxIcon.Warning)
    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from tbl_users order by ID asc"
        Dim da As New MySqlDataAdapter(com, conn)




    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click

    End Sub


    Private Sub btn_Add_Click(sender As Object, e As EventArgs)
        addUser()
    End Sub
    Public Sub addUser()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New MySqlCommand
        cmd.Connection = conn
        cmd.CommandText = "INSERT INTO tbl_users(users_id, users_lastname, users_firstname, users_middlename, users_username, users_password, users_usertype, users_datecreated) VALUES('', '" & MaterialSingleLineTextField2.Text & "', '" & MaterialSingleLineTextField3.Text & "','" & MaterialSingleLineTextField4.Text & "','" & MaterialSingleLineTextField5.Text & "', '" & MaterialSingleLineTextField6.Text & "', '" & MetroComboBox1.Text & "', '" & lbl_date.Text & "')"
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Private Sub btn_Add_Click_1(sender As Object, e As EventArgs) Handles btn_Add.Click
        addUser()
    End Sub



   
    Private Sub lbl_date_Click(sender As Object, e As EventArgs) Handles lbl_date.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lbl_date.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub
End Class
