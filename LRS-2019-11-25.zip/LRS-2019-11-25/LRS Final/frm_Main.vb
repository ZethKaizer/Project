﻿Public Class frm_Main


    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    
    Private Sub Button1_Click(sender As Object, e As EventArgs)


    End Sub

   

    Private Sub frm_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs)

    End Sub

   

    Private Sub Panel3_Paint_1(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub

    Private Sub SidePanel_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Me.Hide()
        AdminDashboard.Show()

    End Sub

   

   

End Class