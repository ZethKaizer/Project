﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin_Manage_Users
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter

    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"


    Private Sub Admin_Manage_Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'BunifuCustomDataGrid1.BringToFront()
        Timer1.Enabled = True
        loadData()
        DataGridView1.Columns(0).Width = 50
        DataGridView1.Columns(1).Width = 200
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 150
        database()
    End Sub




    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete this user?", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxIcon.Warning)
    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from tbl_user order by ID asc"
        Dim da As New MySqlDataAdapter(com, conn)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton8.Click
        If BunifuMetroTextbox1.Text = Nothing Then
            MetroFramework.MetroMessageBox.Show(Me, "Select Account to be Update!", "Select Account", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Admin_Update_User.Show()
        End If
    End Sub


    Private Sub btn_Add_Click(sender As Object, e As EventArgs)

    End Sub
   


    Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New MySqlDataAdapter("Select * from tbl_user", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
        Timer1.Enabled = True
    End Sub

    Private Sub btn_Add_Click_1(sender As Object, e As EventArgs)

    End Sub

    Sub database()
        conn = New MySqlConnection
        conn.ConnectionString =
            CONNECTION_STRING
        Dim Query As String = "select * from tbl_user"
        Dim adpt As New MySqlDataAdapter(Query, conn)
        Dim ds As New DataSet()
        adpt.Fill(ds, "user_id")
        DataGridView1.DataSource = ds.Tables(0)
        conn.Close()
    End Sub


    Private Sub lbl_date_Click(sender As Object, e As EventArgs) Handles lbl_date.Click

    End Sub



    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub Textbox_ID_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Textbox_ID_KeyPress(sender As Object, e As KeyPressEventArgs)
        e.Handled = True
    End Sub

    Private Sub Combobox_Usertype_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btn_Add_Click_2(sender As Object, e As EventArgs)
        Admin_Create_User.Show()
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub MaterialSingleLineTextField7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btn_Add_Click_3(sender As Object, e As EventArgs) Handles btn_Add.Click
        Admin_Create_User.Show()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = DataGridView1.Rows(e.RowIndex)
            BunifuMetroTextbox1.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_ID.Text = row.Cells("user_id").Value.ToString
            Admin_Update_User.Textbox_Name.Text = row.Cells("user_name").Value.ToString
            Admin_Update_User.Textbox_Username.Text = row.Cells("user_username").Value.ToString
            Admin_Update_User.Textbox_Pass.Text = row.Cells("user_pass").Value.ToString
            Admin_Update_User.Textbox_Email.Text = row.Cells("user_email").Value.ToString
            Admin_Update_User.Combobox_Usertype.Text = row.Cells("user_usertype").Value.ToString
            Admin_Update_User.Textbox_DateCreated.Text = row.Cells("user_datecreated").Value.ToString


    
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs) Handles Panel5.Paint

    End Sub
End Class
