﻿Public Class Admin_Videos

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub BunifuFlatButton8_Click(sender As Object, e As EventArgs)
        OpenFileDialog1.Filter = "(*.mp4) | *.mp4"

    End Sub


    Private Sub BunifuFlatButton10_Click(sender As Object, e As EventArgs)
    End Sub


    Private Sub BunifuFlatButton9_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub MaterialSingleLineTextField6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub
End Class
