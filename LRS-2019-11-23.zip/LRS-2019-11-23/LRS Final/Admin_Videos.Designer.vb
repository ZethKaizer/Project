﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Videos
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Videos))
        Me.BunifuFlatButton8 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.BunifuProgressBar1 = New Bunifu.Framework.UI.BunifuProgressBar()
        Me.bunifuImageButton11 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton9 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton7 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton6 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton5 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuImageButton10 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.BunifuSlider1 = New Bunifu.Framework.UI.BunifuSlider()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuFlatButton8
        '
        Me.BunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton8.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton8.BorderRadius = 7
        Me.BunifuFlatButton8.ButtonText = "   Browse"
        Me.BunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton8.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton8.Iconimage = Global.LRS_Final.My.Resources.Resources.browseIcon
        Me.BunifuFlatButton8.Iconimage_right = Nothing
        Me.BunifuFlatButton8.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton8.Iconimage_Selected = Nothing
        Me.BunifuFlatButton8.IconMarginLeft = 0
        Me.BunifuFlatButton8.IconMarginRight = 0
        Me.BunifuFlatButton8.IconRightVisible = True
        Me.BunifuFlatButton8.IconRightZoom = 0.0R
        Me.BunifuFlatButton8.IconVisible = True
        Me.BunifuFlatButton8.IconZoom = 50.0R
        Me.BunifuFlatButton8.IsTab = False
        Me.BunifuFlatButton8.Location = New System.Drawing.Point(35, 432)
        Me.BunifuFlatButton8.Name = "BunifuFlatButton8"
        Me.BunifuFlatButton8.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton8.selected = False
        Me.BunifuFlatButton8.Size = New System.Drawing.Size(113, 36)
        Me.BunifuFlatButton8.TabIndex = 76
        Me.BunifuFlatButton8.Text = "   Browse"
        Me.BunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton8.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton8.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'BunifuFlatButton6
        '
        Me.BunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton6.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton6.BorderRadius = 7
        Me.BunifuFlatButton6.ButtonText = "  Upload"
        Me.BunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton6.Iconimage = Global.LRS_Final.My.Resources.Resources.uploadIcon
        Me.BunifuFlatButton6.Iconimage_right = Nothing
        Me.BunifuFlatButton6.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton6.Iconimage_Selected = Nothing
        Me.BunifuFlatButton6.IconMarginLeft = 0
        Me.BunifuFlatButton6.IconMarginRight = 0
        Me.BunifuFlatButton6.IconRightVisible = True
        Me.BunifuFlatButton6.IconRightZoom = 0.0R
        Me.BunifuFlatButton6.IconVisible = True
        Me.BunifuFlatButton6.IconZoom = 50.0R
        Me.BunifuFlatButton6.IsTab = False
        Me.BunifuFlatButton6.Location = New System.Drawing.Point(154, 432)
        Me.BunifuFlatButton6.Name = "BunifuFlatButton6"
        Me.BunifuFlatButton6.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton6.selected = False
        Me.BunifuFlatButton6.Size = New System.Drawing.Size(113, 36)
        Me.BunifuFlatButton6.TabIndex = 75
        Me.BunifuFlatButton6.Text = "  Upload"
        Me.BunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton6.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(976, 50)
        Me.Panel1.TabIndex = 78
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.LRS_Final.My.Resources.Resources.vidIcon
        Me.PictureBox1.Location = New System.Drawing.Point(150, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(50, 47)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(206, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Windows Media Player"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Panel2.Controls.Add(Me.BunifuSlider1)
        Me.Panel2.Controls.Add(Me.bunifuImageButton10)
        Me.Panel2.Controls.Add(Me.bunifuImageButton11)
        Me.Panel2.Controls.Add(Me.bunifuImageButton9)
        Me.Panel2.Controls.Add(Me.bunifuImageButton7)
        Me.Panel2.Controls.Add(Me.bunifuImageButton6)
        Me.Panel2.Controls.Add(Me.bunifuImageButton5)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 546)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(976, 83)
        Me.Panel2.TabIndex = 79
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.BunifuProgressBar1)
        Me.Panel3.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(0, 50)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(693, 496)
        Me.Panel3.TabIndex = 80
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(0, -1)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(693, 498)
        Me.AxWindowsMediaPlayer1.TabIndex = 78
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel4.Controls.Add(Me.ListBox1)
        Me.Panel4.Controls.Add(Me.BunifuFlatButton8)
        Me.Panel4.Controls.Add(Me.BunifuFlatButton6)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(693, 50)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(283, 496)
        Me.Panel4.TabIndex = 81
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.White
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(25, 26)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(242, 377)
        Me.ListBox1.TabIndex = 77
        '
        'BunifuProgressBar1
        '
        Me.BunifuProgressBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BunifuProgressBar1.BorderRadius = 5
        Me.BunifuProgressBar1.Location = New System.Drawing.Point(0, 486)
        Me.BunifuProgressBar1.MaximumValue = 100
        Me.BunifuProgressBar1.Name = "BunifuProgressBar1"
        Me.BunifuProgressBar1.ProgressColor = System.Drawing.Color.DodgerBlue
        Me.BunifuProgressBar1.Size = New System.Drawing.Size(693, 10)
        Me.BunifuProgressBar1.TabIndex = 0
        Me.BunifuProgressBar1.Value = 20
        '
        'bunifuImageButton11
        '
        Me.bunifuImageButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton11.Image = CType(resources.GetObject("bunifuImageButton11.Image"), System.Drawing.Image)
        Me.bunifuImageButton11.ImageActive = Nothing
        Me.bunifuImageButton11.Location = New System.Drawing.Point(155, 17)
        Me.bunifuImageButton11.Name = "bunifuImageButton11"
        Me.bunifuImageButton11.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton11.TabIndex = 17
        Me.bunifuImageButton11.TabStop = False
        Me.bunifuImageButton11.Zoom = 10
        '
        'bunifuImageButton9
        '
        Me.bunifuImageButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton9.Image = CType(resources.GetObject("bunifuImageButton9.Image"), System.Drawing.Image)
        Me.bunifuImageButton9.ImageActive = Nothing
        Me.bunifuImageButton9.Location = New System.Drawing.Point(353, 11)
        Me.bunifuImageButton9.Name = "bunifuImageButton9"
        Me.bunifuImageButton9.Size = New System.Drawing.Size(55, 55)
        Me.bunifuImageButton9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton9.TabIndex = 16
        Me.bunifuImageButton9.TabStop = False
        Me.bunifuImageButton9.Zoom = 10
        '
        'bunifuImageButton7
        '
        Me.bunifuImageButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton7.Image = CType(resources.GetObject("bunifuImageButton7.Image"), System.Drawing.Image)
        Me.bunifuImageButton7.ImageActive = Nothing
        Me.bunifuImageButton7.Location = New System.Drawing.Point(219, 17)
        Me.bunifuImageButton7.Name = "bunifuImageButton7"
        Me.bunifuImageButton7.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton7.TabIndex = 15
        Me.bunifuImageButton7.TabStop = False
        Me.bunifuImageButton7.Zoom = 10
        '
        'bunifuImageButton6
        '
        Me.bunifuImageButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton6.Image = CType(resources.GetObject("bunifuImageButton6.Image"), System.Drawing.Image)
        Me.bunifuImageButton6.ImageActive = Nothing
        Me.bunifuImageButton6.Location = New System.Drawing.Point(82, 11)
        Me.bunifuImageButton6.Name = "bunifuImageButton6"
        Me.bunifuImageButton6.Size = New System.Drawing.Size(55, 55)
        Me.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton6.TabIndex = 14
        Me.bunifuImageButton6.TabStop = False
        Me.bunifuImageButton6.Zoom = 10
        '
        'bunifuImageButton5
        '
        Me.bunifuImageButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton5.Image = CType(resources.GetObject("bunifuImageButton5.Image"), System.Drawing.Image)
        Me.bunifuImageButton5.ImageActive = Nothing
        Me.bunifuImageButton5.Location = New System.Drawing.Point(21, 17)
        Me.bunifuImageButton5.Name = "bunifuImageButton5"
        Me.bunifuImageButton5.Size = New System.Drawing.Size(45, 45)
        Me.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton5.TabIndex = 13
        Me.bunifuImageButton5.TabStop = False
        Me.bunifuImageButton5.Zoom = 10
        '
        'bunifuImageButton10
        '
        Me.bunifuImageButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.bunifuImageButton10.Image = CType(resources.GetObject("bunifuImageButton10.Image"), System.Drawing.Image)
        Me.bunifuImageButton10.ImageActive = Nothing
        Me.bunifuImageButton10.Location = New System.Drawing.Point(530, 26)
        Me.bunifuImageButton10.Name = "bunifuImageButton10"
        Me.bunifuImageButton10.Size = New System.Drawing.Size(25, 25)
        Me.bunifuImageButton10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton10.TabIndex = 18
        Me.bunifuImageButton10.TabStop = False
        Me.bunifuImageButton10.Zoom = 10
        '
        'BunifuSlider1
        '
        Me.BunifuSlider1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSlider1.BackgroudColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BunifuSlider1.BorderRadius = 0
        Me.BunifuSlider1.IndicatorColor = System.Drawing.Color.DodgerBlue
        Me.BunifuSlider1.Location = New System.Drawing.Point(561, 25)
        Me.BunifuSlider1.MaximumValue = 100
        Me.BunifuSlider1.Name = "BunifuSlider1"
        Me.BunifuSlider1.Size = New System.Drawing.Size(117, 30)
        Me.BunifuSlider1.TabIndex = 19
        Me.BunifuSlider1.Value = 20
        '
        'Admin_Videos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Admin_Videos"
        Me.Size = New System.Drawing.Size(976, 629)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.bunifuImageButton11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BunifuFlatButton8 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton6 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents BunifuSlider1 As Bunifu.Framework.UI.BunifuSlider
    Private WithEvents bunifuImageButton10 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton11 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton9 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton7 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton6 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuImageButton5 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents BunifuProgressBar1 As Bunifu.Framework.UI.BunifuProgressBar


End Class
