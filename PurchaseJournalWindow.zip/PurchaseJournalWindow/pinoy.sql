-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2020 at 02:44 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pinoy`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `ID` int(11) NOT NULL,
  `ProductCode` varchar(20) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `QtyAvailable` double(16,2) NOT NULL,
  `QtyRetail` double(16,2) NOT NULL,
  `Units` varchar(10) DEFAULT NULL,
  `UnitPrice` double(16,2) DEFAULT NULL,
  `RetailUnit` varchar(10) DEFAULT NULL,
  `RetailPrice` double(16,2) DEFAULT NULL,
  `ReorderPoint` double(16,2) DEFAULT NULL,
  `MaxQty` double(16,2) DEFAULT NULL,
  `Company` varchar(55) NOT NULL,
  `TradePrice` double NOT NULL,
  `StockGroup` varchar(10) NOT NULL,
  `ExpiryDate` date NOT NULL,
  `CompanyCode` varchar(15) NOT NULL,
  `Classification` varchar(15) NOT NULL,
  `GenericName` varchar(45) NOT NULL,
  `QtyActual` int(11) NOT NULL,
  `LastUpdated` date NOT NULL,
  `TaxType` varchar(15) NOT NULL,
  `Locked` tinyint(3) UNSIGNED NOT NULL,
  `Carry` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbluserdata`
--

CREATE TABLE `tbluserdata` (
  `UserName` varchar(20) DEFAULT NULL,
  `Secret` varchar(20) DEFAULT NULL,
  `Class` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `MidName` varchar(50) DEFAULT NULL,
  `Sex` varchar(10) DEFAULT NULL,
  `Designation` varchar(50) DEFAULT NULL,
  `UserClass` varchar(10) DEFAULT NULL,
  `ContactNum` varchar(30) DEFAULT NULL,
  `CompanyID` varchar(10) DEFAULT NULL,
  `PINCode` varchar(10) NOT NULL,
  `SeriesNo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbluserdata`
--
ALTER TABLE `tbluserdata`
  ADD PRIMARY KEY (`SeriesNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbluserdata`
--
ALTER TABLE `tbluserdata`
  MODIFY `SeriesNo` double NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
