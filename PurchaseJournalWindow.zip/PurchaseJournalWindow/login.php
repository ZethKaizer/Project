<!DOCTYPE html>
<html>
<head>
	<title>Purchase Journal Window</title>
	<?php include 'tags.php';?>
</head>

<?php



 ?>

<body>
<div class="container">
	<h3 class="text-center p-4 font-weight-light">Access Window</h3>
	<div class="row justify-content-center">
		<div class="col-lg-4 bg-light mt-2 px-0" style="background: white !important; border: solid 1px #d8dee2 !important; border-radius: 10px;">
		
		<form action="" method="post" class="p-4">

		<div class="form-group">
			<label for="usr">Username:</label>
			<input type="text" name="username" class="form-control form-control" required>
		</div>
		<div class="form-group">
			<label for="usr">Password:</label>
			<input type="password" name="password" class="form-control form-control" required>
		</div>
		
		<div class="btn-group btn-group-toggle form-group" data-toggle="buttons" style="width: 100% !important;">
              <label for='regular'  class="btn btn-outline-dark ">
                  <input type="radio" class="custom-control-input" required id="regular" name="employee_type" value="regular"/>Admin
              </label>
              <label for='Job Order' class="btn btn-outline-dark">
                <input type="radio" class="custom-control-input" required id="Job Order" name="employee_type" value="Job Order"/>User
              </label>
          </div>

		<div class="form-group">
			<span><input type="submit" class="btn btn-block btn-dark" value="Login" ></span>
		</div>
		</form>
	</div>
</div>
</div>

</body>
</html>