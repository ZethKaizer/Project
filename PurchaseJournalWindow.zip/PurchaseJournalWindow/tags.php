<!-- To make your web page responsive -->	
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1"> 

<!-- These tags are support for Bootstrap's CSS and Javscript from Bootstrap.-->

	<!-- Latest compiled and minified CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<!-- jQuery library -->
	
	<!-- Latest compiled JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  	<!-- Link for Bootstrap Icons -->
	<link rel="stylesheet" href="css/all.css">
	<script src="js/all.js"></script>

	<!-- Link to style web page (CSS Link) -->
	<link rel="stylesheet" type="text/css" href="css/style.css">