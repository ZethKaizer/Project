﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class Admin_PDFFiles
   
    Private Sub btn_Upload_Click(sender As Object, e As EventArgs) Handles btn_Upload.Click
        OpenFileDialog1.Filter = "PDF Files (*.pdf)|*.pdf"

        Dim SelectedDestinationFile = ComboBox2.SelectedItem
        If IsNothing(SelectedDestinationFile) = False Then

            Dim destinationFile = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_" + SelectedDestinationFile


            'Disable MultiSelect
            OpenFileDialog1.Multiselect = False
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                ListBox1.Items.Clear()
                For Each str As String In OpenFileDialog1.FileNames
                    Dim sourceFile = str
                    'AxAcroPDF1.src = OpenFileDialog1.FileName
                    ComboBox1.Text = ""
                    ComboBox1.SelectedText = ComboBox2.SelectedItem

                    'Will create a directory if not exist
                    Directory.CreateDirectory(destinationFile)
                    'Will copy the files
                    File.Copy(sourceFile, Path.Combine(destinationFile, Path.GetFileName(sourceFile)), True)
                    'Load Files
                    Dim strFileSize As String = ""
                    Dim di As New IO.DirectoryInfo(destinationFile)
                    Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
                    Dim fi As IO.FileInfo

                    For Each fi In aryFi
                        ListBox1.Items.Add(fi.FullName)
                    Next

                Next
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Uploaded! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Please select folder")
        End If


    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 1 Then
            ListBox1.Items.Clear()
            PDF_ICT()
        ElseIf ComboBox1.SelectedIndex = 2 Then
            ListBox1.Items.Clear()
            PDF_HE()
        ElseIf ComboBox1.SelectedIndex = 3 Then
            ListBox1.Items.Clear()
            PDF_Agriculture()
        End If
        If ListBox1.Items.Count = 0 Then
            ListBox1.Items.Add("Nothing to display.")
        End If
    End Sub

    Private Sub PDF_ICT()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_ICT"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub PDF_HE()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_HE"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub PDF_Agriculture()
        Dim directory = AppDomain.CurrentDomain.BaseDirectory + "LRS_PDF\PDF_Agriculture"
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pdf")
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            ListBox1.Items.Add(fi.FullName)
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.Items.Count = 0 Then
            ListBox1.Items.Add("Nothing to display.")
        End If
    End Sub

    Private Sub bunifuImageButton6_Click(sender As Object, e As EventArgs) Handles bunifuImageButton6.Click
        Try
            AxAcroPDF1.src = ListBox1.SelectedItem
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ListBox1.SelectedIndex > ListBox1.Items.Count - 1 = True Then
            ListBox1.SelectedIndex = 0
        Else
            AxAcroPDF1 = ListBox1.SelectedItem
        End If
    End Sub
End Class
