﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin_Manage_Users

    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer
    Dim admin_dashboard As New Admin_Dashboard
    Dim ds As DataSet


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)

    Private Sub Admin_Manage_Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'BunifuCustomDataGrid1.BringToFront()
        Timer1.Enabled = True
        tableHeader()
        loadData()
        autogenerateID()
        searchData("")
    End Sub



    Private Sub autogenerateID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_user", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select max(user_id) as MaxID from tbl_user"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        Textbox_ID.Text = intid
        CN.Close()
    End Sub





    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        deleteUser()


    End Sub

    Private Sub tableHeader()

        DataGridView1.Columns(0).Width = 50
        DataGridView1.Columns(1).Width = 200
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 150
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 150

        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(1).HeaderText = "Name"
        DataGridView1.Columns(2).HeaderText = "User Name"
        DataGridView1.Columns(3).HeaderText = "Password"
        DataGridView1.Columns(4).HeaderText = "Email"
        DataGridView1.Columns(5).HeaderText = "User Type"
        DataGridView1.Columns(6).HeaderText = "Date Created"
    End Sub

    Private Sub deleteUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Deleted! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                conn.Open()
                Dim query As String
                query = "Delete from tbl_user where user_id = '" & Textbox_ID.Text & "'"
                cmd = New MySqlCommand(query, conn)
                dr = cmd.ExecuteReader
                conn.Close()
                Me.Controls.Clear() 'removes all the controls on the form
                InitializeComponent() 'load all the controls again
                autogenerateID()

                loadData()
                tableHeader()

            End If

        Catch ex As Exception

            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tableHeader()
            End If
        End Try
    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from tbl_user order by ID asc"
        Dim da As New MySqlDataAdapter(com, conn)




    End Sub




    Private Sub btn_Add_Click(sender As Object, e As EventArgs)
        addUser()
    End Sub
    Public Sub addUser()
        Try
            Dim conn As New MySqlConnection
            Dim cmd As New MySqlCommand
            conn.ConnectionString = (CONNECTION_STRING)
            conn.Open()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from tbl_user where user_username='" & Textbox_Username.Text & "'"
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                MsgBox("Username Already Registered. Please Enter Another Username")
                conn.Close()
            Else
                conn.Close()
                conn.Open()
                cmd = New MySqlCommand("INSERT INTO tbl_user(user_id, user_name, user_username, user_pass, user_email, user_usertype, user_datecreated) VALUES('', '" & Textbox_Name.Text & "', '" & Textbox_Username.Text & "','" & Textbox_Pass.Text & "','" & Textbox_Email.Text & "', '" & Combobox_Usertype.Text & "', '" & Textbox_DateCreated.Text & "')", conn)
                If (Textbox_Name.Text = "" And Textbox_Username.Text = "" And Textbox_Pass.Text = "" And Textbox_Email.Text = "" And Combobox_Usertype.Text = "") Then
                    MessageBox.Show("Please enter the details")
                Else
                    cmd.ExecuteNonQuery()
                    MsgBox("Succerssfully Registered.", MsgBoxStyle.Information, "Success")
                    Me.Controls.Clear() 'removes all the controls on the form
                    InitializeComponent() 'load all the controls again
                    autogenerateID()
                    loadData()
                    tableHeader()

                    Timer1.Enabled = True
                    'Admin_Dashboard.showTotalUser()


                End If
                conn.Close()
            End If
            conn.Close()
        Catch ex As Exception
        End Try

    End Sub
    Public Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from tbl_user order by user_ID asc"
        Dim da As New MySqlDataAdapter(com, conn)
        Dim ds As New DataSet()

        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub



    Private Sub btn_Add_Click_1(sender As Object, e As EventArgs) Handles btn_Add.Click
        addUser()
    End Sub




    Private Sub lbl_date_Click(sender As Object, e As EventArgs) Handles lbl_date.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Textbox_DateCreated.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        autogenerateID()
        cleardata()

    End Sub

    Public Sub cleardata()
        Textbox_Email.Text = ""
        Textbox_Name.Text = ""
        Textbox_Pass.Text = ""
        Textbox_Username.Text = ""
        Combobox_Usertype.Text = ""
    End Sub

    Private Sub Textbox_ID_Click(sender As Object, e As EventArgs) Handles Textbox_ID.Click

    End Sub

    Private Sub Textbox_ID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Textbox_ID.KeyPress
        e.Handled = True
    End Sub

    Private Sub Combobox_Usertype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combobox_Usertype.SelectedIndexChanged

    End Sub

    Private Sub btn_Update_Click(sender As Object, e As EventArgs) Handles btn_Update.Click
        updateUser()
    End Sub


    Private Sub updateUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to update this user? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Updated! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                conn.Open()
                Dim query As String
                query = "Update tbl_user Set user_name = '" & Textbox_Name.Text & "', user_username = '" & Textbox_Username.Text & "', user_pass = '" & Textbox_Pass.Text & "', user_email = '" & Textbox_Email.Text & "', user_usertype = '" & Combobox_Usertype.Text & "' WHERE user_id = '" & Textbox_ID.Text & "'"
                cmd = New MySqlCommand(query, conn)
                dr = cmd.ExecuteReader
                conn.Close()
                Me.Controls.Clear() 'removes all the controls on the form
                InitializeComponent() 'load all the controls again
                autogenerateID()
                cleardata()
                loadData()
                tableHeader()
            End If

        Catch ex As Exception
            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tableHeader()
            End If
        End Try
    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        index = e.RowIndex
        If (e.RowIndex = -1) Then
            Return
        End If
        Dim selectedRow As DataGridViewRow

        selectedRow = DataGridView1.Rows(index)

        Textbox_ID.Text = selectedRow.Cells(0).Value.ToString()
        Textbox_Name.Text = selectedRow.Cells(1).Value.ToString()
        Textbox_Username.Text = selectedRow.Cells(2).Value.ToString()
        Textbox_Pass.Text = selectedRow.Cells(3).Value.ToString()
        Textbox_Email.Text = selectedRow.Cells(4).Value.ToString()
        Combobox_Usertype.Text = selectedRow.Cells(5).Value.ToString()
        Textbox_DateCreated.Text = selectedRow.Cells(6).Value.ToString()


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        DataGridView1.Columns(0).HeaderText = "ID"
        DataGridView1.Columns(1).HeaderText = "Name"
        DataGridView1.Columns(2).HeaderText = "User Name"
        DataGridView1.Columns(3).HeaderText = "Password"
        DataGridView1.Columns(4).HeaderText = "Email"
        DataGridView1.Columns(5).HeaderText = "User Type"
        DataGridView1.Columns(6).HeaderText = "Date Created"
    End Sub

    Private Sub MaterialSingleLineTextField7_Click(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField7.Click

    End Sub

    Private Sub MaterialSingleLineTextField7_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MaterialSingleLineTextField7.KeyPress

    End Sub

    Public Sub searchData(valuetoSearch As String)

        Dim searchQuery As String = "select * from tbl_user where concat(user_id, user_name, user_username, user_pass, user_email, user_usertype, user_datecreated) like '%" & valuetoSearch & "%'"
        Dim command As New MySqlCommand(searchQuery, conn)
        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub MaterialSingleLineTextField7_TextChanged(sender As Object, e As EventArgs) Handles MaterialSingleLineTextField7.TextChanged
        searchData(MaterialSingleLineTextField7.Text)
    End Sub

    Private Sub MetroComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    
    Private Sub Textbox_Pass_Click(sender As Object, e As EventArgs) Handles Textbox_Pass.Click
        
    End Sub

    Private Sub Textbox_Pass_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Textbox_Pass.KeyPress
        If Textbox_Pass.Text.Length >= 10 Then
            If e.KeyChar <> ControlChars.Back Then
                e.Handled = True
            End If
        End If
    End Sub

    
    Private Sub Textbox_Pass_TextChanged(sender As Object, e As EventArgs) Handles Textbox_Pass.TextChanged

    End Sub
End Class
